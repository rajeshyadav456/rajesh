from reports.api.viewsets import ReportViewSet
from rest_framework import routers

router = routers.DefaultRouter()
router.register('snippets', ReportViewSet, base_name='reports')