// // import React, { useState, useEffect } from "react";
// // import {
// //     Row, Col, Card, CardBody, CardTitle, Label, Button,


// // } from "reactstrap"

// // import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';



// // import { toast } from "react-toastify";
// // import { get, post } from "../../helpers/api_helper"

// // import { AvForm, AvField } from "availity-reactstrap-validation"

// // //Import Breadcrumb
// // import Breadcrumbs from "../../components/Common/Breadcrumb"

// // import { BASE_URL } from "../../helpers/url_helper";

// // import { getAccessToken } from "../../helpers/jwt-token-access/accessToken"

// // import Select from "react-select";

// // const optionGroup = [
// //     {
// //         label: "Days",
// //         options: [
// //             { label: "Monday", value: "Monday" },
// //             { label: "Tuesday", value: "Tuesday" },
// //             { label: "Wednesday", value: "Wednesday" },
// //             { label: 'Thursday', value: 'Thursday' },
// //             { label: 'Friday', value: 'Friday' },
// //             { label: 'Saturday', value: 'Saturday' },
// //             { label: 'Sunday', value: 'Sunday' }
// //         ],
// //     },

// // ];


// // const EventGroup = [
// //     {
// //         label: "Event By",
// //         options: [
// //             { label: "once", value: "once" },
// //             { label: "weekly", value: "weekly" },
// //             { label: "monthly", value: "monthly" }
// //         ]
// //     }
// // ]





// const CreateEvent = (props) => {
//     const { id } = props.match.params
//     const [didMount, setDidMount] = useState(false);
//     const [user, setUser] = useState(null)
//     const [houseChurch, setHouseChurch] = useState([])
//     const [accountUser, setAccountUser] = useState([])
//     const [submitting, setSubmitting] = useState(null)



//     const [ids, setIds] = useState([])


//     const [img, setImg] = useState(null)
//     const [name, setName] = useState([])
//     const [day, setDay] = useState([])

//     const [selectedDenomination, setselectedDenomination] = useState({ label: "Select Denomination", value: null });


//     const [searchBy, setSearchBy] = useState(null);
//     const [selectedGroup, setselectedGroup] = useState(null);
//     const [selectedHouseGroup, setselectedHouseGroup] = useState({ 'label': 'Select House Church', 'value': null })
//     const [selectedUserGroup, setselectedUserGroup] = useState({ 'label': 'Select User', 'value': null })
//     const [selectedTypeGroup, setselectedTypeGroup] = useState({ 'label': 'Selecte Type', 'value': null })
//     const [selectedDayGroup, setselectedDayGroup] = useState({ "label": "Select Day", "value": null })

//     const [houseEvent, setHouseEvent] = useState([])
//     const [startDate, setStartDate] = useState([])
//     const [endDate, setEndDate] = useState([])






//     useEffect(() => {
//         loadData(`${BASE_URL}/api/house_church/events/`)
//         loadUserData(`${BASE_URL}/api/accounts/users/`)
//         loadHouseData(`${BASE_URL}/api/house_church/dash-list-house_church/`)
//         loadEventData(`${BASE_URL}/api/house_church/events/`)


//         setDidMount(true);
//         get(`${BASE_URL}/api/house_church/events/${id}/`,
//             { headers: { 'Content-Type': 'application/json', 'Authorization': getAccessToken() }, validateStatus: false }
//         )
//             .then(response => {
//                 console.log(response.data, 'eventtype')
//                 setUser(response.data)
//                 setImg(response.data.image,)
//                 setStartDate(response.data.start)
//                 setEndDate(response.data.end)







//             })



//     }, []);




//     if (!didMount) {
//         return null;
//     }
//     //when file size is greater than 30 kb then show toast errror.convert file in bas4image 
//     const handleFileUpload = (e) => {
//         try {
//             let reader = new FileReader();
//             let file = e.target.files[0];
//             if (!file) {
//                 return;
//             }
//             const fileSizeInKB = file.size / 1024;
//             if (fileSizeInKB > 30) {
//                 toast.error('Please select an image file smaller than 30 kB');
//                 setImg(null)
//             } else {
//                 reader.onloadend = () => {
//                     var previewImgUrl = reader.result
//                     setImg(previewImgUrl)
//                 }
//                 reader.readAsDataURL(file);
//             }

//         } catch (error) {

//         }
//     }
//     //save church events field 
//     function handleSubmit(e, values) {
//         setSubmitting(true)
//         let data = { ...values, image: img, type: selectedTypeGroup.value, day: selectedDayGroup.value, user_id: selectedUserGroup.value, house_id: selectedHouseGroup.value}
//         post(`${BASE_URL}/api/house_church/events/`, data,
//             { headers: { 'Content-Type': 'application/json', 'Authorization': getAccessToken() }, validateStatus: false }
//         )
//             .then(response => {
//                 if (response.status >= 400) {

//                     console.log(response, 'event')
//                     if (response.name === undefined) {
//                         return toast.error('Event name is not define')
//                     }
//                     if (response.address === undefined) {
//                         return toast.error('Event address is not define')
//                     }
//                     if (response.house_id ===undefined){
//                         return toast.error("Event house id is not define")
//                     }
//                     if (response.type===undefined){
//                         return toast.error("Event type is not define")
//                     }

//                     setSubmitting(false)
//                 } else {
//                     console.log(response, 'SuccessEvent')
//                     setSubmitting(false)
//                 }
//             })

//     }


//     //get listing of event on the basis of id
//     function loadData(url) {
//         let data = get(url, { headers: { 'Content-Type': 'application/json', } })
//         data.then(response => {
//             const formattedOptions = response.data.results.map(items => ({
//                 value: items.id,
//                 label: items.name
//             }));
//             const formattedDate = new Date(startDate).toLocaleString('en-US', {
//                 month: '2-digit',
//                 day: '2-digit',
//                 year: 'numeric',

//             });
//             setStartDate(formattedDate)


//             setName(formattedOptions)



//         })
//     }
//     //get listing of house church on the basis of id.and get data in terms of value and label
//     function loadHouseData(url) {
//         let data = get(url, { headers: { 'Content-Type': 'application/json', } })
//         data.then(response => {
//             const formattedOptions = response.data.results.map((items) => ({
//                 value: items.id,
//                 label: items.name
//             }));
//             setHouseChurch(formattedOptions)
//         })

//     }
   
//     //get listing of accounts user. and show first and last name.
//     function loadUserData(url) {
//         let data = get(url, { headers: { 'Content-Type': 'application/json', } })
//         data.then(response => {
//             const formattedOptions = response.data.results.map((items) => ({
//                 value: items.id,
//                 label: items.first_name + '' + items.last_name
//             }));
//             setAccountUser(formattedOptions)
//         })
//     }
//     function loadEventData(url) {
//         // let data=get(url,{headers:{'Content-Type':'application/json'}})
//         // data.then(response=>{
//         //     console.log(response.data.results,'event')
//         //     const data=response.data.results.map(items=>items.type)
//         //     console.log(data,'datadata')
//         //     setType(data)
//         // })


//     }
//     function handleSelectGroup(selectedDenomination) {
//         setselectedDenomination(selectedDenomination);
//     }

//     function handleHouseSelectGroup(selectedHouseGroup) {
//         setselectedHouseGroup(selectedHouseGroup);
//     }
//     function handleUserSelectGroup(selectedUserGroup) {
//         setselectedUserGroup(selectedUserGroup);
//     }
//     function handleTypeSelectGroup(selectedTypeGroup) {
//         setselectedTypeGroup(selectedTypeGroup)

//     }
//     function handleSelectDayGroup(selectedDayGroup) {
//         setselectedDayGroup(selectedDayGroup)
//     }
  


//     //single select row 
//     function handleOnSelect(row, isSelect) {
//         let id = []
//         if (isSelect) {
//             id = ids
//             id.push(row.id)
//         } else {
//             for (let i = 0; i < ids.length; i++) {
//                 if (ids[i] !== row.id) {
//                     id.push(ids[i])
//                 }
//             }

//         }
//         setIds(id)
//     }
//     //multiple select row 
//     function handleOnSelectAll(isSelect, rows) {
//         console.log(isSelect, 'eventisSelect')
//         if (isSelect) {
//             let email = []
//             let id = []
//             for (let i = 0; i < rows.length; i++) {
//                 email.push(rows[i].email.toLowerCase())
//                 id.push(rows[i].id)
//             }
//             setIds(id)
//         } else {
//             setIds([])
//         }
//     }



//     const selectRow = {
//         mode: 'checkbox',
//         clickToSelect: true,
//         onSelect: handleOnSelect,
//         onSelectAll: handleOnSelectAll
//     };









//     return (
//         <React.Fragment>
//             <div className="page-content">

//                 <Breadcrumbs title="House Church" breadcrumbItem="Event Data" link="/house-churches" />

//                 <Row>
//                     <Col lg={12}>



//                         {user ?
//                             <Row>
//                                 <Col md="12">

//                                     <Row>

//                                         <Col sm="10">
//                                             <AvForm className="needs-validation" onValidSubmit={handleSubmit}>
//                                                 <Card>
//                                                     <CardBody>
//                                                         <CardTitle>Church Detail </CardTitle>
//                                                         <Row>
//                                                             <Col md="6">
//                                                                 <div className="mb-3">

//                                                                     <Label htmlFor="user_id">User Name</Label>
//                                                                     <Select
//                                                                         value={selectedUserGroup}
//                                                                         onChange={(e) => {
//                                                                             handleUserSelectGroup(e);
//                                                                         }}
//                                                                         options={accountUser}
//                                                                         classNamePrefix="select2-selection"
//                                                                     />
//                                                                 </div>
//                                                             </Col>

//                                                             <Col md="6">
//                                                                 <div className="mb-3">
//                                                                     <Label htmlFor='house_id'>House Name</Label>
//                                                                     <Select
//                                                                         value={selectedHouseGroup}
//                                                                         onChange={(e) => {
//                                                                             handleHouseSelectGroup(e);
//                                                                         }}
//                                                                         options={houseChurch}
//                                                                         classNamePrefix="select2-selection"
//                                                                     />

//                                                                 </div>
//                                                             </Col>
//                                                         </Row>


//                                                         <Row>
//                                                             <Col md="6">
//                                                                 <div className="mb-3">
//                                                                     <Label htmlFor="name">Name</Label>
//                                                                     <AvField
//                                                                         name="name"
//                                                                         placeholder="Name"
//                                                                         type="text"
//                                                                         className="form-control"

//                                                                         id="name"
//                                                                         value={user.name}
//                                                                     />
//                                                                 </div>

//                                                             </Col>
//                                                             <Col md="6">
//                                                                 <div className="mb-3">
//                                                                     <Label htmlFor="address">Address</Label>
//                                                                     <AvField
//                                                                         name="address"
//                                                                         placeholder="Address"
//                                                                         type="text"
//                                                                         errorMessage=" Please Enter Address."
//                                                                         className="form-control"

//                                                                         id="address"
//                                                                         value={user.address}
//                                                                     />
//                                                                 </div>
//                                                             </Col>
//                                                         </Row>
//                                                         <Row>
//                                                             <Col md="6">
//                                                                 <div className="mb-3">
//                                                                     <Label htmlFor="city">City</Label>
//                                                                     <AvField
//                                                                         name="city"
//                                                                         placeholder="City"
//                                                                         type="text"
//                                                                         errorMessage=" Please Enter city."
//                                                                         className="form-control"

//                                                                         id="city"
//                                                                         value={user.city}
//                                                                     />
//                                                                 </div>
//                                                             </Col>

//                                                             <Col md="6">
//                                                                 <div className="mb-3">
//                                                                     <Label htmlFor="state">State</Label>
//                                                                     <AvField
//                                                                         name="state"
//                                                                         placeholder="State"
//                                                                         type="text"
//                                                                         errorMessage=" Please Enter State."
//                                                                         className="form-control"

//                                                                         id="state"
//                                                                         value={user.state}
//                                                                     />
//                                                                 </div>
//                                                             </Col>
//                                                         </Row>
//                                                         <Row>


//                                                             <Col md="6">
//                                                                 <div className="mb-3">
//                                                                     <Label htmlFor="zipcode">ZipCode</Label>
//                                                                     <AvField
//                                                                         name="zipcode"
//                                                                         placeholder="ZipCode"
//                                                                         type="text"
//                                                                         errorMessage=" Please provide a valid ZipCode."
//                                                                         className="form-control"

//                                                                         id="zipcode"
//                                                                         value={user.zipcode}
//                                                                     />
//                                                                 </div>
//                                                             </Col>

//                                                             <Col md="6">
//                                                                 <div className="mb-3">

//                                                                     <Label htmlFor='type'>Type</Label>
//                                                                     <Select
//                                                                         value={selectedTypeGroup}
//                                                                         onChange={(e) => {
//                                                                             handleTypeSelectGroup(e);
//                                                                         }}
//                                                                         options={EventGroup}
//                                                                         classNamePrefix="select2-selection"
//                                                                     />
//                                                                 </div>
//                                                             </Col>



//                                                         </Row>
//                                                         <Row>

//                                                             <Col md="6">
//                                                                 <div className="mb-3">

//                                                                     <Label htmlFor='start'>Start Time</Label>
//                                                                     <AvField
//                                                                         name='start'
//                                                                         placeholder="Start Time"
//                                                                         type='date'
//                                                                         id='start'
//                                                                         value={user.start} />
//                                                                 </div>
//                                                             </Col>

//                                                             <Col md="6">
//                                                                 <div className="mb-3">

//                                                                     <Label htmlFor='end'>End Time</Label>
//                                                                     <AvField
//                                                                         name='end'
//                                                                         placeholder='End Time'
//                                                                         type='date'
//                                                                         id='end'
//                                                                         value={user.end} />
//                                                                 </div>

//                                                             </Col>

//                                                         </Row>


//                                                         <Row>
//                                                             <Col md='6'>
//                                                                 <div className="mb-3">

//                                                                     <Label htmlFor='monthly_date'>Monthly Date</Label>
//                                                                     <AvField
//                                                                         name='monthly_date'
//                                                                         placeholder='Monthly Date'
//                                                                         type='Date'
//                                                                         id='monthly_date'
//                                                                         value={user.monthly_date} />
//                                                                 </div>

//                                                             </Col>
//                                                             <Col md='6'>
//                                                                 <div className="mb-3">

//                                                                     <Label htmlFor="day">Day</Label>
//                                                                     <Select
//                                                                         value={selectedDayGroup}
//                                                                         onChange={(e) => {
//                                                                             handleSelectDayGroup(e);
//                                                                         }}
//                                                                         options={optionGroup}
//                                                                         classNamePrefix="select2-selection"
//                                                                     />
//                                                                 </div>

//                                                             </Col>
//                                                         </Row>
//                                                         <Row>
//                                                             <Col md='6'>
//                                                                 <div className="mb-3">
//                                                                     <Label htmlFor="time">Time</Label>
//                                                                     <AvField
//                                                                         name="time"
//                                                                         placeholder="Time"
//                                                                         type="time"
//                                                                         errorMessage=" Please provide a valid TIme."
//                                                                         className="form-control"

//                                                                         id="time"
//                                                                         value={user.time}
//                                                                     />
//                                                                 </div>

//                                                             </Col>
                                                            
                                                            
//                                                             <Col md='6'>
//                                                                     <div className="mb-3">

//                                                                         <Label htmlFor='Desc'>Description</Label>
//                                                                         <AvField
//                                                                             name='Desc'
//                                                                             placeholde='Description'
//                                                                             type='textarea'
//                                                                             id='Desc'
//                                                                             value={user.Desc} />
//                                                                     </div>
//                                                                 </Col>

//                                                         </Row>
//                                                         <Row>
//                                                             <Col md={6}>

//                                                                 <div className="mb-3">
//                                                                     <Label>Image</Label>{" "}
//                                                                     <input
//                                                                         type="file"
//                                                                         id="image"
//                                                                         accept="image/png, image/jpeg"
//                                                                         onChange={(e) => handleFileUpload(e)}
//                                                                         value={user.image}
//                                                                     />
//                                                                 </div>

//                                                             </Col>
//                                                         </Row>






//                                                         {submitting ?
//                                                             <button
//                                                                 type="button"
//                                                                 className="btn btn-primary waves-effect waves-light my-3"
//                                                             >
//                                                                 <i className="bx bx-loader bx-spin font-size-16 align-middle me-2"></i>{" "}
//                                                                 Creating
//                                                             </button>
//                                                             :
//                                                             <Button color="primary" type="submit">
//                                                                 Create
//                                                             </Button>
//                                                         }
//                                                     </CardBody>
//                                                 </Card>
//                                             </AvForm>
//                                         </Col>

//                                     </Row>


//                                 </Col>

//                             </Row>
//                             :
//                             <div id="preloader">
//                                 <div id="status">
//                                     <div className="spinner-chase">
//                                         <div className="chase-dot"></div>
//                                         <div className="chase-dot"></div>
//                                         <div className="chase-dot"></div>
//                                         <div className="chase-dot"></div>
//                                         <div className="chase-dot"></div>
//                                         <div className="chase-dot"></div>
//                                     </div>
//                                 </div>
//                             </div>
//                         }





//                     </Col>



//                 </Row>


//             </div>

//         </React.Fragment>
//     )
// }

// export default CreateEvent


