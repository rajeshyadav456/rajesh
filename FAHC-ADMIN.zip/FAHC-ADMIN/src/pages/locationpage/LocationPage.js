import React, { useState, useEffect } from "react";
import { Row, Col, Card, CardBody, CardTitle, Label, Button, Modal,Spinner } from "reactstrap"
import { AvForm, AvField } from "availity-reactstrap-validation"
//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb"

import { BASE_URL } from "../../helpers/url_helper";
import { get, patch } from "../../helpers/api_helper";
import { toast } from 'react-toastify';
// import not_avail from "../../assets/images/not_avail.jpg"
import { getAccessToken } from "../../helpers/jwt-token-access/accessToken"
import { ValidateUser } from "../../helpers/validate_user";

const LocationPage = (props) => {
    // const state = props.location.statedata
    // const { id } = props.match.params
    const [didMount, setDidMount] = useState(false);
    const [user, setUser] = useState(null)
    const [submitting, setSubmitting] = useState(null)
    const [img, setImg] = useState(null)
    const [isLoading, setLoading] = useState(true); // Loading state
    const [modal_standard, setmodal_standard] = useState(false)

    function removeBodyCss() {
        document.body.classList.add("no_padding")
    }

    function tog_standard() {
        setmodal_standard(!modal_standard)
        removeBodyCss()
    }


    ValidateUser(props)


    useEffect(() => {

        setDidMount(true);
        get(`${BASE_URL}/api/house_church/meta-content/1/`,
            { headers: { 'Content-Type': 'application/json', 'Authorization': getAccessToken() }, validateStatus: false }
        )
            .then(response => {
                setUser(response.data)
                console.log(response.data.image, 'pageimage')




            })

    }, []);


    if (!didMount) {
        return null;
    }
    const handleFileUpload = (e) => {
        try {
            let reader = new FileReader();
            let file = e.target.files[0];
            if (!file) {
                return;
            }
            const fileSizeInKB = file.size / 1024;
            if (fileSizeInKB > 30) {
                toast.error('Please select an image file smaller than 30 kB');
                setImg(null)
            } else {
                reader.onloadend = () => {
                    var previewImgUrl = reader.result
                    setImg(previewImgUrl)
                }
                reader.readAsDataURL(file);
            }

        } catch (error) {

        }
    }


    function handleSubmit(e, values) {
        setSubmitting(true)
        setLoading(true)
        if (img) {
            // Convert the image to bytes to calculate its size
            const imageSizeInKB = img.size / 1024;

            if (imageSizeInKB > 30) {
                // Show an error message using the 'toast.error()' function
                toast.error('Please select an image less than 30 KB');
                setSubmitting(false); // Set submitting to false to enable the user to try again.
                return; // Exit the function without making the API call.
            }
        }


        let data = { ...values }
        if (img) {
            data['image'] = img
        }
        console.log(data, 'data')
        patch(`${BASE_URL}/api/house_church/meta-content/1/`, data,
            { headers: { 'Content-Type': 'application/json', 'Authorization': getAccessToken() }, validateStatus: false }
        )
            .then(response => {
                if (response.status >= 400) {

                    setSubmitting(false)
                    console.log(response.data, 'notchurch')
                } else {
                    console.log(response, 'sucesschurch')
                    setSubmitting(false)
                    tog_standard()
                    setLoading(false)
                    console.log(submitting, 'submitting')
                }
            })

    }

    return (
        <React.Fragment>
            <div className="page-content">

                <Breadcrumbs title="Dashboard" breadcrumbItem={"Mangae Page Meta"} link="/" />
                {/* <Breadcrumbs title="Location Page" breadcrumbItem={"Location Church"} /> */}

                {user ?
                    <Row>

                        <Col lg={8}>
                            <AvForm className="needs-validation" onValidSubmit={handleSubmit}>
                                <Card>
                                    <CardBody>
                                        <CardTitle>Location Page </CardTitle>
                                        <Row>
                                            <Col md="6">
                                                <div className="mb-3">
                                                    <Label htmlFor="meta_title">Meta title</Label>
                                                    <AvField
                                                        name='meta_title'
                                                        placeholder='Meta title'
                                                        type='text'
                                                        className='form-control'
                                                        id='meta_title'
                                                        value={user.meta_title} />

                                                </div>
                                            </Col>
                                            <Col md='6'>
                                                <div className="mb-3">
                                                    <Label htmlFor="meta_description">Meta description</Label>
                                                    <AvField
                                                        name='meta_description'
                                                        placeholder=' Meta description'
                                                        type='textarea'
                                                        className='form-control'
                                                        id='meta_description'
                                                        value={user.meta_description}
                                                    />

                                                </div>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col md="6">
                                                <div className="mb-3">
                                                    <Label htmlFor="keywords">Keywords</Label>
                                                    <AvField
                                                        name="keywords"
                                                        placeholder="keywords"
                                                        type="text"
                                                        className="form-control"

                                                        id="keywords"
                                                        value={user.keywords}
                                                    />
                                                </div>

                                            </Col>
                                            <Col md="6">
                                                <div className="mb-3">
                                                    <Label htmlFor="page_title">Page title</Label>
                                                    <AvField
                                                        name="page_title"
                                                        placeholder="page_title"
                                                        type="text"
                                                        errorMessage=" Please Enter Page title."
                                                        className="form-control"

                                                        id="page_title"
                                                        value={user.page_title}
                                                    />
                                                </div>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col md='6'>

                                                <div className="mb-3">
                                                    <Label>Image</Label>{" "}
                                                    <input
                                                        type="file"
                                                        id="image"
                                                        accept="image/png, image/jpeg"
                                                        onChange={(e) => handleFileUpload(e)}
                                                    //    value={user.image}
                                                    />
                                                </div>
                                            </Col>
                                        </Row>





                                        {submitting ?
                                            <Button color='primary' type='submit' onClick={() => { tog_standard() }}
                                            >
                                                Submit
                                            </Button>
                                            :
                                            <Button color="primary" type="submit" onClick={() => { tog_standard() }} >
                                                Sumbit
                                            </Button>
                                        }
                                    </CardBody>
                                </Card>
                            </AvForm>

                        </Col>

                    </Row>

                    :
                    <div id="preloader">
                        <div id="status">
                            <div className="spinner-chase">
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                            </div>
                        </div>
                    </div>

                }
                <Modal
                    isOpen={modal_standard}
                    toggle={() => {
                        tog_standard()
                    }}
                    centered={true}

                >
                    <div className="modal-header">
                        <p className="mt-3">Creating Page Meta</p>


                    </div>

                    <div className="modal-body">

                        <Col lg='12'>
                            <p>script is running please do not close or reload this page</p>
                            {/* if (isLoading){
        return (
                            <div className="d-flex align-items-center justify-content-center">
                                <h4 className="my-3">Table is Empty</h4>

                            </div>
                            )
       } */}
       {isLoading?   <div className="d-flex align-items-center justify-content-center">
          <Spinner className="my-3" color="dark" />
        </div> :
        <div className="d-flex align-items-center justify-content-center">
          <Spinner className="my-3" color="dark" />
        </div>}
                        </Col>

                    </div>

                </Modal>

            </div>


        </React.Fragment>


    )
}

export default LocationPage
