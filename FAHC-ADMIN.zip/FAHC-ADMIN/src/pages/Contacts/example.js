import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import ReactSelect from 'react-select';
import {
  Row,
  Col,
  Card,
  CardBody,
  CardTitle,
  Label,
  Button,
} from 'reactstrap';

const Select = (props) => {
  const { name, title, placeholder, className, isClearable, value, options } =
    props;

  const handleChange = (e) => {
    const selectedValue = e ? e.value : null;
    props.onChangeFunc(selectedValue, name, e);

    if (props.onValidateFunc) {
      let errorMsg = null;
      if (!selectedValue && props.isReq) {
        errorMsg = `Please select ${props.title}.`;
      }

      props.onValidateFunc(errorMsg, name);
    }
  };

  const inputProps = {
    name,
    placeholder: placeholder || `Select ${title}`,
    className,
    isClearable,
    value: options.find((x) => x.value === value),
    options,
  };

  return (
    <div className={props.outerClassName}>
      <label className="form-label">{title}</label>
      <ReactSelect {...inputProps} onChange={handleChange} />
      {props.errorMsg && (
        <span className="text-danger">
          {props.errorMsg === true ? `Please select ${title}.` : props.errorMsg}
        </span>
      )}
    </div>
  );
};

Select.defaultProps = {
  name: '',
  title: '',
  placeholder: '',
  className: '',
  outerClassName: 'mb-2',
  isClearable: true,
  value: '',
  options: [],
  onChangeFunc: () => {},
  isReq: null,
  onValidateFunc: () => {},
};

Select.propTypes = {
  name: PropTypes.string,
  title: PropTypes.string,
  placeholder: PropTypes.string,
  className: PropTypes.string,
  outerClassName: PropTypes.string,
  isClearable: PropTypes.bool,
  value: PropTypes.any,
  options: PropTypes.array,
  onChangeFunc: PropTypes.func,
  isReq: PropTypes.bool,
  errorMsg: PropTypes.any,
  onValidateFunc: PropTypes.func,
};

function Contact() {
  const [form, setForm] = useState({
    country: null,
    lang: null,
  });

  const [error, setError] = useState({
    country: {
      isReq: true,
      errorMsg: '',
      onValidateFunc: onValidate,
    },
    lang: {
      isReq: true,
      errorMsg: '',
      onValidateFunc: onValidate,
    },
  });

  const fetchCountryList = async () => {
    try {
      const response = await axios.get('API_URL/countries');
      const countryList = response.data.map((country) => ({
        value: country.code,
        label: country.name,
      }));
      return countryList;
    } catch (error) {
      console.error('Failed to fetch country list:', error);
      return [];
    }
  };

  const fetchLanguageList = async () => {
    try {
      const response = await axios.get('API_URL/languages');
      const languageList = response.data.map((language) => ({
        value: language.code,
        label: language.name,
      }));
      return languageList;
    }
