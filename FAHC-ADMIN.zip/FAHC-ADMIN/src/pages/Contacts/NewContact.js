function handleSubmit(e, values) {
    setSubmitting(true);
  
    // Update the image
    put(
      `${BASE_URL}/api/house_church/listchurches/${id}/`,
      { ...values, image: img },
      {
        headers: { 'Content-Type': 'application/json' },
        validateStatus: false
      }
    )
      .then(response => {
        if (response.status >= 400) {
          toast.error("Something Went Wrong (Image Update)");
        } else {
          // Image updated successfully, now update the status
          put(
            `${BASE_URL}/api/house_church/listchurches/${id}/`,
            { ...values, status: ischecked },
            {
              headers: { 'Content-Type': 'application/json' },
              validateStatus: false
            }
          )
            .then(response => {
              if (response.status >= 400) {
                toast.error("Something Went Wrong (Status Update)");
              } else {
                props.history.push("/allchurch");
              }
            });
        }
      });
  }
  