import React,{useState,useEffect} from "react"
import { Row, Col, CardBody, Card, Container } from "reactstrap"
import { getAccessToken } from "../../helpers/jwt-token-access/accessToken"

import { get } from "../../helpers/api_helper"
import { BASE_URL } from "../../helpers/url_helper";



import './data.css'

const Dashboard = (props) => {

  const [totalusers,setTotalUsers]=useState([])
  const [totalchurches,setTotalChurches]=useState([])
  const [allhouses,setAllHouse]=useState([])
  const [userregistrations,setUserRegistrations]=useState([])
  const [housechurchregistrations,setHouseChurchRegistrations]=useState([])
  const [churchregistrations,setChurchRegistrations]=useState([])
  const [flaggedusercount,setFlaggedUserCount]=useState([])
  const [flaggedhousechurchcount,setFlaggedHouseChurchCount]=useState([])
  const [upcomingeventcount,setUpcomingEventCount]=useState([])
  


  useEffect(()=>{
    loadData(`${BASE_URL}/api/house_church/dashboard-data/`)
  },[])
  function loadData(url){
    let data=get(url,{headers:{'Content-Type':'aplication/json','Authorization': getAccessToken() }})
    data.then(response=>{
      setTotalUsers(response.data.total_users)
      setTotalChurches(response.data.total_churches)
      setAllHouse(response.data.all_houses)
      setUserRegistrations(response.data.user_registrations)
      setHouseChurchRegistrations(response.data.house_church_registrations)
      setChurchRegistrations(response.data.church_registrations)
      setFlaggedUserCount(response.data.flagged_user_count)
      setFlaggedHouseChurchCount(response.data.flagged_house_church_count)
      setUpcomingEventCount(response.data.upcoming_event_count)
    

    })
  }
  return (
    <React.Fragment>
      <div className="page-content">
  
        <Row>
          <div className="col-12">
            <div className="page-title-box d-flex align-items-center justify-content-between">
              <h4 className="page-title mb-0 font-size-18">Dashboard</h4>

              <div className="page-title-right">
                <ol className="breadcrumb m-0">
                  <li className="breadcrumb-item active">Welcome to FAHC Dashboard</li>
                </ol>
              </div>
            </div>
          </div>
        </Row>
        
       <Row>
  
        <Row >
         <Col lg='3' >
        
         <Container>
      <div className="position-relative">
        <Card>
          <CardBody>
            <div className="d-flex align-items-start">
              <div className="avatar-sm font-size-20 me-3">
                <span className="avatar-title bg-soft-primary text-primary rounded">
                  <i className="mdi mdi-account-multiple-outline"></i>
                </span>
              </div>
              <div className="flex-1">
                <div className="font-size-16 mt-2">Total Users</div>
              </div>
            </div>
            <h4 className="mt-4">{totalusers}</h4>
            <Row>
              <div className="col-7">
                <p className="mb-0">
                  
                  <a href='/users'>
                  <span className="text-success me-2">View Users</span>
                  </a>
                  <i className=""></i>
                </p>
              </div>
            </Row>
          </CardBody>
        </Card>
      </div>
    </Container>
         </Col>
         <Col lg='3'>

         
            <Card>
              <CardBody>
                <div className="d-flex align-items-start">
                  <div className="avatar-sm font-size-20 me-3">
                    <span className="avatar-title bg-soft-primary text-primary rounded">
                      <i className="fas fa-church"></i>
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="font-size-16 mt-2">Churches</div>

                  </div>
                </div>
                <h4 className="mt-4">{totalchurches}</h4>
                <Row>
                  <div className="col-7">
                    <p className="mb-0"></p>
                      <a href='/all-churches'><span className="text-success me-2"> View Church <i
                      className=""></i> </span></a>
                  </div>
                 
                </Row>
              </CardBody>
            </Card>
         </Col>
         <Col lg='3'>

     
            <Card>
              <CardBody>
                <div className="d-flex align-items-start">
                  <div className="avatar-sm font-size-20 me-3">
                    <span className="avatar-title bg-soft-primary text-primary rounded">
                      <i className="fas fa-home fa-church"></i>
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="font-size-16 mt-2">House Churches</div>

                  </div>
                </div>
                <h4 className="mt-4">{allhouses}</h4>
                <Row>
                  <div className="col-7">
                    <p className="mb-0"></p>
                      <a href='/house-churches'><span className="text-success me-2"> View Houses <i
                      className=""></i> </span></a>
                  </div>
                
                </Row>
              </CardBody>
            </Card>
         </Col>
         <Col lg='3'>
        
            <Card>
              <CardBody>
                <div className="d-flex align-items-start">
                  <div className="avatar-sm font-size-20 me-3">
                    <span className="avatar-title bg-soft-primary text-primary rounded">
                      <i className="fas fa-exclamation-circle"></i>
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="font-size-16 mt-2">Violations</div>

                  </div>
                </div>
                <h4 className="mt-4">{flaggedusercount+flaggedhousechurchcount}</h4>
              
                <Row>
                  <div className="col-7">
                    <p className="mb-0"></p>
                      <a href='/flagged-house-church'><span className="text-success me-2"> <i
                      className=""></i> </span></a>
                  </div>
              
                </Row>
               
              </CardBody>
            </Card>
         </Col>
        
       
        </Row>
        <Row >
         <Col lg='4' >
        
           <Card>
              <CardBody>
                <div className="d-flex align-items-start">
                  <div className="avatar-sm font-size-20 me-3">
                    <span className="avatar-title bg-soft-primary text-primary rounded">
                      <i className="mdi mdi-account-multiple-outline"></i>
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="font-size-16 mt-2">Users Registered This Week</div>

                  </div>
                </div>
                <h4 className="mt-4">{userregistrations}</h4>
              
              </CardBody>
            </Card>
         </Col>
         <Col lg='4'>

         
            <Card>
              <CardBody>
                <div className="d-flex align-items-end">
                  <div className="avatar-sm font-size-20 me-3">
                    <span className="avatar-title bg-soft-primary text-primary rounded">
                      <i className="fas fa-church"></i>
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="font-size-16 mt-2">House Churches Registered This Week</div>

                  </div>
                </div>
                <h4 className="mt-4">{housechurchregistrations}</h4>
               
              </CardBody>
            </Card>
         </Col>
         <Col lg='4'>

     
            <Card>
              <CardBody>
                <div className="d-flex align-items-start">
                  <div className="avatar-sm font-size-20 me-3">
                    <span className="avatar-title bg-soft-primary text-primary rounded">
                      <i className="fas fa-home fa-church"></i>
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="font-size-16 mt-2">Churches Registered This Week</div>

                  </div>
                </div>
                <h4 className="mt-4">{churchregistrations}</h4>
               
              </CardBody>
            </Card>
         </Col>
       
        
       
        </Row>
        <Row >
         <Col lg='4' >
        
           <Card>
              <CardBody>
                <div className="d-flex align-items-start">
                  <div className="avatar-sm font-size-20 me-3">
                    <span className="avatar-title bg-soft-primary text-primary rounded">
                      <i className="mdi mdi-account-multiple-outline"></i>
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="font-size-16 mt-2">Flagged Profiles</div>

                  </div>
                </div>
                <h4 className="mt-4">{flaggedusercount}</h4>
                <Row>
                
                
                </Row>
              </CardBody>
            </Card>
         </Col>
         <Col lg='4'>

         
            <Card>
              <CardBody>
                <div className="d-flex align-items-start">
                  <div className="avatar-sm font-size-20 me-3">
                    <span className="avatar-title bg-soft-primary text-primary rounded">
                      <i className="fas fa-church"></i>
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="font-size-16 mt-2">Flagged Houses</div>

                  </div>
                </div>
                <h4 className="mt-4">{flaggedhousechurchcount}</h4>
                <Row>
                 
                </Row>
              </CardBody>
            </Card>
         </Col>
         <Col lg='4'>

     
            <Card>
              <CardBody>
                <div className="d-flex align-items-start">
                  <div className="avatar-sm font-size-20 me-3">
                    <span className="avatar-title bg-soft-primary text-primary rounded">
                      <i className="bx bx-calendar-event"></i>
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="font-size-16 mt-2">Upcoming Event</div>

                  </div>
                </div>
                <h4 className="mt-4">{upcomingeventcount}</h4>
                <Row>
                 

                </Row>
              </CardBody>
            </Card>
         </Col>
       
        
       
        </Row>
       </Row>
    
      </div>
    </React.Fragment>
  )
}

export default Dashboard