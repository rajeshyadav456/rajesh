import React, { useState, useEffect } from "react";
import { Row, Col, Card, CardBody, CardTitle, Label, Button } from "reactstrap"
import { AvForm, AvField } from "availity-reactstrap-validation"
//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb"

import { BASE_URL } from "../../helpers/url_helper";
import { get, put } from "../../helpers/api_helper";
import { toast } from 'react-toastify';
import { getAccessToken } from "../../helpers/jwt-token-access/accessToken"


const EditCustomer = (props) => {
    const state = props.location.statedata
    const { id } = props.match.params
    const [didMount, setDidMount] = useState(false);
    const [user, setUser] = useState(null)
    const [submitting, setSubmitting] = useState(null)
    const [ischecked, setIsChecked] = useState(null)




  
    useEffect(() => {
        setDidMount(true);
        get(`${BASE_URL}/api/house_church/denominations/${id}/`,
            { headers: { 'Content-Type': 'application/json', 'Authorization': getAccessToken() }, validateStatus: false }
        )
            .then(response => {
                setUser(response.data)
                setIsChecked(response.data.status)
            })
        return () => setDidMount(false);

    }, [id]);

    if (!didMount) {
        return null;
    }

    function handleSubmit(e, values) {
        setSubmitting(true)
        put(`${BASE_URL}/api/house_church/denominations/${id}/`, {...values,
            status: ischecked},
            { headers: { 'Content-Type': 'application/json', 'Authorization': getAccessToken()}, validateStatus: false }
        )
            .then(response => {
                if (response.status >= 400) {
                    toast.error("Somthing Went Wrong")
                } else {
                    props.history.push("/denomination")
                }
            })

    }
    
    return (
        <React.Fragment>
            <div className="page-content">

                <Breadcrumbs title="Users" breadcrumbItem={"House church"} link="/users" data={state} />
                {user ?
                    <Row>
                       
                                <Col lg="6">
                                    <AvForm className="needs-validation" onValidSubmit={handleSubmit}>
                                        <Card>
                                            <CardBody>
                                                <CardTitle>User Details </CardTitle>
                                                <Row>
                                                    <Col md="6">
                                                        <div className="mb-3">
                                                            <Label htmlFor="name"> Name</Label>
                                                            <AvField
                                                                name="name"
                                                                placeholder=" Name"
                                                                type="text"
                                                                className="form-control"

                                                                id="name"
                                                                value={user.name}
                                                             
                                                            />
                                                        </div>
                                                    </Col>



                                                </Row>
                                                <Row>

                                                    <Col md={6}>
                                                        {/* <div className="mb-3">
                                                        <Label htmlFor="status">Status</Label>
                                                            <AvField
                                                                name="status"
                                                                placeholder=" Status"
                                                                type="text"
                                                                className="form-control"
                                                                id="status"
                                                                value={user.status}
                                                                />
                                                        </div> */}
                                                        <div className="checkbox-wrapper">
                                                            <label>
                                                                <input

                                                                    type="checkbox"
                                                                    checked={ischecked}
                                                                    onChange={(e) => setIsChecked(e.target.checked)}

                                                                
                                                                />{"   "}
                                                                Status
                                                            </label>
                                                        </div>
                                                    </Col>
                                                </Row>
                                                <Row>



                                                    <Col md={6}>

                                                    </Col>
                                                </Row>
                                                <Row>


                                                </Row>
                                           
                                                           {submitting ?
                                                               <button
                                                                   type="button"
                                                                   className="btn btn-primary waves-effect waves-light my-3"
                                                               >
                                                                   <i className="bx bx-loader bx-spin font-size-16 align-middle me-2"></i>{" "}
                                                                   Updating
                                                               </button> 
                                                               :
                                                               <Button color="primary" type="submit">
                                                                   Update
                                                               </Button>
                                                           }
                                          
                                            </CardBody>
                                        </Card>
                                    </AvForm>
                                </Col>
                               
                            </Row>


                        
                   
                    :
                    <div id="preloader">
                        <div id="status">
                            <div className="spinner-chase">
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                            </div>
                        </div>
                    </div>
                }

            </div>

        </React.Fragment>
    )
}

export default EditCustomer
