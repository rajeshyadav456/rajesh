# organization member invitation link expiry days
ORGANIZATION_MEMBER_INVITE_VALIDITY_DAYS = 30  # days
