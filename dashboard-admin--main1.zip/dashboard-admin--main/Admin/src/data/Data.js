// import Ownership from "../console/ownership"

function Data(){
    return (
        <>
        <div>
            <h1>Verify OwnerShip</h1>
            <p>To use Ahrefs and check your website for free, please prove that you own your website.</p>
            {/* <Ownership/> */}
        </div>
        </>
    )
}
export default Data
