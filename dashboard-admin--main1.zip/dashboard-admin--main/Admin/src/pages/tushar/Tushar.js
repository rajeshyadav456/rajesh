const Tushar=()=>{
    return (
        <div style={{'marginTop':'200px' ,'textAlign':'center'}}>
            <h1>my name is tushar kumar</h1>
        </div>
    );
}
export default Tushar
