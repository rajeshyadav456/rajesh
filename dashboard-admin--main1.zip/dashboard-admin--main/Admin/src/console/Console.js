

import Navbar from "./Udesign"

const Console=(props)=>{
  return(
    <>
    <Navbar 
      props = {props}
      history = {props.history}
      />
    </>
  )
}
export default Console











