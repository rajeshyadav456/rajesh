export const BASE_URL = 'https://app.doddlehq.com/api';
