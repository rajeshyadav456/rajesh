{/* <AvForm className="needs-validation" onSubmit={() => handleSubmit()}>
                <Row>
                  <Col md="6">
                    <div className="mb-3">
                      <Label htmlFor="validationCustom01" value={start_date}>start_date</Label>
                      <AvField
                        name="start_date"
                        placeholder="start_date"
                        type="date"
                        errorMessage="Enter start_date"
                        className="form-control"
                        validate={{ required: { value: true } }}
                        id="validationCustom01"
                        onChange={(e) => setStartDate(e.target.value)}
                      />
                    </div>
                  </Col>
                  <Col md="6">
                    <div className="mb-3">
                      <Label htmlFor="validationCustom02" value={end_date}>end_date</Label>
                      <AvField
                        name="end_date"
                        placeholder="end_date"
                        type="date"
                        errorMessage="Enter end_date"
                        className="form-control"
                        validate={{ required: { value: true } }}
                        id="validationCustom02"
                        onChange={(e) => setEndDate(e.target.value)}
                      />
                    </div>
                  </Col>
                </Row>

                <div className="form-check mb-3">
                  <div className="invalid-feedback">
                    You must agree before submitting.
                  </div>
                </div>
                <Button color="primary" type="submit">
                  Submit form
                </Button>
              </AvForm> */}



 {/* <AvForm className="needs-validation" onSubmit={() => handleSubmit()}>
              <Row>
                <Col md="6">
                  <div className="mb-3">
                    <Label htmlFor="validationCustom01" value={start_date}>start_date</Label>
                    <AvField
                      name="start_date"
                      placeholder="start_date"
                      type="date"
                      errorMessage="Enter start_date"
                      className="form-control"
                      validate={{ required: { value: true } }}
                      id="validationCustom01"
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                </Col>
                <Col md="6">
                  <div className="mb-3">
                    <Label htmlFor="validationCustom02" value={end_date}>end_date</Label>
                    <AvField
                      name="end_date"
                      placeholder="end_date"
                      type="date"
                      errorMessage="Enter end_date"
                      className="form-control"
                      validate={{ required: { value: true } }}
                      id="validationCustom02"
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                  </div>
                </Col>
              </Row>

              <div className="form-check mb-3">
                <div className="invalid-feedback">
                  You must agree before submitting.
                </div>
              </div>
              <Button color="primary" type="submit">
                Submit form
              </Button>
            </AvForm> */}