from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Profiles)
admin.site.register(Devices)
admin.site.register(BusinessModel)
admin.site.register(Contact)
admin.site.register(ContactFromBusiness)
admin.site.register( BusinessServices)
admin.site.register(BusinessWeekHours)
admin.site.register(HostMatches)
admin.site.register(HostInvitations)
admin.site.register(Team1Players)
admin.site.register(Team2Players)
admin.site.register(MatchRounds)
admin.site.register(PlayerRatings)
admin.site.register(FriendRequests)
admin.site.register(Notification)
admin.site.register(OnlineUsers)
# admin.site.register(MessageModel)
admin.site.register(MatchSummary)








