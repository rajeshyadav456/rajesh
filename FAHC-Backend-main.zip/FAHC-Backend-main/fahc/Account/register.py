from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
import os
import random


def generate_username(name):

    username = "".join(name.split(' ')).lower()
    if not get_user_model().objects.filter(username=username).exists():
        return username
    else:
        random_username = username + str(random.randint(0, 1000))
        return generate_username(random_username)


def register_social_user(user_id, email, name):
    filtered_user_by_email = get_user_model().objects.filter(email=email)

    if filtered_user_by_email.exists():
       
       return filtered_user_by_email[0]
    else:
        user = {'username': generate_username(name), 'email': email, 'password': make_password(os.environ.get('SOCIAL_SECRET'))}
        user = get_user_model().objects.create_user(**user)
        user.save()

        return user
