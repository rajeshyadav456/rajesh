from .serializers import (UsersSerializer,LoginSerializer,ChangePasswordSerializer, GoogleSocialAuthSerializer, FacebookSocialAuthSerializer,
                        ChangeUserPasswordSerializer,RegisterSerializer)
from .models import Users
from rest_framework import viewsets,generics, status
from django.contrib.auth import get_user_model
from rest_framework.response import Response
from django.contrib.auth.hashers import check_password, make_password
from rest_framework_simplejwt.tokens import RefreshToken
from django.utils import timezone
from rest_framework.views import APIView
from django.http import HttpResponse
from django.shortcuts import render
from django.core.mail import send_mail
from django.conf import settings
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from . import google, facebook, register
from django_filters import rest_framework as filters
from rest_framework.exceptions import AuthenticationFailed
from rest_framework.filters import SearchFilter
from HouseChurch.mypagination import CustomPageNumberPagination
import os
from rest_framework.permissions import IsAuthenticated, IsAuthenticatedOrReadOnly
from HouseChurch.models import Histories
import random
from datetime import timedelta
from django.utils import timezone
from django.contrib.auth import get_user_model
import redis
from rest_framework_simplejwt.tokens import RefreshToken
from django.db.models import Q

from django.contrib.auth.hashers import check_password

redis_host = os.environ.get("REDIS_HOST", "localhost")
redis_port = os.environ.get("REDIS_PORT", 6379)
redis_client = redis.Redis(host=redis_host, port=redis_port)
redis_client.set("example@admin.com", "123456", ex=300)


class UsersApi(viewsets.ModelViewSet):
    
    queryset = Users.objects.all().order_by('-date_joined')
    serializer_class = UsersSerializer
    pagination_class = CustomPageNumberPagination
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['status','date_joined', 'zipcode','archive']

    permission_classes = [IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        queryset = super().get_queryset()
        order_by = self.request.query_params.get('order_by')
        username = self.request.query_params.get('username', None)
        address = self.request.query_params.get('address', None)
        email = self.request.query_params.get('email', None)
        name = self.request.query_params.get('name')

        print(name,'=====')
        if name:
            name_parts = name.split(' ', 1)
            if len(name_parts) == 2:
                first_name, last_name = name_parts
                # Filter the queryset using Q objects to match either first name or last name
                queryset = queryset.filter(
                    Q(first_name__icontains=first_name) | Q(last_name__icontains=last_name)
                )
            else:
                # If there's only one part, assume it's the first name
                first_name = name_parts[0]
                last_name = name_parts[0]  # Use the same value for first_name and last_name
                queryset = queryset.filter(
                    Q(first_name__icontains=first_name) | Q(last_name__icontains=last_name)
                )
        if username:
            queryset = queryset.filter(username__icontains=username)
        if address:
            queryset = queryset.filter(address__icontains=address)
        if email:
            queryset = queryset.filter(email__icontains=email)
        if order_by:
            queryset = queryset.order_by(order_by)
        return queryset
    
    def retrieve(self, request, *args, **kwargs):
        if kwargs['pk'].isdigit():
            instance = self.get_object()
        else:
            instance = Users.objects.filter(slug= kwargs['pk']).first()
        if instance:
            serializer = UsersSerializer(instance, context={'request': request})
            return Response(serializer.data)
        else:
            return Response({'message': "Not Found"}, status=status.HTTP_400_BAD_REQUEST) 
          
    def create(self, request, *args, **kwargs):
        response = super().create(request)
        if response.status_code == 201:
            user = Users.objects.get(pk = response.data['id'])
            user.password = make_password(user.password)
            user.save()

        return response
        
    def update(self, request, *args, **kwargs):
        response = super().update(request)
        if response.status_code == 200:
            instance = self.get_object()
            instance.updated_at = timezone.now()
            instance.save()
            
        return response 
    





class LoginApi(generics.GenericAPIView):
    serializer_class = LoginSerializer

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.data
        email = data['email']
        password = data['password']
        social_type = data['social_type']
        social_id = data['social_id']

        try:
            if social_type:
                # Social login
                user, created = get_user_model().objects.get_or_create(email=email)
                user.last_login = timezone.now()
                user.social_type = social_type
                user.social_id = social_id
                user.save()
                token = str(RefreshToken.for_user(user))
                access = str(RefreshToken.for_user(user).access_token)

                return Response({
                    "user": UsersSerializer(user, context=self.get_serializer_context()).data,
                    "access": access,
                    "refresh": token,
                })
            else:
                # Regular login
                try:
                    user = get_user_model().objects.get(email=email)

                    if user.status:  # Check the status value
                        validate = check_password(password, user.password)
                      
                        if validate:
                            # Passwords match
                            user.last_login = timezone.now()
                            user.save()
                            token = str(RefreshToken.for_user(user))
                            access = str(RefreshToken.for_user(user).access_token)
                            return Response({
                                "user": UsersSerializer(user, context=self.get_serializer_context()).data,
                                "access": access,
                                "refresh": token,
                            })
                        else:
                            # Passwords don't match
                            content = {"detail": "password do not match"}
                            return Response(content, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        content1 = {'detail': 'Disabled user cannot log in'}
                        return Response(content1, status=status.HTTP_400_BAD_REQUEST)

                except get_user_model().DoesNotExist:
                    content = {"detail": "No active account found with the given credentials"}
                    return Response(content, status=status.HTTP_400_BAD_REQUEST)

        except get_user_model().DoesNotExist:
            content = {"detail": "No active account found with the given credentials"}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)


class ChangePasswordView(APIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = ChangePasswordSerializer
    
    def get_object(self, queryset=None):
        return self.request.user
    
    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        serializer = ChangePasswordSerializer(data=request.data)
        
        if serializer.is_valid():
            # Check old password
            old_password = serializer.data.get("old_password")
            new_password = serializer.data.get("new_password")
            
            if not self.object.check_password(old_password):
                return Response(
                    {"old_password": ["Your previous password is not correct"]},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            if old_password == new_password:
                return Response(
                    {"new_password": ["New password must be different from the old password"]},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            self.object.set_password(new_password)
            self.object.save()
            
            return Response(
                {"message": "Your password has been updated successfully!"},
                status=status.HTTP_204_NO_CONTENT
            )
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


def send_mail_to_all(request): 
    return HttpResponse("Sent Email Successfully...Check your mail please")


class GoogleSocialAuthView(generics.GenericAPIView):

    serializer_class = GoogleSocialAuthSerializer

    def post(self, request):
        """

        POST with "auth_token"

        Send an idtoken as from google to get user information

        """
        user_data = google.Google.validate(request.data['auth_token'])
        try:
            user_data['sub']
        except:
            return Response({'message': 'The token  is invalid or expired. Please login again.'}, status=status.HTTP_400_BAD_REQUEST)

        if user_data['aud'] != settings.GOOGLE_CLIENT_ID:

            raise AuthenticationFailed('Invalid Request')

        user_id = user_data['sub']
        email = user_data['email']
        name = user_data['name']

        user = register.register_social_user(
            user_id=user_id, email=email, name=name)
        token = str(RefreshToken.for_user(user))
        access = str(RefreshToken.for_user(user).access_token)
        return Response({
            "user": UsersSerializer(user, context=self.get_serializer_context()).data,
            "access": access,
            "refresh": token,
            })


class FacebookSocialAuthView(generics.GenericAPIView):

    serializer_class = FacebookSocialAuthSerializer

    def post(self, request):
        """
        POST with "auth_token"

        Send an access token as from facebook to get user information

        """
        auth_token = self.serializer_class(data=request.data['auth_token'])
        user_data = facebook.Facebook.validate(auth_token)

        try:
            user_id = user_data['id']
            email = user_data['email']
            name = user_data['name']
            user = register.register_social_user(
                user_id=user_id,
                email=email,
                name=name
            )
            token = str(RefreshToken.for_user(user))
            access = str(RefreshToken.for_user(user).access_token)
            return Response({
                "user": UsersSerializer(user, context=self.get_serializer_context()).data,
                "access": access,
                "refresh": token,
                })
        except Exception as identifier:

            return Response({'message': 'The token  is invalid or expired. Please login again.'}, status=status.HTTP_400_BAD_REQUEST)



@login_required
def home(request):
    return render(request, 'home.html')

class ChangeUserPasswordView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, queryset=None):
        return self.request.user

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        serializer = ChangeUserPasswordSerializer(data=request.data)

        if serializer.is_valid():
            # Check old password
            if self.object.is_superuser and self.object.is_active:
                user = Users.objects.get(email = serializer.data.get("email"))
                # set_password also hashes the password that the user will get
                user.set_password(serializer.data.get("new_password"))
                user.save()
                user_serializer = UsersSerializer(user).data,
                return Response(user_serializer, status=status.HTTP_204_NO_CONTENT)
            

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    

class UsersBulkActionApi(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        users = request.data["users"]
        action = request.data.get('action')

        if action == 'delete':
            Users.objects.filter(id__in=users).delete()
            Histories.objects.create(user_id=request.user, message=f"User Deleted by {request.user.first_name}")
            return Response({'message': 'Users deleted successfully.'})
        elif action == 'disable':
            Users.objects.filter(id__in=users).update(status=False,archive=False, updated_at=timezone.now())
            Histories.objects.create(user_id=request.user, message=f"Users disabled by {request.user.first_name}")
            return Response({'message': 'Users disabled successfully.'})
        elif action == 'enable':
    
            Users.objects.filter(id__in=users).update(status=True,archive=False, updated_at=timezone.now())
            Histories.objects.create(user_id=request.user, message=f"Users enabled by {request.user.first_name}")
            return Response({'message': 'Users enabled successfully.'})
        elif action == 'archive':
            Users.objects.filter(id__in=users).update(archive=True,status=False, updated_at=timezone.now())
            Histories.objects.create(user_id=request.user, message=f"Users archived by {request.user.first_name}")
            return Response({'message': 'Users archived successfully.'})
        else:
            return Response({'error': 'Invalid action.'}, status=status.HTTP_400_BAD_REQUEST)



def generate_otp():
    return str(random.randint(100000, 999999))


def send_otp_email(email, otp):
    subject = "OTP Verification"
    message =  f'Hii \nYour OTP is {otp} for email verification'
    from_email = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message, from_email, recipient_list)



class SendOtpApi(APIView):
    def post(self, request, *args, **kwargs):
        email = request.data.get('email')
        try:
            # Check if email already exists
            if Users.objects.filter(email=email).exists():
                return Response(
                    {"message": "User already exists with this email."},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            otp = generate_otp()
            redis_key = f'otp:{email}'
            redis_client.set(redis_key, otp)
            redis_client.expire(redis_key, timedelta(hours=3))  # Set the OTP expiration time to 3 hours

            send_otp_email(email, otp)

            expiration_time = timezone.now() + timedelta(hours=3)
            message = f"OTP sent successfully. Please check your email to validate your account. The OTP will expire in {expiration_time.strftime('%Y-%m-%d %H:%M:%S')}."

            return Response(
                {"message": message},
                status=status.HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"message": f"Error occurred while sending OTP. {str(e)}"},
                status=status.HTTP_400_BAD_REQUEST
            )




class ValidateOtpApi(APIView):

    def post(self, request, *args, **kwargs):
        email = request.data.get('email')
        otp = request.data.get('otp')
        try:
            redis_key = f'otp:{email}'
            stored_otp = redis_client.get(redis_key)

            if stored_otp and otp == stored_otp.decode('utf-8'):
                return Response({"message": "OTP is Validated"}, status=status.HTTP_200_OK) 
            else:
                return Response({"message": "Invalid OTP."}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response(
                {"message": f"Error occurred while validating OTP. {str(e)}"},
                status=status.HTTP_400_BAD_REQUEST
            )



class SocialRegisterView(APIView):
    def post(self, request):
        social_id = request.data.get("social_id", None)
        if social_id:
            try:
                user = Users.objects.get(social_id = social_id)
                return Response({"message": "User is already registered with this social Id"}, status=status.HTTP_400_BAD_REQUEST)
            except:
                return Response({"message": "User in Not Registered"}, status=status.HTTP_200_OK) 
        else:
            return Response({"message": "social_id is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        
class SocialLoginAPI(APIView):
    def post(self, request):
        social_id = request.data.get("social_id", None)
        try:
            user = Users.objects.get(social_id=social_id)
            token = str(RefreshToken.for_user(user))
            access = str(RefreshToken.for_user(user).access_token)
            return Response({
                "user": UsersSerializer(user).data,
                "access": access,
                "refresh": token,
            })
        except Users.DoesNotExist:
            return Response({"message": "Invalid social id"}, status=status.HTTP_400_BAD_REQUEST)

                
class RegisterUserAPI(APIView):
    serializer_class = RegisterSerializer
    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            social_id = serializer.validated_data.get("social_id")
            password = serializer.validated_data.get("password")
            if not social_id and not password:
                return Response(
                    {"message": "Please provide either social_id or password"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            else:
                user = serializer.save()
                user.status = True
                user.save()
                
                token = str(RefreshToken.for_user(user))
                access = str(RefreshToken.for_user(user).access_token)

                return Response({
                    "user": UsersSerializer(user).data,
                    "access": access,
                    "refresh": token,
                })
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        

