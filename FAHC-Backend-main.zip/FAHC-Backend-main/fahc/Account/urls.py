from django.urls import path, include
from .views import (UsersApi, LoginApi, ChangePasswordView, GoogleSocialAuthView, FacebookSocialAuthView, 
                    SendOtpApi,ChangeUserPasswordView, UsersBulkActionApi,ValidateOtpApi,SocialRegisterView,RegisterUserAPI,SocialLoginAPI)
from rest_framework import routers
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from django_rest_passwordreset.views import (ResetPasswordValidateTokenViewSet, ResetPasswordConfirmViewSet, 
                                            ResetPasswordRequestTokenViewSet)
from . import views
from django.contrib.auth import views as auth_views
router = routers.DefaultRouter()

router.register(r'users', UsersApi, basename='users')
router.register(
    r'passwordreset/validate_token',
    ResetPasswordValidateTokenViewSet,
    basename='reset-password-validate'
)
router.register(
    r'passwordreset/confirm',
    ResetPasswordConfirmViewSet,
    basename='reset-password-confirm'
)
router.register(
    r'passwordreset',
    ResetPasswordRequestTokenViewSet,
    basename='reset-password-request'
)
router.register(
    r'forgot-password/passwordreset/validate_token',
    ResetPasswordValidateTokenViewSet,
    basename='forgot-password-validate'
)
router.register(
    r'forgot-password/passwordreset/confirm',
    ResetPasswordConfirmViewSet,
    basename='forgot-password-confirm'
)
router.register(
    r'forgot-password/passwordreset',
    ResetPasswordRequestTokenViewSet,
    basename='forgot-password'
)
urlpatterns = [
    path('', include(router.urls)),
    path('login/', LoginApi.as_view()),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('change-password/', ChangePasswordView.as_view(), name='change-password'),
    path('password_reset/', include('django_rest_passwordreset.urls', namespace='password_reset')),
    path('sendmail/', views.send_mail_to_all, name="sendmail"),
    path('users-bulk-action/', UsersBulkActionApi.as_view(), name='users-bulk-action'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('social-auth/', include('social_django.urls', namespace='social')),
    path("home/", views.home, name='home'),
    path('google/', GoogleSocialAuthView.as_view()),
    path('facebook/', FacebookSocialAuthView.as_view()),
    path('change-user-password/', ChangeUserPasswordView.as_view(), name='change-user-password'),
    path('send-otp/', SendOtpApi.as_view(), name='send-otp'),
    path('validate-otp/', ValidateOtpApi.as_view(), name='validate-otp'),
    path('social-register/', SocialRegisterView.as_view(), name='social_register'),
    path('social-login/', SocialLoginAPI.as_view(), name='social_login'),
    path('register/', RegisterUserAPI.as_view(), name='register'),
]

