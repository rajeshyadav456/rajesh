from rest_framework import serializers
from .models import  Users
from django.contrib.auth.password_validation import validate_password
from . import google, facebook
from HouseChurch.method import Base64ImageField
from django.conf import settings


class UsersSerializer(serializers.ModelSerializer):
    image = Base64ImageField(required=False)
    class Meta:
        model = Users
        fields = ["id",
            "is_superuser", "first_name", "last_name", "is_staff", "is_active", "date_joined", "username",
            "email", "role", "status", "address", "phone", "city", "state", "zipcode", "flag", "image", "company",
            "website", "about", "fb", "insta", "twitter", "gallery", "videos", "latitude", "longitude",
            "affilate_id", "remember_token", "last_login", "social_type", "social_id", 'archive', 'slug',
        ]
        extra_kwargs = {
            'email':{'read_only': True},
            'social_type':{'required':False},
            'social_id':{'required':False},
        }
    def create(self, validated_data):
        image = validated_data.pop('image', None)
        user_image = Users.objects.create( **validated_data, image=image)
        return user_image
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url
        return representation
    
    
class UserShortDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = ['id', 'first_name', 'last_name', 'image','email','address','city','zipcode','state','slug']
  


    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url
        return representation

    
class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(max_length=200, required=False, allow_null=True)
    social_type = serializers.CharField(max_length=20, required=False, allow_null=True)
    social_id = serializers.CharField(max_length=225, required=False, allow_null=True)


class RegisterSerializer(serializers.ModelSerializer):
    image = Base64ImageField(required=False)
    class Meta:
        model = Users
        fields = (
            'id', 'email', 'password', 'first_name', 'last_name', 'phone',
            'address', 'zipcode', 'city', 'state', 'about', 'image','social_type','social_id'
        )
        extra_kwargs = {
            'password': {'required': False, 'allow_blank': True, 'allow_null': True},
        }
    def create(self, validated_data):
        image = validated_data.pop('image', None)
        user_image = Users.objects.create( **validated_data, image=image)
        return user_image
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url
        return representation

class ChangePasswordSerializer(serializers.Serializer):
    model = Users

    """
    Serializer for password change endpoint.
    """
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    def validate_new_password(self, value):
            validate_password(value)
            return value



class FacebookSocialAuthSerializer(serializers.Serializer):
    """Handles serialization of facebook related data"""
    auth_token = serializers.CharField()
        


class GoogleSocialAuthSerializer(serializers.Serializer):
    auth_token = serializers.CharField()


class ResetPasswordViaEmailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = ( 'id', 'username', 'first_name', 'last_name', 'email', 'date_joined', 'password','role', 'last_login','is_active',
                    )
        read_only_fields = ['is_active']
        extra_kwargs = {
            'first_name':{'required':False},
            'last_name':{'required':False},
            'email':{'required':True},
            'password':{'required':False},
            'role': {'required': True},
            # 'password':{'write_only': True},
            'id':{'read_only': True},

        }  

class ChangeUserPasswordSerializer(serializers.Serializer):
    email = serializers.CharField(max_length=200, required=True)
    new_password = serializers.CharField(max_length=200,required=True)


class SocialLoginSerializer(serializers.Serializer):
    social_id = serializers.CharField()