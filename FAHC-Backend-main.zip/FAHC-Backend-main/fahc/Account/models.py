from django.db import models
from django.contrib.auth.models import AbstractUser
from .manager import UserManager
from django.dispatch import receiver
from django.urls import reverse
from django_rest_passwordreset.signals import reset_password_token_created
from django.core.mail import send_mail  
from django.conf import settings
from django.utils.text import slugify
from django.utils.crypto import get_random_string




    
class Users(AbstractUser):

    username = models.CharField(unique=True, max_length=225, blank=True, null=True)
    email = models.EmailField(unique=True)
    role = models.CharField(max_length=50, default="",  blank=True, null=True)
    status =  models.BooleanField(default=False)
    address = models.CharField(max_length=255, default="",  blank=True, null=True)
    phone = models.CharField(max_length=255, default="",  blank=True, null=True)
    city=models.CharField(max_length=255, default="", blank=True, null=True)
    state=models.CharField(max_length=255, default="", blank=True,null=True)
    zipcode=models.CharField(max_length=255, default="", blank=True, null=True)
    flag = models.IntegerField(blank=True,null=True)
    image = models.ImageField(upload_to='profile',blank=True, null=True,)
    company = models.CharField(max_length=255, default="",  blank=True, null=True)
    website = models.CharField(max_length=255, default="",  blank=True, null=True)
    about = models.TextField( default="", null=True,blank=True)
    fb = models.CharField(max_length=255, default="", blank=True, null=True)
    insta = models.CharField(max_length=255, default="", blank=True, null=True)
    twitter = models.CharField(max_length=255, default="", blank=True, null=True)
    gallery = models.CharField(max_length=255, default="", blank=True, null=True)
    videos = models.CharField(max_length=255, default="", blank=True, null=True)
    latitude = models.CharField(max_length=255, default="", blank=True, null=True)
    longitude = models.CharField(max_length=255, default="", blank=True, null=True)
    affilate_id = models.CharField(max_length=255, default="", blank=True, null=True)
    remember_token = models.CharField(max_length=255, default="", blank=True, null=True)
    archive = models.BooleanField(default=False)
    social_type = models.CharField(max_length=20, default="", blank=True, null=True)
    social_id = models.CharField(unique= True, max_length=255, default="", blank=True, null=True)
    slug = models.SlugField(max_length=255, unique=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)
    otp = models.CharField(max_length=6, default="", blank=True, null=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
    objects = UserManager()

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.first_name) + get_random_string(10)
            while Users.objects.filter(slug=self.slug).exists():
                self.slug = slugify(self.first_name) + get_random_string(10)
        super().save(*args, **kwargs)



