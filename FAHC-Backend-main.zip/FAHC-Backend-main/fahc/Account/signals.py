from django.template.loader import get_template
from django.core.mail import EmailMessage
from django_rest_passwordreset.signals import reset_password_token_created
from django.conf import settings
from django.dispatch import receiver



@receiver(reset_password_token_created)
def password_reset_token_created(sender, instance, reset_password_token, *args, **kwargs):

    context = {
        "url": f"https://dev.findahousechurch.com/password-reset/{reset_password_token.key}"
    }
    message = get_template('restet_password.html').render(context)

    msg = EmailMessage(
        subject="FAHC Reset Password",
        body=message,
        from_email=f"FAHC Admin <{settings.EMAIL_HOST_USER}>",
        to=[reset_password_token.user.email],
        )
    msg.content_subtype = "html"
    msg.send()


@receiver(reset_password_token_created)
def password_reset_token_created(sender, instance, reset_password_token, *args, **kwargs):

    # reset_password_url =
    context = {
        "url": f"https://app.findahousechurch.com/password-reset/{reset_password_token.key}"
    }
    message = get_template('dashpasswordreset.html').render(context)

    msg = EmailMessage(
        subject="FAHC Reset Password",
        body=message,
        from_email=f"FAHC Admin <{settings.EMAIL_HOST_USER}>",
        to=[reset_password_token.user.email],
        )
    msg.content_subtype = "html"
    msg.send()