from django.contrib import admin
from .models import Users
from django.contrib.auth.admin import UserAdmin
from django.utils.translation import gettext_lazy as _


 

#     affilate_id = models.CharField(max_length=255, default="", blank=True, null=True)
#     remember_token = models.CharField(max_length=255, default="", blank=True, null=True)
@admin.register(Users)
class CustomUserAdmin(UserAdmin):
    """Define admin model for custom User model with no username field."""
    fieldsets = (
        (None, {'fields': ('email','password')}),
        (_('Personal info'), {'fields': ('username','first_name', 'last_name', 'phone','address','city','state', 'zipcode',   
                                        'company', 'about')}),
        (_('Social info'), {'fields': ('website','fb','insta', 'twitter',)}),
        (_('Location info'), {'fields': ('latitude','longitude',)}),
        (_('Permissions'), {'fields': ('is_active', 'is_staff', 'is_superuser','role','status','flag',
                                       'groups', 'user_permissions')}),
        (_('Important dates'), {'fields': ('last_login', 'date_joined')}),
        (_('Media'), {'fields': ('image', 'gallery', 'videos')}),
        (_('Other'), {'fields': ('affilate_id', 'remember_token')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username','email',  'password1', 'password2'),
        }),
    )
    list_display = ('username','email', 'first_name', 'last_name', 'is_staff')
    search_fields = ('username','email', 'first_name', 'last_name')
    ordering = ('username',)
    
    pass
