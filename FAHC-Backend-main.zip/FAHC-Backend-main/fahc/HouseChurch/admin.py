from django.contrib import admin
from .models import *




admin.site.register(Churches)
admin.site.register(Contacts)
admin.site.register(Denominations)
admin.site.register(Downloadcounts)
admin.site.register(House_church)
admin.site.register(Events)
admin.site.register(Favourites)
admin.site.register(Histories)
admin.site.register(Joinhouses)
admin.site.register(Reports)
admin.site.register(Galleries)
# admin.site.register(HouseChurchMember)
admin.site.register(Audio)
admin.site.register(Attendees)
admin.site.register(Discussion)
admin.site.register(HouseChurchMember)
admin.site.register(EventMembers)
admin.site.register(LocationPage)
admin.site.register(LocationPageContent)
admin.site.register(EventMessage)
admin.site.register(Post)