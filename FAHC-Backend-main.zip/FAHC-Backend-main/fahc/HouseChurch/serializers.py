from rest_framework import serializers
from .models import  *
from Account.serializers import UserShortDetailSerializer
from .method import Base64ImageField,Base64AudioField
from django.conf import settings
from rest_framework.pagination import PageNumberPagination
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from datetime import date
from django.core.files.base import ContentFile

class CustomPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100

class SenderdetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = ['id','image','email','first_name', 'last_name']

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url
        return representation
    
class ChurchesSerializer(serializers.ModelSerializer):
    image = Base64ImageField(required=False)
    class Meta:
        model = Churches
        fields = ['id','name','address','city','state','zipcode','image']
        extra_kwargs = {
            'loc_dst': {'required': False},
            'image': {'required': False},
        }
    def create(self, validated_data):
        image = validated_data.pop('image', None)
        church_image = Churches.objects.create( **validated_data, image=image)
        return church_image
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url   
        return representation  
    
class listChurchesSerializer(serializers.ModelSerializer):
    image = Base64ImageField(required=False)
    class Meta:
        model = Churches
        fields = "__all__"

    def create(self, validated_data):
        image = validated_data.pop('image', None)
        church_image = Churches.objects.create( **validated_data, image=image)
        return church_image
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url 
        if instance.denomination_id:
            representation['denomination_id'] = DenomShortSerializer(instance.denomination_id, context={'request': self.context['request']}).data  
        return representation  

class ChurchShortSerializer(serializers.ModelSerializer):
    class Meta:
        model = Churches
        fields= ['id','name']

class ContactsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contacts
        fields = "__all__"


class DenominationsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Denominations
        fields = "__all__"

class DenomShortSerializer(serializers.ModelSerializer):
    class Meta:
        model= Denominations
        fields = ['id','name']

class DownloadcountsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Downloadcounts
        fields = "__all__"

class EventsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Events
        fields = "__all__"

class FavouritesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Favourites
        fields = "__all__"

class HistoriesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Histories
        fields = "__all__"

class LocationPageSerializer(serializers.ModelSerializer):
    image = Base64ImageField(required=False)
    class Meta:
        model=LocationPage
        fields="__all__"
        extra_kwargs = {
            'location': {'required': False},
   
        }
    def create(self, validated_data):
        image = validated_data.pop('image', None)
        user_image = LocationPage.objects.create( **validated_data, image=image)
        return user_image
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url
        
        if instance.location:
            location_serializer = LocationSerializer(instance.location, context={'request': self.context['request']})
            representation['location'] = location_serializer.data
        return representation

class LocationPageContentSerializer(serializers.ModelSerializer):
    class Meta:
        model=LocationPageContent
        fields="__all__"

class EventMemberSerializer(serializers.ModelSerializer):
    user= serializers.SerializerMethodField()   
    class Meta:
        model = EventMembers
        fields = "__all__"

    def get_user(self,obj):
        try:
            user= Users.objects.get(email = obj.user_email)
            return UserShortDetailSerializer(user).data
        except:
            return None
 
class HouseMemberSerializer(serializers.ModelSerializer): 
    user= serializers.SerializerMethodField() 
    class Meta:
        model = HouseChurchMember
        fields = ['id','type','user_email','user','message']

     
    def get_user(self,obj):
        try:
            user= Users.objects.get(email = obj.user_email)
            return UserShortDetailSerializer(user, context={'request': self.context['request']}).data
        except:
            return None
class DashHouseMemberSerializer(serializers.ModelSerializer): 
    user= serializers.SerializerMethodField()
    def validate(self, attrs):
        
        return super().validate(attrs) 
    class Meta:
        model = HouseChurchMember
        fields = "__all__"

     
    def get_user(self,obj):
        try:
            user= Users.objects.get(email = obj.user_email)
            return UserShortDetailSerializer(user, context={'request': self.context['request']}).data
        except:
            return None
from django.utils import timezone
         
class House_churchSerializer(serializers.ModelSerializer):
    image = Base64ImageField(required=False)  
    events = serializers.SerializerMethodField()
    class Meta:
        model = House_church
        fields = ['id',  'church_id', 'user_id', 'slug', 'address', 'city', 'state', 'zipcode',
                  'name', 'denomination_id', 'type', 'days', 'time', 'info', 'flag', 'special_inst', 'image',
                  'gallery', 'videos', 'status', 'latitude', 'longitude', 'created_at', 'updated_at','archive',
                  'events']
        extra_kwargs = {
            'user_id': {'required': False},
            'image': {'required': False},
        }



    def get_events(self, obj):
        events = obj.events.all()  # Retrieve all events of the house church
        serializer = EventsSerializer(
            events,
            many=True,
            context=self.context  
        )
        return serializer.data

    def create(self, validated_data):
        image = validated_data.pop('image', None)
        user_id = validated_data.pop('user_id')
        events_data = validated_data.pop('events', [])  
        house_church = House_church.objects.create(user_id=user_id, **validated_data, image=image)
        for event_data in events_data:
            Events.objects.create(house_church=house_church, **event_data)
        return house_church
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        special_inst_value = representation.get('special_inst')
        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url
        
        if special_inst_value == "1":
            representation['special_inst'] = "Adult Gathering Only"
        elif special_inst_value == "2":
            representation['special_inst'] = "Childcare Provided"
        elif special_inst_value == "3":
            representation['special_inst'] = "Kid Friendly - No Childcare Provided"
        
        return representation
    

class HouseChurchDetailSerializer(serializers.ModelSerializer):
    house_members = serializers.SerializerMethodField()
    events = serializers.SerializerMethodField()
    posts = serializers.SerializerMethodField()    
    class Meta:
        model = House_church
        fields = ['id','church_id', 'user_id', 'slug', 'address', 'city', 'state', 'zipcode', 'name', 'denomination_id',
                  'type', 'days', 'time', 'info', 'flag', 'special_inst', 'image', 'gallery', 'videos', 'status',
                  'latitude', 'longitude', 'created_at', 'updated_at','posts','house_members', 'events']
        extra_kwargs = {
            'user_id': {'required': False,},
            'image': {'required': False},
        }

    def get_posts(self, house_church):
        # Fetch the recent posts related to the provided house church
        recent_posts = Post.objects.filter(event_id__house_id=house_church).order_by('-created_at')[:10]
        return EventPostSerializer(recent_posts, many=True, context=self.context).data


    def get_house_members(self, obj):
        members = HouseChurchMember.objects.filter(house_id=obj.id)
        serializer = HouseMemberSerializer(
            members,
            many=True,
            context=self.context
        )
        return serializer.data

    def get_events(self, obj):
        events = obj.events.all()  # Retrieve all events of the house church
        serializer = EventsSerializer(
            events,
            many=True,
            context=self.context  
        )
        return serializer.data


    
    def to_representation(self, instance):
        data = super().to_representation(instance)
        if instance.denomination_id:
            data['denomination_id'] = DenomShortSerializer(instance.denomination_id, context={'request': self.context['request']}).data
        if instance.church_id:
            data['church_id'] = ChurchShortSerializer(instance.church_id, context={'request': self.context['request']}).data
        data['user_id'] = UserShortDetailSerializer(instance.user_id, context={'request': self.context['request']}).data
        if instance.special_inst == "1":
            data['special_inst'] = "Adult Gathering Only"
        elif instance.special_inst == "2":
            data['special_inst'] = "Childcare Provided"
        elif instance.special_inst == "3":
            data['special_inst'] = "Kid Friendly - No Childcare Provided"
        return data
    
class HouseChurchShortDetailSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = House_church
        fields = ['id','slug', 'name',]
    
class JoinhousesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Joinhouses
        fields = "__all__"


class EventsSerializer(serializers.ModelSerializer):
    image = Base64ImageField(required=False)
    house_name = serializers.CharField(source='house_id.name', read_only=True)
    event_members = EventMemberSerializer(many=True, read_only=True) 
    class Meta:
        model = Events
        fields = ['id','house_id','user_id','slug','name','desc','image','address','city','state','zipcode','type','start','end','monthly_date',
                  'day','time','created_at','updated_at','house_name','event_members']
        extra_kwargs = {
            'house_id': {'required': False,},
        }
         
    def create(self, validated_data):
        image = validated_data.pop('image', None)
        event_image = Events.objects.create( **validated_data, image=image)
        return event_image

    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        
        # Filter event members based on status="accepted"
        accepted_members = instance.event_members.filter(status="accepted")
        event_member_serializer = EventMemberSerializer(accepted_members, many=True, read_only=True)
        representation['user_id'] = UserShortDetailSerializer(instance.user_id).data

        representation['event_members'] = event_member_serializer.data

        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url
        return representation
      
class EventsDetailSerializer(serializers.ModelSerializer):
    image = Base64ImageField(required=False)
    house_name = serializers.CharField(source='house_id.name', read_only=True)
    event_members = EventMemberSerializer(many=True, read_only=True) 
    posts = serializers.SerializerMethodField()
    class Meta:
        model = Events
        fields = ['id','house_id','user_id','slug','name','desc','image','address','city','state','zipcode','type','start','end','monthly_date',
                  'day','time','created_at','updated_at','house_name','event_members','posts']
        extra_kwargs = {
            'house_id': {'required': False,},
            'user_id': {'required': False,},
        }

    def get_posts(self, instance):
        posts = Post.objects.filter(event_id=instance.id)
        posts_serializer = EventPostSerializer(posts, many=True)  
        return posts_serializer.data
         
    def create(self, validated_data):
        image = validated_data.pop('image', None)
        event_image = Events.objects.create( **validated_data, image=image)
        return event_image
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        
        # Filter event members based on status="accepted"
        accepted_members = instance.event_members.filter(status="accepted")
        event_member_serializer = EventMemberSerializer(accepted_members, many=True, read_only=True)
        representation['user_id'] = UserShortDetailSerializer(instance.user_id, context={'request': self.context['request']}).data

        representation['event_members'] = event_member_serializer.data

        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url
        return representation  

class GallerySerializer(serializers.ModelSerializer):
    photo = Base64ImageField()
    class Meta:
        model = Galleries
        fields = "__all__"

    def create(self, validated_data):
        photo = validated_data.pop('photo')
        user_id = validated_data.get('user_id') 
        gallery = Galleries.objects.create(user_id=user_id, **validated_data, photo=photo)
        return gallery
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.photo:
            representation['photo'] = settings.SITE_DOMAIN + instance.photo.url   
        return representation



class AttendeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attendees
        fields = ['id','type','user_id','event_id','created_at','updated_at']
        extra_kwargs = {
            'event_id': {'required': False,},
        }

class AudioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Audio
        fields = "__all__"

class DiscussionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Discussion
        fields = "__all__"


class ZipRadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ziprad
        fields = "__all__"
        
        

class EventInvitationSerializer(serializers.Serializer):
    event_name = serializers.CharField()
    house_church_name = serializers.CharField()
    event_owner_name = serializers.CharField()
    user_email = serializers.EmailField()

# from drf_extra_fields.fields import Base64ImageField

class EventBulkSerializer(serializers.Serializer):
    image = Base64ImageField(required=False)
    name = serializers.CharField(max_length=225)
    desc = serializers.CharField(max_length=225)
    user_id = serializers.CharField(max_length=225)
    house_id =serializers.CharField(max_length=225)
    start = serializers.CharField(max_length=225)
    end = serializers.CharField(max_length=225)
    time = serializers.CharField(max_length=225)
    type = serializers.CharField(max_length=225)
    monthly_date = serializers.CharField(max_length=225)
    day = serializers.CharField(max_length=225)

    def create(self, validated_data):
        image = validated_data.pop('image', None)
        event_image = Events.objects.create( **validated_data, image=image)
        return event_image
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url   
        return representation  
    


class dashhousechurchSerializer(serializers.ModelSerializer):
    image = Base64ImageField(required=False) 
    class Meta:
        model= House_church
        fields = "__all__"

    def create(self, validated_data):
        image = validated_data.pop('image', None)
        dash_image = House_church.objects.create( **validated_data, image=image)
        return dash_image
    
    def to_representation(self, instance):
        data = super().to_representation(instance)
        if instance.image:
            data['image'] = settings.SITE_DOMAIN + instance.image.url
        if instance.denomination_id:
            data['denomination_id'] = DenomShortSerializer(instance.denomination_id, context={'request': self.context['request']}).data
        if instance.church_id:
            data['church_id'] = ChurchShortSerializer(instance.church_id, context={'request': self.context['request']}).data
        data['user_id'] = UserShortDetailSerializer(instance.user_id, context={'request': self.context['request']}).data
        if instance.special_inst == "1":
            data['special_inst'] = "Adult Gathering Only"
        elif instance.special_inst == "2":
            data['special_inst'] = "Childcare Provided"
        elif instance.special_inst == "3":
            data['special_inst'] = "Kid Friendly - No Childcare Provided"
        return data
    

class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model= Notification
        fields = "__all__"

class ActivitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Activity
        fields = "__all__"


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = "__all__"


class ReportsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reports
        fields = "__all__"
    def to_representation(self, instance):
        data = super().to_representation(instance)
        if instance.house_id:
            data['house_id'] = HouseChurchShortDetailSerializer(instance.house_id, context={'request': self.context['request']}).data
        if instance.profile:
            data['profile'] = UserShortDetailSerializer(instance.profile, context={'request': self.context['request']}).data
        data['user_id'] = UserShortDetailSerializer(instance.user_id, context={'request': self.context['request']}).data
        return data


class ConversationSerializer(serializers.ModelSerializer):
   
    class Meta:
        model = Conversation
        fields = "__all__"


class ChatSerializer(serializers.ModelSerializer):
   
    class Meta:
        model = Chat
        fields = "__all__"
    

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['sender'] = UserShortDetailSerializer(instance.sender, context={'request': self.context['request']}).data
        data['receiver'] = UserShortDetailSerializer(instance.receiver, context={'request': self.context['request']}).data
        return data


class StateSerializer(serializers.ModelSerializer):
    class Meta:
        model = State
        fields = "__all__"

class CountySerializer(serializers.ModelSerializer):
    class Meta:
        model = County
        fields = "__all__"
    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['state'] = StateSerializer(instance.state, context={'request': self.context['request']}).data
        return data

class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Location
        fields = "__all__"
    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['county'] = CountySerializer(instance.county, context={'request': self.context['request']}).data
        return data

class ShortHouseSerializer(serializers.ModelSerializer):
    class Meta:
        model = House_church
        fields= ['id','user_id','slug','zipcode','image','name','type','created_at']

class EventMessageSerializer(serializers.ModelSerializer):
    event_name = serializers.SerializerMethodField()
    recipient = SenderdetailSerializer(read_only=True)
    sender = SenderdetailSerializer(source='user_id', read_only=True)  

    class Meta:
        model = EventMessage
        fields = ['id', 'event_message','title', 'created', 'type', 'event_id','event_name', 'sender', 'recipient']
        read_only_fields = ['type'] 
    def get_event_name(self, instance):
        if instance.event_id:
            return instance.event_id.name
        return None

    
    def to_representation(self, instance):
        data = super().to_representation(instance)        
        if instance.receipt_user:
            data['recipient'] = SenderdetailSerializer(instance.receipt_user).data       
        return data
    


class MetaContentSerializers(serializers.ModelSerializer):
    image = Base64ImageField(required=False)
    class Meta:
        model = MetaContent
        fields= "__all__"
        extra_kwargs = {
            'image': {'required': False},
   
        }

    def create(self, validated_data):
        image = validated_data.pop('image', None)
        user_image = MetaContent.objects.create( **validated_data, image=image)
        return user_image
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url
        return representation

class EventPostSerializer(serializers.ModelSerializer):
    replies = serializers.SerializerMethodField()
    audio = Base64AudioField(required=False)
    image = Base64ImageField(required=False)
    class Meta:
        model = Post
        fields = ['id', 'user', 'parent', 'message', 'event_id', 'video_link','audio', 'image','created_at','updated_at','replies']
        extra_kwargs = {
            'audio': {'required': False},
            'image': {'required': False},
            'message': {'required': False},
        }
    def create(self, validated_data):
        user = self.context['request'].user
        audio = validated_data.pop('audio', None)
        image = validated_data.pop('image', None)
      
        post = Post.objects.create(user=user, **validated_data, audio=audio, image=image)
        return post
    def get_replies(self, instance):
        replies_queryset = Post.objects.filter(parent=instance.id)
        replies_serializer = EventPostSerializer(replies_queryset, many=True)
        return replies_serializer.data    

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.parent:
            representation.pop('event_id',None)
        if instance.image:
            representation['image'] = settings.SITE_DOMAIN + instance.image.url
        if instance.audio:
            representation['audio'] = settings.SITE_DOMAIN + instance.audio.url
        representation['user'] = SenderdetailSerializer(instance.user).data
        return representation   
    
