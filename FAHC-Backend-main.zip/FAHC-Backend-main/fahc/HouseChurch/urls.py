from django.urls import path, include
from .views import *
from rest_framework import routers
router = routers.DefaultRouter()

router.register(r'house-members', HouseMemberList,basename='house-members-list')
router.register(r'dash-house-members', DeshHouseMemberList,basename='dash-house-members-list')
router.register(r'churches', ChurchessApi,basename='house-church-churches')
router.register(r'dash-list-house_church', DashHouseChurchsApi,basename='dash-list-house_church')
router.register(r'dash_list_churches', ListChurchessApi,basename='dash_list_churches')
router.register(r'contracts', ContactsApi,basename='house-church-contracts')
router.register(r'denominations', DenominationsApi,basename='house-church-denominations')
router.register(r'downloadcounts', DownloadcountsApi,basename='house-church-downloadcounts')
router.register(r'favourites', FavouritesApi,basename='house-church-favourites')
router.register(r'histories', HistoriesApi,basename='house-church-histories')
router.register(r'house-church', HousesApi,basename='house-church')
router.register(r'joinhouses', JoinhousesApi,basename='house-church-joinhouses')
router.register(r'attendees', AttendeesAPI,basename='house-church-attendees')
router.register(r'gallaries', GalleryAPI,basename='gallaries')
router.register(r'audio', AudioAPI,basename='audio')
router.register(r'discussion', DiscussionAPI,basename='discussion')
router.register(r'events', EventsAPI,basename='events')
router.register(r'notification', NotificationAPI,basename='notification')
router.register(r'ziprad', ZipRadAPI,basename='ziprad')
router.register(r'event-members', EventMemberAPI,basename='event-members')
router.register(r'activity', ActivityApi,basename='activity')
router.register(r'category', CategoryAPI,basename='category')
router.register(r'reports', RepotsAPI,basename='reports')
router.register(r'post', EventPostAPI,basename='post')
# router.register(r'get-eventcomment', GetEventCommentAPI,basename='get-eventcomment')
# router.register(r'conversation', ConversationAPI,basename='conversation')
# router.register(r'chats', ChatAPI,basename='chats')
router.register(r'state', StateViewSet,basename='state')
router.register(r'county', CountyViewSet,basename='county')
router.register(r'location', LocationViewSet,basename='location')
router.register(r'locationpage',LocationPageAPi,basename='locationpage')
router.register(r'locationpagecontent',LocationPageContentApi,basename='locationpagecontent')
router.register(r'event-messages', EventMessageViewSet,basename='event-messages')
router.register(r'meta-content', MetaContentAPI,basename='meta-content')
router.register(r'events-userslist', EventOwnerUserListViewSet, basename='events-userslist')
router.register(r'event-user-chat', EventuserChatList, basename='event-user-chat')



urlpatterns = [
    path('', include(router.urls)),
    path('index', index,name='index'),
    path('search/',search_house_church, name='search'),
    # path('get_conversations/', GetConversationAPI.as_view(), name='conversation-detail'),
    path('send-event-invitation/', SendInvitationAPI.as_view(), name='send_invitation'),
    path('request-to-join/', RequestToJoinEventAPI.as_view(), name='request-to-join'),
    path('accecpt-reject-api/', AcceptRejectRequestAPI.as_view(), name='request-to-join'),
    path('create_event_bulk/', EventBulkAPIView.as_view(), name='create_event_bulk'),
    path('search-house_church/', SearchHouseChurchAPI.as_view(), name='search-house_church'),
    path('denominations-bulk-action/', DenominationsBulkActionApi.as_view(), name='denominations-bulk-action'),
    path('churches-bulk-action/', ChurchesBulkActionApi.as_view(), name='churches-bulk-action'),
    path('house-churches-bulk-action/', HousesChurchesBulkActionApi.as_view(), name='house-churches-bulk-action'),
    path('house_churches/<int:house_church_id>/upcoming-events/', HouseChurchEventsAPI.as_view({'get': 'retrieve_upcoming_events'}), name='house-church-upcoming-events'),
    path('house_churches/<int:house_church_id>/past-events/', HouseChurchEventsAPI.as_view({'get': 'retrieve_past_events'}), name='house-church-past-events'),
    path('events-by-zipcode/', EventsByZipcodeAPI.as_view(), name='events-by-zipcode'),
    path('housechurch-by-zipcode/', HouseChurchByZipcodeAPI.as_view(), name='housechurch-by-zipcode'),
    path('follow-housechurch/', FollowHouseChurchAPIView.as_view(), name='follow-housechurch'),
    path('change-event-member-type/', ChangeEventMemberTypeAPI.as_view(), name='change_event_member_type'),
    path('change-house-member-type/', ChangeHouseChurchMemberTypeAPI.as_view(), name='change_house_member_type'),
    path('reports-bulk-action/', ReportsBulkActionApi.as_view(), name='reports-bulk-action'),
    path('dashboard-data/', DashboardDataAPI.as_view(), name='dashboard-data'),
    path('update-location-meta/', UpdateLocationPageMetaView.as_view(), name='update-location-meta'),

]