from math import sin, cos, sqrt, atan2, radians
from django.template.defaultfilters import slugify
from botocore.exceptions import NoCredentialsError
from django.conf import settings
import random
import boto3
import os
import requests
import datetime
# from geopy.geocoders import Nominatim

def get_distance_from_two_location(latitude1, longitude1, latitude2, longitude2):
    '''Function take two location's latitude and longitude as params
    and return distance from one location to another in miles'''

    # approximate radius of earth in miles
    R = 3960.0
    lat1 = radians(float(latitude1))
    lon1 = radians(float(longitude1))
    lat2 = radians(float(latitude2))
    lon2 = radians(float(longitude2))

    dlon = lon2 - lon1
    dlat = lat2 - lat1

    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))

    distance = R * c

    return float(f"{distance:.2f}")


def getSlug(name, houseChurch):

    slug = slugify(name)
    if not houseChurch.filter(slug = slug).exists():
        return slug
    else:
        slug = slug + str(random.randint(0, 1000))
        return getSlug(slug, houseChurch)
    


def upload_to_aws(local_file, bucket, s3_file):
    s3 = boto3.client('s3', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                      aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY)

    try:
        s3.upload_file(local_file, bucket, Key=s3_file, ExtraArgs={'ACL': 'public-read'})
        return True
    except FileNotFoundError:
        print("The file was not found")
        return False
    except NoCredentialsError:
        print("Credentials not available")
        return False

def delete_from_aws( bucket, s3_file):
    s3 = boto3.client('s3', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                      aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY)

    try:
        result = s3.delete_object(Bucket=bucket, Key=s3_file)
        return True
    except FileNotFoundError:
        print("The file was not found")
        return False
    except NoCredentialsError:
        print("Credentials not available")
        return False

def download(url, filename):
    # if not os.path.exists(dest_folder):
    #     os.makedirs(dest_folder)  # create folder if it does not exist

    filename = f"{filename}"  # be careful with file names
    file_path = os.path.join(settings.MEDIA_ROOT, filename)

    r = requests.get(url, stream=True)
    if r.ok:
        print("saving to", os.path.abspath(file_path))
        with open(file_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024 * 8):
                if chunk:
                    f.write(chunk)
                    f.flush()
                    os.fsync(f.fileno())
        return True
    else:  # HTTP status code 4XX/5XX
        print(f"Download failed: status code {r.status_code} {r.text}")
        return False