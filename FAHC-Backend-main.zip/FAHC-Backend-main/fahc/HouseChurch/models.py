from django.db import models
from Account.models import Users
from django.template.defaultfilters import slugify
from django.core.exceptions import ValidationError
import random
import os


class Denominations(models.Model):
    name = models.CharField(max_length=225)
    status = models.BooleanField(default= False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    archive = models.BooleanField(default=False)

    
class Churches(models.Model):
    name = models.CharField(max_length=150)
    email = models.CharField(max_length=225, blank=True, null=True)
    biz_info = models.TextField(blank=True, null=True)
    denomination_id = models.ForeignKey(Denominations, on_delete=models.SET_NULL, null=True, blank=True)
    address = models.CharField(max_length=100, blank=True, null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    state = models.CharField(max_length=20, blank=True, null=True)
    zipcode = models.CharField(max_length=7, blank=True, null=True)
    e_zip_full = models.CharField(max_length=10, blank=True, null=True)
    country = models.CharField(max_length=20, blank=True, null=True)
    loc_county = models.CharField(max_length=40, blank=True, null=True)
    loc_area_code = models.CharField(max_length=3, blank=True, null=True)
    loc_fips = models.CharField(db_column='loc_FIPS', max_length=5, blank=True, null=True)  # Field name made lowercase.
    loc_msa = models.CharField(db_column='loc_MSA', max_length=5, blank=True, null=True)  # Field name made lowercase.
    loc_pmsa = models.CharField(db_column='loc_PMSA', max_length=5, blank=True, null=True)  # Field name made lowercase.
    loc_tz = models.CharField(db_column='loc_TZ', max_length=6, blank=True, null=True)  # Field name made lowercase.
    loc_dst = models.CharField(db_column='loc_DST', max_length=1,blank=True, null=True)  # Field name made lowercase.
    lat = models.CharField(max_length=15, blank=True, null=True)
    loc_lat_poly = models.CharField(db_column='loc_LAT_poly', max_length=15, blank=True, null=True)  # Field name made lowercase.
    lng = models.CharField(max_length=15, blank=True, null=True)
    loc_long_poly = models.CharField(db_column='loc_LONG_poly', max_length=15, blank=True, null=True)  # Field name made lowercase.
    website = models.CharField(max_length=255, blank=True, null=True)
    web_meta_title = models.CharField(max_length=255, blank=True, null=True)
    web_meta_desc = models.CharField(max_length=255, blank=True, null=True)
    web_meta_keys = models.CharField(max_length=255, blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    biz_phone_ext = models.CharField(max_length=8, blank=True, null=True)
    poc = models.CharField(max_length=225, blank=True, null=True)
    poc_email = models.CharField(max_length=225, blank=True, null=True)
    poc_phone = models.CharField(max_length=225, blank=True, null=True)
    status = models.BooleanField(default=False, blank=True, null=True)
    # user_id = models.ForeignKey(Users, on_delete=models.SET_NULL, blank=True, null=True)
    image = models.ImageField(upload_to='churches', blank=True, null=True)
    slug = models.CharField(max_length=225, blank=True, null=True)
    search_status = models.IntegerField(blank=True, null=True)
    pageurl = models.CharField(max_length=225, blank=True, null=True)
    code = models.TextField(blank=True, null=True)
    claimed = models.IntegerField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    archive = models.BooleanField(default=False)
    approved = models.BooleanField(default=False)
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = self.generateSlug()
        return super().save(*args, **kwargs)


    def generateSlug(self):
        slug = slugify(self.name)
        while True:
            try:
                Churches.objects.get(slug=slug)
                slug = f"{slug} {random.randint(1, 100)}"
            except Churches.DoesNotExist:
                return slug


    def __str__(self):
        if self.slug:
            return self.slug
        return "" 


class Contacts(models.Model):
    contact_to = models.CharField(max_length=200, blank=True, null=True)
    contact_from = models.CharField(max_length=200, blank=True, null=True)
    attend = models.CharField(max_length=200, blank=True, null=True)
    question = models.CharField(max_length=200, blank=True, null=True)
    phone = models.CharField(max_length=225, blank=True, null=True)
    time = models.CharField(max_length=225, blank=True, null=True)
    message = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.attend



    def __str__(self):
        return self.name

class Downloadcounts(models.Model):
    user_id = models.ForeignKey(Users, on_delete=models.CASCADE)
    doc_type = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


    def __str__(self):
        if self.doc_type:
            return self.doc_type
        return ""

class House_church(models.Model):

    church_id = models.ForeignKey(Churches, on_delete=models.CASCADE, null=True, blank=True)
    user_id = models.ForeignKey(Users, on_delete=models.CASCADE)
    slug = models.SlugField(max_length=225, default="", unique=True, blank=True, null=True)
    address = models.CharField(max_length=225, default="", blank=True, null=True)
    city = models.CharField(max_length=225, default="", blank=True, null=True)
    state = models.CharField(max_length=225, default="", blank=True, null=True)
    zipcode = models.CharField(max_length=225, default="", blank=True, null=True)
    name = models.CharField(max_length=225, default="")
    denomination_id = models.ForeignKey(Denominations, on_delete=models.CASCADE, null=True, blank=True)
    type = models.CharField(max_length=225, default="", blank=True, null=True)
    days = models.CharField(max_length=225, default="", blank=True, null=True)
    time = models.CharField(max_length=225, default="", blank=True, null=True)
    info = models.TextField(default="",blank=True, null=True)
    flag = models.IntegerField(blank=True, null=True)
    special_inst = models.CharField(max_length=225, default="", blank=True, null=True)
    image = models.ImageField(upload_to='houses', blank=True, null=True)
    gallery = models.CharField(max_length=225, default="", blank=True, null=True)
    videos = models.CharField(max_length=225, default="", blank=True, null=True)
    status = models.BooleanField(default=False, blank=True, null=True)
    latitude = models.DecimalField(max_digits=15, decimal_places=10, blank=True, null=True)
    longitude = models.DecimalField(max_digits=15, decimal_places=10, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    archive = models.BooleanField(default=False)
    
    def save(self, *args, **kwargs):
        if self.slug == "":
            self.slug = self.generateSlug()
        return super().save(*args, **kwargs)

    def generateSlug(self):
        slug = slugify(self.name)
        while True:
            try:
                House_church.objects.get(slug=slug)
                slug = f"{slug} {random.randint(1, 100)}"
            except House_church.DoesNotExist:
                return slug


    def __str__(self):
        return self.name  

class Events(models.Model):
    EVENT_TYPE_CHOICES = (
        ('once', 'Once'),
        ('weekly', 'Weekly'),
        ('monthly','Monthly')
    )
    user_id = models.ForeignKey(Users, on_delete=models.CASCADE,blank=True,null=True)
    house_id = models.ForeignKey(House_church, related_name='events', on_delete=models.CASCADE)
    slug = models.SlugField(max_length=225, default="", unique=True, blank=True, null=True)
    name = models.CharField(max_length=225, blank=True, null=True)
    desc = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='event',blank=True, null=True,)
    address = models.CharField(max_length=225, default="", blank=True, null=True)
    city = models.CharField(max_length=225, default="", blank=True, null=True)
    state = models.CharField(max_length=225, default="", blank=True, null=True)
    zipcode = models.CharField(max_length=225, default="", blank=True, null=True)
    type = models.CharField(max_length=225, choices=EVENT_TYPE_CHOICES,default="once")
    start = models.DateField(blank=True, null=True,)
    end = models.DateField(blank=True, null=True)
    monthly_date = models.CharField(max_length=255, blank=True, null=True)
    day= models.CharField(max_length=255,blank=True, null=True)
    time = models.TimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, related_name='children', null=True, blank=True)


    def save(self, *args, **kwargs):
        if self.slug == "":
            self.slug = self.generateSlug()
        return super().save(*args, **kwargs)
    

    def generateSlug(self):
        slug = slugify(self.name)

        if not slug:
            slug = f"event-{random.randint(1, 100)}"

        while True:
            try:
                Events.objects.get(slug=slug)
                slug = f"{slug}-{random.randint(1, 100)}"
            except Events.DoesNotExist:
                return slug

            
    def __str__(self):
        if self.name:
            return self.name
        return ""

class HouseChurchMember(models.Model):
    Member_Type_Choices = (
        ('organizer', 'Organizer'),
        ('sub_organizer', 'Sub Organizer'),
        ('attendee','Attendee')
    )
    joined_Status=(
        ('request','Request'),
        ('invite','Invite'),
    )
    joined_by = models.CharField(max_length=255, choices=joined_Status,default='request')
    type = models.CharField(max_length=225, choices=Member_Type_Choices, default='attendee')
    user_email= models.EmailField(max_length=225,)
    message = models.TextField(blank=True, null=True)
    house_id = models.ForeignKey(House_church,on_delete=models.CASCADE,null=True,blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_deleted =  models.BooleanField(default=False)
    deleted_by = models.ForeignKey(Users, on_delete=models.CASCADE,null=True,blank=True,related_name="deleted_by")

    # def __str__(self):
    #     return self.user_email
    
    class Meta:
        unique_together = ('user_email', 'house_id',)

class Conversation(models.Model):
    participants = models.ManyToManyField(Users, related_name='conversations')
    name = models.CharField(max_length=225, default="", blank=True , null= True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f'Conversation {self.id}'
    

    
class EventMembers(models.Model):
    ATTENDEES_TYPE_CHOICES = (
        ('organizer', 'Organizer'),
        ('sub_organizer', 'Sub Organizer'),
        ('attendee','Attendee')
    )
    EVENT_MEMBER_STATUS_CHOICES=(
        ('onhold','Onhold'),
        ('accepted','Accepted'),
        ('rejected','Rejected'),


    )
    JOINED_STATUS_CHOICES=(
        ('request','Request'),
        ('invite','Invite'),
    )
    joined_by = models.CharField(max_length=255, choices=JOINED_STATUS_CHOICES,default='request')
    type = models.CharField(max_length=225, choices=ATTENDEES_TYPE_CHOICES,default='attendee')
    event_id = models.ForeignKey(Events, on_delete=models.CASCADE, related_name='event_members',null=True,blank=True) 
    user_email = models.EmailField()
    message = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=50,choices=EVENT_MEMBER_STATUS_CHOICES, default="onhold")  # accepted/rejected/onhold
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        unique_together = ('user_email', 'event_id',)

    def __str__(self):
        return self.user_email
    

class Favourites(models.Model):
    user_id = models.ForeignKey(Users, on_delete=models.CASCADE)
    house_id = models.ForeignKey(House_church, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class Histories(models.Model):
    user_id = models.ForeignKey(Users, on_delete=models.CASCADE)
    message = models.CharField(max_length=225, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


    # def __str__(self):
    #     return self.user_id

class Joinhouses(models.Model):
    user_id = models.ForeignKey(Users, on_delete=models.CASCADE)
    house_id = models.ForeignKey(House_church,on_delete=models.CASCADE)
    host_id = models.IntegerField(blank=True, null=True)
    message = models.TextField(blank=True, null=True)
    userphone = models.CharField(max_length=225, blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


    # def __str__(self):
    #     return self.userphone


REPORT_STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('resolved', 'Resolved'),
    )
class Reports(models.Model):

    profile = models.ForeignKey(Users, on_delete=models.CASCADE, null=True, blank=True,  related_name='profile')
    house_id = models.ForeignKey(House_church,on_delete=models.CASCADE, null=True, blank=True,)
    user_id = models.ForeignKey(Users, on_delete=models.CASCADE)
    comment = models.TextField(default="", blank=True, null=True)
    status = models.CharField(max_length=10, choices=REPORT_STATUS_CHOICES ,default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if not self.profile and not self.house_id:
            raise ValidationError("profile or house_id cannot be blank or null.")
        super().save(*args, **kwargs)

    # def __str__(self):
    #     return self.house_name

class Galleries(models.Model):
    event_id = models.ForeignKey(Events,  on_delete=models.CASCADE,null=True,blank=True)
    house_id = models.ForeignKey(House_church,on_delete=models.CASCADE,null=True,blank=True)
    user_id = models.ForeignKey(Users, on_delete=models.CASCADE,null=True,blank=True)
    photo = models.ImageField(upload_to='gallary')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        if self.event_id:
            return self.event_id.name
        elif self.house_id:
            return self.house_id.name
        elif self.user_id:
            return self.user_id.first_name
        else:
            return "Unnamed Gallery"



class Audio(models.Model):
    audio = models.ImageField(upload_to='audio')
    audio_desc = models.TextField()
    house_id = models.ForeignKey(House_church,on_delete=models.CASCADE)
    approved = models.BooleanField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.audio

class Attendees(models.Model):
    Attendees_TYPE_CHOICES = (
        ('organizer', 'Organizer'),
        ('sub_organizer', 'Sub Organizer'),
        ('attendee','Attendee')
    )
    type = models.CharField(max_length=225, choices=Attendees_TYPE_CHOICES,default='attendee')
    user_id = models.ForeignKey(Users, on_delete=models.SET_NULL, blank=True, null=True)
    event_id = models.ForeignKey(Events, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


    def __str__(self):
        if self.event_id:
            return self.event_id.name
        elif self.user_id:
            return self.user_id.first_name
        else:
            return "Unnamed"


    
class Category(models.Model):
    name = models.CharField(max_length=225, default="", null=True, blank= True)
    slug = models.SlugField(max_length=225, unique=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
        super(Category, self).save(*args, **kwargs)

class Discussion(models.Model):
    user_id = models.ForeignKey(Users, on_delete=models.CASCADE)
    event_id = models.ForeignKey(Events, on_delete=models.CASCADE,blank=True,null=True)
    discussion_id = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='replies')
    comment = models.CharField(max_length=225, null=True, blank= True)
    category_id = models.ForeignKey(Category, on_delete=models.CASCADE,blank=True,null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # def __str__(self):
    #     user = str(self.user_id) if self.user_id else "None"
    #     event = str(self.event_id) if self.event_id else "None"
    #     category = str(self.category_id) if self.category_id else "None"
    #     return f"User: {user} - Event: {event} - Category: {category}"
 
    
class Ziprad(models.Model):
    zipcode = models.CharField(db_column='ZipCode', max_length=5)  # Field name made lowercase.
    cityname = models.CharField(db_column='CityName', max_length=35, blank=True, null=True)  # Field name made lowercase.
    statename = models.CharField(db_column='StateName', max_length=2, blank=True, null=True)  # Field name made lowercase.
    countyname = models.CharField(db_column='CountyName', max_length=45, blank=True, null=True)  # Field name made lowercase.
    areacode = models.CharField(db_column='AreaCode', max_length=55, blank=True, null=True)  # Field name made lowercase.
    citytype = models.CharField(db_column='CityType', max_length=1, blank=True, null=True)  # Field name made lowercase.
    cityaliasabbreviation = models.CharField(db_column='CityAliasAbbreviation', max_length=13, blank=True, null=True)  # Field name made lowercase.
    cityaliasname = models.CharField(db_column='CityAliasName', max_length=35, blank=True, null=True)  # Field name made lowercase.
    latitude = models.DecimalField(db_column='Latitude', max_digits=12, decimal_places=6, blank=True, null=True)  # Field name made lowercase.
    longitude = models.DecimalField(db_column='Longitude', max_digits=12, decimal_places=6, blank=True, null=True)  # Field name made lowercase.
    timezone = models.CharField(db_column='TimeZone', max_length=2, blank=True, null=True)  # Field name made lowercase.
    elevation = models.IntegerField(db_column='Elevation', blank=True, null=True)  # Field name made lowercase.
    countyfips = models.CharField(db_column='CountyFIPS', max_length=5, blank=True, null=True)  # Field name made lowercase.
    daylightsaving = models.CharField(db_column='DayLightSaving', max_length=1, blank=True, null=True)  # Field name made lowercase.
    preferredlastlinekey = models.CharField(db_column='PreferredLastLineKey', max_length=10, blank=True, null=True)  # Field name made lowercase.
    classificationcode = models.CharField(db_column='ClassificationCode', max_length=1, blank=True, null=True)  # Field name made lowercase.
    multicounty = models.CharField(db_column='MultiCounty', max_length=1, blank=True, null=True)  # Field name made lowercase.
    statefips = models.CharField(db_column='StateFIPS', max_length=2, blank=True, null=True)  # Field name made lowercase.
    citystatekey = models.CharField(db_column='CityStateKey', max_length=6, blank=True, null=True)  # Field name made lowercase.
    cityaliascode = models.CharField(db_column='CityAliasCode', max_length=5, blank=True, null=True)  # Field name made lowercase.
    primaryrecord = models.CharField(db_column='PrimaryRecord', max_length=1, blank=True, null=True)  # Field name made lowercase.
    citymixedcase = models.CharField(db_column='CityMixedCase', max_length=35, blank=True, null=True)  # Field name made lowercase.
    cityaliasmixedcase = models.CharField(db_column='CityAliasMixedCase', max_length=35, blank=True, null=True)  # Field name made lowercase.
    stateansi = models.CharField(db_column='StateANSI', max_length=2, blank=True, null=True)  # Field name made lowercase.
    countyansi = models.CharField(db_column='CountyANSI', max_length=3, blank=True, null=True)  # Field name made lowercase.
    facilitycode = models.CharField(db_column='FacilityCode', max_length=1, blank=True, null=True)  # Field name made lowercase.
    citydeliveryindicator = models.CharField(db_column='CityDeliveryIndicator', max_length=1, blank=True, null=True)  # Field name made lowercase.
    carrierrouteratesortation = models.CharField(db_column='CarrierRouteRateSortation', max_length=1, blank=True, null=True)  # Field name made lowercase.
    financenumber = models.CharField(db_column='FinanceNumber', max_length=6, blank=True, null=True)  # Field name made lowercase.
    uniquezipname = models.CharField(db_column='UniqueZIPName', max_length=1, blank=True, null=True)  # Field name made lowercase.
    countymixedcase = models.CharField(db_column='CountyMixedCase', max_length=45, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        db_table = 'ziprad'




class Notification(models.Model):
    user = models.ForeignKey(Users, on_delete=models.CASCADE)
    message = models.TextField()
    link = models.CharField(max_length=255, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.message
    


class Activity(models.Model):
    user_id = models.ForeignKey(Users,on_delete=models.CASCADE)
    activity_type = models.CharField(max_length=1050,null=True,blank=False)
    actiivty_desc = models.CharField(max_length=1100,default="")
    link = models.URLField(blank=True, null=True)
    comment = models.TextField(blank=True, null=True)
    reply_to = models.ForeignKey('self', on_delete=models.CASCADE, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)



def validate_audio_file_extension(value):
    ext = os.path.splitext(value.name)[1]  # Get the file extension
    valid_extensions = ['.mp3', '.wav', '.ogg', '.flac']  # List of valid audio extensions
    if not ext.lower() in valid_extensions:
        raise ValidationError("Invalid file extension. Please upload an audio file (MP3, WAV, OGG, FLAC).")
    

class Post(models.Model):
    user = models.ForeignKey(Users, on_delete=models.CASCADE,blank=True, null=True)
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='replies')
    message = models.TextField(default="",blank=True, null=True)
    event_id = models.ForeignKey(Events, on_delete=models.CASCADE,null=True,blank=True) 
    video_link = models.URLField(blank=True, null=True)
    audio = models.FileField(upload_to="audio", blank=True, null= True)
    image = models.ImageField(upload_to="message", blank=True, null= True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if self.audio:
            validate_audio_file_extension(self.audio)

        super().save(*args, **kwargs)
    


class Chat(models.Model):
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(Users, on_delete=models.CASCADE, related_name='sent_messages')
    receiver = models.ForeignKey(Users, on_delete=models.CASCADE, related_name='received_messages')
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f'Message {self.id}'

class State(models.Model):
    name = models.CharField(max_length=200)
    abbr = models.CharField(max_length=3)

    def __str__(self):
        return self.name
    
class County(models.Model):
    name = models.CharField(max_length=200)
    state = models.ForeignKey(State, on_delete=models.CASCADE)

    def __str__(self) -> str:
        return self.name
    
class Location(models.Model):
    name = models.CharField(max_length=200)
    county = models.ForeignKey(County, on_delete=models.CASCADE)
    slug = models.SlugField(unique=True, blank=True)

    def __str__(self) -> str:
        return self.name



class LocationPage(models.Model):
    location=models.OneToOneField(Location,on_delete=models.CASCADE)
    meta_title = models.CharField(max_length=100, blank=True, null=True)
    meta_description = models.TextField(blank=True, null=True)
    keywords = models.CharField(max_length=100, blank=True, null=True) 
    page_title = models.CharField(max_length=100, blank=True, null=True)
    is_active=models.BooleanField(default=False)
    follow = models.BooleanField(default=False)
    index = models.BooleanField(default=False)
    image=models.ImageField(upload_to='data',blank=True,null=True)

class MetaContent(models.Model):
    meta_title = models.CharField(max_length=100, blank=True, null=True)
    meta_description = models.TextField(blank=True, null=True)
    keywords = models.CharField(max_length=100, blank=True, null=True) 
    page_title = models.CharField(max_length=100, blank=True, null=True)
    is_active=models.BooleanField(default=False)
    follow = models.BooleanField(default=False)
    index = models.BooleanField(default=False)
    image=models.ImageField(upload_to='data',blank=True,null=True)


class LocationPageContent(models.Model):
    content=models.TextField(blank=True,null=True)

class EventMessage(models.Model):
    MESSAGE_TYPES = (
        ('outbox', 'Invite'),
        ('inbox', 'request'),
    )

    user_id = models.ForeignKey(Users, on_delete=models.CASCADE,blank=True,null=True)
    event_id = models.ForeignKey(Events, on_delete=models.CASCADE,null=True,blank=True) 
    event_message = models.TextField()
    title = models.CharField(max_length=255, blank=True, null=True)
    created = models.DateTimeField(auto_now_add=True)
    type = models.CharField(max_length=6, choices=MESSAGE_TYPES)
    parent_message = models.ForeignKey('self', on_delete=models.CASCADE, blank=True, null=True)
    receipt_user = models.ForeignKey(Users, on_delete=models.CASCADE, related_name='event_message_recipient', blank=True, null=True)

    def __str__(self) -> str:
        return self.event_message
    # def __str__(self):
    #     if self.event_id:
    #         return self.event_id.name
 
    #     elif self.user_id:
    #         return self.user_id.first_name
    #     else:
    #         return "Unnamed EventMessage"