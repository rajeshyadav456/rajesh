from django.http import HttpResponse
from rest_framework.decorators import api_view
from .serializers import *
from rest_framework import status, viewsets, permissions,generics
from django_filters import rest_framework as filters
from rest_framework.filters import SearchFilter
from .mypagination import CustomPageNumberPagination
from rest_framework.permissions import IsAuthenticated, IsAuthenticatedOrReadOnly
from rest_framework.response import Response
from rest_framework.views import APIView
from .helper import get_distance_from_two_location
from operator import itemgetter
from django.utils import timezone
from django.conf import settings
from django.core.mail import send_mail
from .models import *
from dateutil import relativedelta
from django.utils.translation import gettext_lazy as _
from django.core.mail import EmailMultiAlternatives
from datetime import datetime
from django.template.loader import render_to_string
from django.utils.html import strip_tags
import jwt
from dateutil.relativedelta import relativedelta
from django.db import IntegrityError
from django.core.exceptions import ObjectDoesNotExist
from datetime import timedelta
from django.db.models import *
from django.shortcuts import get_object_or_404
from dateutil.parser import parse

class NotificationAPI(viewsets.ModelViewSet):  
    queryset = Notification.objects.all().order_by('id')
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]

    
class ListChurchessApi(viewsets.ModelViewSet):
    
    queryset = Churches.objects.all().order_by('name')
    serializer_class = listChurchesSerializer
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['status','zipcode','claimed','archive', "approved" ]
    def get_queryset(self):
        queryset = super().get_queryset()
        order_by = self.request.query_params.get('order_by')
        name = self.request.query_params.get('name', None)
        address = self.request.query_params.get('address', None)
        claimed = self.request.query_params.get('claimed',)
        poc = self.request.query_params.get('poc',)
        poc_email= self.request.query_params.get('poc_email',)

        if name:
            queryset = queryset.filter(name__icontains=name)
        if poc:
            queryset = queryset.filter(poc__icontains=poc)
        if poc_email:
            queryset = queryset.filter(poc_email__icontains=poc_email)
        if address:
            queryset = queryset.filter(address__icontains=address)
        if claimed:
            queryset = queryset.filter(claimed=claimed)
        if order_by:
            queryset = queryset.order_by(order_by)
        return queryset
    
class ChurchessApi(viewsets.ModelViewSet):
    
    queryset = Churches.objects.filter(approved=True).order_by('name')
    serializer_class = ChurchesSerializer
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['status','name','address','zipcode' ]
    search_fields = ['name', 'address', 'zipcode']
    

    
    def create(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        if response.status_code == 201:
            instance = Churches.objects.get(pk=response.data['id'])
            Histories.objects.create(user_id=request.user, message=f"{instance.name} Church Created by {request.user.first_name}")
        return response

    def update(self, request, *args, **kwargs):
        response = super().update(request, *args, **kwargs)
        if response.status_code == 200:
            instance = self.get_object()
            instance.updated_at = timezone.now()
            instance.save()
            Histories.objects.create(user_id=request.user, message=f"{instance.name} Church Updated by {request.user.first_name}")
        return response 
    
    def partial_update(self, request, *args, **kwargs):
        response = super().partial_update(request, *args, **kwargs)
        if response.status_code == 200:
            instance = self.get_object()
            instance.updated_at = timezone.now()
            instance.save()
            Histories.objects.create(user_id=request.user, message=f"{instance.name} Church Updated by {request.user.first_name}")
        return response 
    
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        Histories.objects.create(user_id=request.user, message=f"{instance.name} Church Deleted by {request.user.first_name}")
        return Response(status=status.HTTP_204_NO_CONTENT)

class ChurchesBulkActionApi(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        action = request.data.get('action')
        churches = request.data.get('churches')

        if action == 'delete':
            # Delete the selected churches
            Churches.objects.filter(id__in=churches).delete()
            Histories.objects.create(user_id = request.user, message = f"Churches Deleted by {request.user.first_name}")
            return Response({'message': 'Churches deleted successfully.'})
        elif action == 'disable':
            # Disable the selected churches
            Churches.objects.filter(id__in=churches).update(status=False,archive=False, updated_at=timezone.now())
            Histories.objects.create(user_id = request.user, message = f"Churches disabled by {request.user.first_name}")
            return Response({'message': 'Churches disabled successfully.'})
        elif action == 'enable':
            # Enable the selected churches
            Churches.objects.filter(id__in=churches).update(status=True,archive=False, updated_at=timezone.now())
            Histories.objects.create(user_id = request.user, message = f"Churches enabled by {request.user.first_name}")
            return Response({'message': 'Churches enabled successfully.'})
        elif action == 'archive':
            Churches.objects.filter(id__in=churches).update(archive=True,status=False, updated_at=timezone.now())
            Histories.objects.create(user_id=request.user, message=f"Churches archived by {request.user.first_name}")
            return Response({'message': 'Churches archived successfully.'})
        else:
            return Response({'error': 'Invalid action.'}, status=status.HTTP_400_BAD_REQUEST)

class ContactsApi(viewsets.ModelViewSet):
    
    queryset = Contacts.objects.all().order_by('id')
    serializer_class = ContactsSerializer
    pagination_class = CustomPageNumberPagination

class DenominationsApi(viewsets.ModelViewSet):
    
    queryset = Denominations.objects.all().order_by('name')
    serializer_class = DenominationsSerializer
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['status', 'archive']
    def get_queryset(self):
        queryset = super().get_queryset()
        order_by = self.request.query_params.get('order_by')
        name = self.request.query_params.get('name', None)
        if name:
            queryset = queryset.filter(name__icontains=name)
        if order_by:
            queryset = queryset.order_by(order_by)
        return queryset
    
    def create(self, request, *args, **kwargs):
        response = super().create(request)
        if response.status_code == 201:
            instance = Denominations.objects.get(pk=response.data['id'])
            Histories.objects.create(user_id=request.user, message=f"{instance.name} Denomination Created by {request.user.first_name}")

            # Send email to admin
            subject = 'New Denomination Approval'
            template = 'new_denomination_approval.html'
            context = {'denomination_name': instance.name}
            message = render_to_string(template, context)

            from_email = settings.DEFAULT_FROM_EMAIL
            to_email = 'fahc2023@gmail.com'
            send_mail(subject, message, from_email, [to_email], fail_silently=False)

        
            approved = False  
            if approved:
                instance.status = True
                instance.save()


            email_subject = 'New Denomination Created'
            email_template = 'new_denomination_approval.html'  

            recipient_email = request.user.email  
            context = {
                'denomination_name': instance.name,
                'recipient_email': recipient_email,
            }

            html_email = render_to_string(email_template, context)

            email = EmailMultiAlternatives(
                subject=email_subject,
                body=html_email,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[recipient_email]
            )
            email.content_subtype = 'html'
            email.send()

        return response
    
    
    def update(self, request, *args, **kwargs):
        response = super().update(request)
        if response.status_code == 200:
            instance = self.get_object()
            instance.updated_at = timezone.now()
            instance.save()
            Histories.objects.create(user_id = request.user, message = f"{instance.name} Denomination Updated by {request.user.first_name}")
            
        return response 
    
    def partial_update(self, request, *args, **kwargs):
        response = super().partial_update(request)
        if response.status_code == 200:
            instance = self.get_object()
            instance.updated_at = timezone.now()
            instance.save()            
            Histories.objects.create(user_id = request.user, message = f"{instance.name} Denomination Updated by {request.user.first_name}")
            
        return response 
    
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        Histories.objects.create(user_id = request.user, message = f"{instance.name} Denomination Deleted by {request.user.first_name}")
        instance.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    

   
class DenominationsBulkActionApi(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        denominations = request.data["denominations"]
        action = request.data.get('action')

        if action == 'delete':
            # Delete the selected denominations
            Denominations.objects.filter(id__in=denominations).delete()
            Histories.objects.create(user_id=request.user, message=f"Denominations Deleted by {request.user.first_name}")
            return Response({'message': 'Denominations deleted successfully.'})
        elif action == 'disable':
            # Disable the selected denominations
            Denominations.objects.filter(id__in=denominations).update(status=False,archive=False, updated_at=timezone.now())
            Histories.objects.create(user_id=request.user, message=f"Denominations disabled by {request.user.first_name}")
            return Response({'message': 'Denominations disabled successfully.'})
        elif action == 'enable':
            # Enable the selected denominations
            Denominations.objects.filter(id__in=denominations).update(status=True,archive=False, updated_at=timezone.now())
            Histories.objects.create(user_id=request.user, message=f"Denominations enabled by {request.user.first_name}")
            return Response({'message': 'Denominations enabled successfully.'})
        elif action == 'archive':
            Denominations.objects.filter(id__in=denominations).update(archive=True,status=False, updated_at=timezone.now())
            Histories.objects.create(user_id=request.user, message=f"Denominations archived by {request.user.first_name}")
            return Response({'message': 'Denominations archived successfully.'})
        else:
            return Response({'error': 'Invalid action.'}, status=status.HTTP_400_BAD_REQUEST)



class DownloadcountsApi(viewsets.ModelViewSet):
    
    queryset = Downloadcounts.objects.all().order_by('id')
    serializer_class = DownloadcountsSerializer
    pagination_class = CustomPageNumberPagination


class FavouritesApi(viewsets.ModelViewSet):
    
    queryset = Favourites.objects.all().order_by('id')
    serializer_class = FavouritesSerializer
    pagination_class = CustomPageNumberPagination

class HistoriesApi(viewsets.ModelViewSet):
    
    queryset = Histories.objects.all().order_by('id',)
    serializer_class = HistoriesSerializer
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['user_id', 'created_at', 'created_at']

class DashHouseChurchsApi(viewsets.ModelViewSet):
    queryset = House_church.objects.all().order_by('name')
    serializer_class = dashhousechurchSerializer
    pagination_class  = CustomPageNumberPagination
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['user_id', 'status', 'zipcode','archive']
    def get_queryset(self):
        queryset = super().get_queryset()
        order_by = self.request.query_params.get('order_by')
        name = self.request.query_params.get('name', None)
        address = self.request.query_params.get('address', None)
        user_full_name = self.request.query_params.get('user', None)
        if user_full_name:
            # Split the user_full_name into first name and last name
            name_parts = user_full_name.split(' ', 1)
            if len(name_parts) == 2:
                first_name, last_name = name_parts
                # If both first name and last name are provided, filter using both
                queryset = queryset.filter(
                    Q(user_id__first_name__icontains=first_name) & Q(user_id__last_name__icontains=last_name)
                )
            else:
                # If only first name is provided, filter using first name only
                first_name = name_parts[0]
                queryset = queryset.filter(
                    Q(user_id__first_name__icontains=first_name) | Q(user_id__last_name__icontains=first_name)
                )

        if name:
            queryset = queryset.filter(name__icontains=name)
        if address:
            queryset = queryset.filter(address__icontains=address)



        if order_by:
            queryset = queryset.order_by(order_by)
        return queryset
    
class LocationPageAPi(viewsets.ModelViewSet):
    queryset = LocationPage.objects.all()
    serializer_class = LocationPageSerializer
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticated]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['is_active']

    def get_queryset(self):
        queryset = super().get_queryset()
        order_by = self.request.query_params.get('order_by')
        meta_title = self.request.query_params.get('meta_title', None)
        keywords = self.request.query_params.get('keywords', None)
        page_title = self.request.query_params.get('page_title', None)
        location_name = self.request.query_params.get('location', None)
        state_name = self.request.query_params.get('state', None)  # Get the state parameter
        
        if location_name:
            queryset = queryset.filter(location__name__icontains=location_name)
        if state_name:
            queryset = queryset.filter(location__county__state__name__icontains=state_name)  # Filter by state name
        
        if page_title:
            queryset = queryset.filter(page_title__icontains=page_title)
        if keywords:
            queryset = queryset.filter(keywords__icontains=keywords)
        if meta_title:
            queryset = queryset.filter(meta_title__icontains=meta_title)

        if order_by:
            queryset = queryset.order_by(order_by)
        
        return queryset

class LocationPageContentApi(viewsets.ModelViewSet):
    queryset=LocationPageContent.objects.all()
    serializer_class=LocationPageContentSerializer
    pagination_class=CustomPageNumberPagination
    permission_class=[IsAuthenticated]
    

class HousesApi(viewsets.ModelViewSet):
    queryset = House_church.objects.all().order_by('name')
    serializer_class = House_churchSerializer
    pagination_class  = CustomPageNumberPagination
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['user_id', 'status','denomination_id', 'slug','name','address','zipcode','church_id',]
    search_fields = ['name','address', ]

    def get_queryset(self):
        queryset = House_church.objects.all().order_by('name')
        archive_param = self.request.query_params.get('archive', None)

        # If 'archive' parameter is not provided or 'archive' is not true, return the original queryset
        if archive_param is None or archive_param.lower() != 'true':
            return queryset

        # If 'archive' is true, return the queryset of house churches that are not deleted
        return queryset.filter(archive=False)
    
    def retrieve(self, request, *args, **kwargs):
        if kwargs['pk'].isdigit():
            instance = self.get_object()
        else:
            instance = House_church.objects.filter(slug= kwargs['pk']).first()
        if instance:
            serializer = HouseChurchDetailSerializer(instance, context={'request': request})
            return Response(serializer.data)
        else:
            return Response({'message': "Not Found"}, status=status.HTTP_400_BAD_REQUEST)
        
    
    def update(self, request, *args, **kwargs):
        response = super().update(request)
        if response.status_code == 200:
            instance = self.get_object()
            instance.updated_at = timezone.now()
            instance.save()       
            Histories.objects.create(user_id = instance.user_id, message = f"{instance.name} House Church Updated by {request.user.first_name}")
            
        return response    

    def partial_update(self, request, *args, **kwargs):
            instance = self.get_object()
            partial = kwargs.pop('partial', True)
            serializer = self.get_serializer(instance, data=request.data, partial=partial)
            serializer.is_valid(raise_exception=True)
            serializer.save()
            Histories.objects.create(user_id = instance.user_id, message = f"{instance.name} House Church Updated by {request.user.first_name}")           
            return Response(serializer.data)
    
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()      
        Histories.objects.create(user_id = instance.user_id, message = f"{instance.name} House Church Deleted by {request.user.first_name}")
        instance.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    
class HousesChurchesBulkActionApi(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        action = request.data.get('action')
        house_churches = request.data.get('house_churches')

        if action == 'delete':
            # Delete the selected house churches
            House_church.objects.filter(id__in=house_churches).delete()
            Histories.objects.create(user_id = request.user, message = f"House Churches Deleted by {request.user.first_name}")
            return Response({'message': 'House Churches deleted successfully.'})
        elif action == 'disable':
            # Disable the selected house churches
            House_church.objects.filter(id__in=house_churches).update(status=False,archive=False, updated_at=timezone.now())
            Histories.objects.create(user_id = request.user, message = f"House Churches disabled by {request.user.first_name}")
            return Response({'message': 'House Churches disabled successfully.'})
        elif action == 'enable':
            # Enable the selected house churches
            House_church.objects.filter(id__in=house_churches).update(status=True,archive=False, updated_at=timezone.now())
            Histories.objects.create(user_id = request.user, message = f"House Churches enabled by {request.user.first_name}")
            return Response({'message': 'House Churches enabled successfully.'})
        elif action == 'archive':
            House_church.objects.filter(id__in=house_churches).update(archive=True,status=False, updated_at=timezone.now())
            Histories.objects.create(user_id=request.user, message=f"House Churches archived by {request.user.first_name}")
            return Response({'message': 'House Churches archived successfully.'})
        else:
            return Response({'error': 'Invalid action.'}, status=status.HTTP_400_BAD_REQUEST)

    
class JoinhousesApi(viewsets.ModelViewSet):
    
    queryset = Joinhouses.objects.all().order_by('id')
    serializer_class = JoinhousesSerializer
    pagination_class = CustomPageNumberPagination


class EventsAPI(viewsets.ModelViewSet):   
    queryset = Events.objects.all().order_by('id')
    serializer_class = EventsSerializer
    pagination_class  = CustomPageNumberPagination
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['house_id','user_id',]
    search_fields = ['name', ]
    def get_queryset(self):
        queryset = super().get_queryset()
        order_by = self.request.query_params.get('order_by')
        name = self.request.query_params.get('name', None)
        address = self.request.query_params.get('address', None)
        zipcode = self.request.query_params.get('zipcode', None)
        start_from = self.request.query_params.get('start_from')
        end_from = self.request.query_params.get('end_from')
        start_to = self.request.query_params.get('start_to')
        end_to = self.request.query_params.get('end_to')

        house_id = self.request.query_params.get('house_id')

        if house_id:
            queryset = queryset.filter(house_id=house_id)
        if name:
            queryset = queryset.filter(name__icontains=name)
        if start_from:
            queryset = queryset.filter(start__gte=start_from)
        if end_from:
            queryset = queryset.filter(end__gte=end_from)
        if start_to:
            queryset = queryset.filter(start__lte=start_to)
        if end_to:
            queryset = queryset.filter(end__lte=end_to)
        if start_from and start_to:
            queryset = queryset.filter(start__range=(start_from, start_to))
        if end_from and end_to:
            queryset = queryset.filter(end__range=(end_from, end_to))

        if address:
            queryset = queryset.filter(address__icontains=address)
        if zipcode:
            queryset = queryset.filter(zipcode=zipcode)
        if order_by:
            queryset = queryset.order_by(order_by)
        return queryset
    

    def retrieve(self, request, *args, **kwargs):
        if kwargs['pk'].isdigit():
            instance = self.get_object()
        else:
            instance = Events.objects.filter(slug= kwargs['pk']).first()
        if instance:
            serializer = EventsDetailSerializer(instance, context={'request': request})
            return Response(serializer.data)
        else:
            return Response({'message': "Not Found"}, status=status.HTTP_400_BAD_REQUEST)


    def create(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_id = response.data['id']
            user_id = request.user.id
            user_instance = Users.objects.get(pk=user_id)
            event_instance = Events.objects.get(pk=event_id)

            Attendees.objects.create(type='owner', user_id=user_instance, event_id=event_instance)

            sub_organizers = request.data.get('sub_organizers', [])
            invite_to_all = request.data.get('invite_to_all', False)

            for user_id in sub_organizers:
                sub_organizer = Users.objects.filter(id=user_id).first()
                if sub_organizer:
                    try:
                        sub_organizer_entry, _ = EventMembers.objects.get_or_create(
                            event_id=event_instance,
                            user_email=sub_organizer.email,
                            defaults={
                                'joined_by': 'request',
                                'type': 'sub_organizer',
                                'status': 'onhold'
                            }
                        )

                        if sub_organizer_entry:
                            # Send email to the sub-organizer
                            subject = 'You have been added as a sub-organizer'
                            event_name = event_instance.name
                            event_owner = event_instance.user_id.first_name
                            sub_organizer_name = sub_organizer.first_name 
                            context = {
                                'sub_organizer_name': sub_organizer_name,
                                'event_name': event_name,
                                'event_owner': event_owner,
                            }
                            html_content = render_to_string('sub_organizer_email.html', context)
                            text_content = strip_tags(html_content)

                            email = EmailMultiAlternatives(
                                subject=subject,
                                body=text_content,
                                from_email=None,
                                to=[sub_organizer.email]
                            )
                            email.attach_alternative(html_content, "text/html")
                            email.send()
                    except IntegrityError:
                        pass

            if invite_to_all:
                members = event_instance.house_id.housechurchmember_set.filter(is_deleted=False)
                subject = 'Invitation to Event'
                event_name = event_instance.name
                event_owner = event_instance.user_id.first_name
                event_city = event_instance.city
                event_state = event_instance.state
                event_zipcode = event_instance.zipcode
                event_date = event_instance.start
                event_time = event_instance.time
                event_slug = event_instance.slug

                for member in members:
                    try:
                        invite_entry, _ = EventMembers.objects.get_or_create(
                            event_id=event_instance,
                            user_email=member.user_email,
                            defaults={
                                'joined_by': 'invite',
                                'type': 'attendee',
                                'status': 'onhold'
                            }
                        )
                       
                        if invite_entry:
                            recipient_name = member.user_email
                            recipient = Users.objects.filter(email=recipient_name).first()
                            if recipient:
                                recipient_name = recipient.first_name  
                            context = {
                                'receipt_user': recipient_name,
                                'message': '',
                                'event_name': event_name,
                                'event_owner': event_owner,
                                'event_city': event_city,
                                'event_state': event_state,
                                'event_zipcode': event_zipcode,
                                'event_date': event_date,
                                'event_time': event_time,
                                'event_slug': event_slug,
                                'token': '',
                            }

                            html_content = render_to_string('invite_to_all.html', context)
                            text_content = strip_tags(html_content)

                            email = EmailMultiAlternatives(
                                subject=subject,
                                body=text_content,
                                from_email=None,
                                to=[member.user_email]
                            )
                            email.attach_alternative(html_content, "text/html")
                            email.send()
                    except IntegrityError:
                        pass

            Histories.objects.create(user_id=user_instance, message=f"{event_instance.name} Event Created by {user_instance.first_name}")

        return response


        
    def update(self, request, *args, **kwargs):
        response = super().update(request)
        if response.status_code == 200:
            instance = self.get_object()
            instance.updated_at = timezone.now()
            instance.save()
            Histories.objects.create(user_id = request.user, message = f"{instance.name} Event Updated by {request.user.first_name}")
            
        return response 
    
    def partial_update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        instance.updated_at = timezone.now()
        instance.save()
        Histories.objects.create(user_id=request.user, message=f"{instance.name} Event Updated by {request.user.first_name}")

        return Response(serializer.data)
    
    
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()      
        Histories.objects.create(user_id = instance.user_id, message = f"{instance.name} House Church Deleted by {request.user.first_name}")
        instance.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class AttendeesAPI(viewsets.ModelViewSet):   
    queryset = Attendees.objects.all().order_by('id')
    serializer_class = AttendeeSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    pagination_class  = CustomPageNumberPagination
    filterset_fields = ['user_id','event_id']
    search_fields = ['type' ]


class AudioAPI(viewsets.ModelViewSet):   
    queryset = Audio.objects.all().order_by('id')
    serializer_class = AudioSerializer
    pagination_class = CustomPageNumberPagination

class GalleryAPI(viewsets.ModelViewSet):   
    queryset = Galleries.objects.all().order_by('id')
    serializer_class = GallerySerializer
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['user_id','event_id','house_id']


    def create(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        if response.status_code == 201:
            instance = response.data
            name = instance.get('name', 'Unknown Gallery')
            Histories.objects.create(user_id=request.user, message=f"{name} Gallery Created by {request.user.first_name}")
        return response
    
    def update(self, request, *args, **kwargs):
        response = super().update(request, *args, **kwargs)
        if response.status_code == 200:
            instance = response.data
            name = instance.get('name', 'Unknown Gallery')
            Histories.objects.create(user_id=request.user, message=f"{name} Gallery Created by {request.user.first_name}")
        return response
    def partial_update(self, request, *args, **kwargs):
        response = super().partial_update(request, *args, **kwargs)
        if response.status_code == 200:
            instance = response.data
            name = instance.get('name', 'Unknown Gallery')
            Histories.objects.create(user_id=request.user, message=f"{name} Gallery Created by {request.user.first_name}")
        return response
    

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        name = serializer.data.get('name', 'Unknown Gallery')
        Histories.objects.create(user_id=request.user, message=f"{name} Gallery Deleted by {request.user.first_name}")
        return Response(status=status.HTTP_204_NO_CONTENT)
    

class DiscussionAPI(viewsets.ModelViewSet):   
    queryset = Discussion.objects.all().order_by('id')
    serializer_class = DiscussionSerializer
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['user_id', 'category_id','event_id', 'discussion_id', 'created_at', 'updated_at']
    search_fields = ['comment', ]


class ZipRadAPI(viewsets.ModelViewSet):   
    queryset = Ziprad.objects.all().order_by('id')
    serializer_class = ZipRadSerializer
    pagination_class = CustomPageNumberPagination

def index(request):
    return HttpResponse("<p>Welcome to Find A House Church</p>")

@api_view(['GET'])
def search_house_church(request):
    zipcode = request.GET.get('zipcode')
    if zipcode:
        house_churches = House_church.objects.filter(zipcode=zipcode)
        serializer = House_churchSerializer(house_churches, many=True)
        return Response(serializer.data)
    else:
        return Response({'error': 'zipcode parameter is missing'})
    
class SearchHouseChurchAPI(APIView):
    def get(self, request):
        zipcode = request.query_params.get('zipcode')
        distc = request.query_params.get('distance', None)
        latitude = request.query_params.get('latitude')
        longitude = request.query_params.get('longitude')
        denomination = request.query_params.get('denomination')
        days = request.query_params.get('days')
        house_type = request.query_params.get('type')
        special_inst = request.query_params.get('special_inst')

        house_churches = []
        house_church = House_church.objects.all()
        house_church = house_church.filter(denomination_id__id=denomination) if denomination else house_church
        house_church = house_church.filter(days__icontains=days) if days else house_church
        house_church = house_church.filter(type__icontains=house_type) if house_type else house_church
        house_church = house_church.filter(special_inst=special_inst) if special_inst else house_church

        if (latitude and longitude) or zipcode:
            if zipcode:
                zipcode_objs = Ziprad.objects.filter(zipcode=zipcode)
                if zipcode_objs.exists():
                    latitude = zipcode_objs[0].latitude
                    longitude = zipcode_objs[0].longitude
                else:
                    return Response(status=status.HTTP_204_NO_CONTENT)

            match_house_church = house_church.filter(zipcode=zipcode) if zipcode else house_church
            # if len(zipcode) > 0:
            #     match_house_church= house_church.filter(zipcode=zipcode[0].zipcode)
            # print(match_house_church,'---')
            new_queryset = match_house_church | house_church

            for house in new_queryset:
                if house.latitude and house.longitude and house.longitude != "" and house.longitude != "":
                    distance = get_distance_from_two_location(latitude, longitude, house.latitude, house.longitude)
                    print(distance,'-----')
                    try:
                        dist = int(distc)
                    except:
                        dist = 20
                    if distance < dist:
                        data = {"id": house.id, 'name': house.name, 'address': house.address,
                                'distance': distance, 'slug': house.slug,
                                'image': settings.SITE_DOMAIN + house.image.url if house.image else "",
                                'city': house.city, 'zipcode': house.zipcode, 'type': house.type,
                                'days': house.days, 'time': house.time, 'info': house.info,
                                'latitude': house.latitude, 'longitude': house.longitude,
                                'user_address': house.user_id.address if house.user_id else ""}
                        house_churches.append(data)

            newlist = sorted(house_churches, key=itemgetter('distance'))
            return Response(newlist, status=status.HTTP_200_OK)

        return Response(status=status.HTTP_204_NO_CONTENT)


    
class HouseMemberList(viewsets.ModelViewSet):   
    queryset = HouseChurchMember.objects.all().order_by('id')
    serializer_class = HouseMemberSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    pagination_class = CustomPageNumberPagination
    filterset_fields = [ 'house_id']
    def get_queryset(self):
        queryset = super().get_queryset()
        order_by = self.request.query_params.get('order_by')
        user_email = self.request.query_params.get('user_email', None)
        if user_email:
            queryset = queryset.filter(name__icontains=user_email)
        if order_by:
            queryset = queryset.order_by(order_by)
        return queryset
    
class DeshHouseMemberList(viewsets.ModelViewSet):   
    queryset = HouseChurchMember.objects.all().order_by('id')
    serializer_class = DashHouseMemberSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    pagination_class = CustomPageNumberPagination
    filterset_fields = [ 'house_id']
    search_fields = ['user_email']
    def get_queryset(self):
        queryset = super().get_queryset()
        order_by = self.request.query_params.get('order_by')
        user_email = self.request.query_params.get('user_email', None)
        type = self.request.query_params.get('type', None)

        if user_email:
            queryset = queryset.filter(user_email__icontains=user_email)
        if type:
            queryset = queryset.filter(type__icontains=type)
        if order_by:
            queryset = queryset.order_by(order_by)
        return queryset
    
class EventMemberAPI(viewsets.ModelViewSet):   
    queryset = EventMembers.objects.all().order_by('id')
    serializer_class = EventMemberSerializer
    pagination_class = CustomPageNumberPagination
    filterset_fields = ['event_id']

    def get_queryset(self):
        queryset = super().get_queryset()
        order_by = self.request.query_params.get('order_by')
        user_email = self.request.query_params.get('user_email', None)
        type = self.request.query_params.get('type', None)
        user = self.request.query_params.get('user', None)

        if user_email:
            queryset = queryset.filter(user_email__icontains=user_email)
        if type:
            queryset = queryset.filter(type__icontains=type)
        if order_by:
            queryset = queryset.order_by(order_by)
        return queryset

class EventBulkAPIView(APIView):
    permission_classes = [permissions.IsAuthenticated] 
    serializer_class = EventBulkSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            name = serializer.validated_data.get("name")
            desc = serializer.validated_data.get("desc")
            user_id = serializer.validated_data.get("user_id")
            house_id = serializer.validated_data.get("house_id")
            start = serializer.validated_data.get("start")
            end = serializer.validated_data.get("end")
            time = serializer.validated_data.get("time")
            type = serializer.validated_data.get("type")
            monthly_date = serializer.validated_data.get("monthly_date")
            day = serializer.validated_data.get("day")
            image = serializer.validated_data.get("image")

            # Check if all required data is provided
            if user_id and house_id and start and end and time:
                try:
                    # Retrieve the user and house church objects
                    user = Users.objects.get(id=user_id)
                    house_church = House_church.objects.get(id=house_id)

                    # Convert start and end to datetime objects
                    start = datetime.datetime.strptime(start, "%Y-%m-%d").date()
                    end = datetime.datetime.strptime(end, "%Y-%m-%d").date()

                    if type == "once":
                        event = Events.objects.create(
                            user_id=user,
                            house_id=house_church,
                            name=name,
                            desc=desc,
                            start=start,
                            end=end,
                            time=time,
                            image=image,
                        )
                        return Response(
                            {"detail": "1 New Event Created"}, status=status.HTTP_200_OK
                        )

                    if type == "monthly":
                        if monthly_date:
                            # Create events for each month within the specified range
                            count = 0
                            parent_event = None
                            while start.month <= end.month:
                                event = Events.objects.create(
                                    user_id=user,
                                    house_id=house_church,
                                    name=name,
                                    desc=desc,
                                    start=start,
                                    end=start,
                                    monthly_date=monthly_date,
                                    time=time,
                                    image=image,
                                    parent=parent_event
                                )
                                if count == 0:
                                    parent_event = event
                                start += relativedelta(months=1)
                                count += 1
                            return Response(
                                {"detail": f"{count} New Events Created"},
                                status=status.HTTP_200_OK,
                            )
                        else:
                            return Response(
                                {"detail": "monthly date required for monthly events"},
                                status=status.HTTP_400_BAD_REQUEST,
                            )

                    if type == "weekly":
                        if day:
                            months = {
                                "monday": 0,
                                "tuesday": 1,
                                "wednesday": 2,
                                "thursday": 3,
                                "friday": 4,
                                "saturday": 5,
                                "sunday": 6,
                            }
                            month = months[day]
                            if start.weekday() == month:
                                parent_event = Events.objects.create(
                                    user_id=user,
                                    house_id=house_church,
                                    name=name,
                                    desc=desc,
                                    start=start,
                                    end=start,
                                    monthly_date=monthly_date,
                                    time=time,
                                    day=day,
                                    image=image,
                                )
                                count = 1
                            else:
                                parent_event = None
                                count = 0

                            start = next_weekday(start, month)
                            while start.month <= end.month:
                                event = Events.objects.create(
                                    user_id=user,
                                    house_id=house_church,
                                    name=name,
                                    desc=desc,
                                    start=start,
                                    end=start,
                                    monthly_date=monthly_date,
                                    time=time,
                                    image=image,
                                    parent=parent_event
                                )
                                parent_event = event
                                start = next_weekday(start, month)
                                count += 1

                            return Response(
                                {"detail": f"{count} New Events Created"},
                                status=status.HTTP_200_OK,
                            )
                        else:
                            return Response(
                                {"detail": "day required for weekly events"},
                                status=status.HTTP_400_BAD_REQUEST,
                            )

                except Exception as e:
                    return Response(
                        {"detail": str(e)},
                        status=status.HTTP_400_BAD_REQUEST,
                    )

            return Response(
                {"detail": "Please provide all required data"},
                status=status.HTTP_400_BAD_REQUEST,
            )
        else:
            return Response(
                serializer.errors, status=status.HTTP_400_BAD_REQUEST
            )



class HouseChurchEventsAPI(viewsets.ViewSet):
    pagination_class = CustomPageNumberPagination
    def list(self, request, house_church_id):
        house_church = House_church.objects.get(pk=house_church_id)
        events = house_church.events.all().order_by('start')

        serializer = EventsSerializer(events, many=True)
        return Response(serializer.data)

    def retrieve_upcoming_events(self, request, house_church_id):
        house_church = House_church.objects.get(pk=house_church_id)
        today = date.today()
        upcoming_events = house_church.events.filter(end__gte=today).order_by('start')

        serializer = EventsSerializer(upcoming_events, many=True)
        return Response(serializer.data)

    def retrieve_past_events(self, request, house_church_id):
        house_church = House_church.objects.get(pk=house_church_id)
        today = date.today()
        past_events = house_church.events.filter(end__lt=today).order_by('-start')

        serializer = EventsSerializer(past_events, many=True)
        return Response(serializer.data)
            
               

def next_weekday(d, weekday):
    days_ahead = weekday - d.weekday()
    if days_ahead <= 0: # Target day already happened this week
        days_ahead += 7
    return d + datetime.timedelta(days_ahead)


class EventsByZipcodeAPI(APIView):
    def get(self, request):
        events_within_radius = []
        current_datetime = datetime.now()
        zipcode = request.query_params.get('zipcode')
        if not zipcode:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        zipcode = Ziprad.objects.filter(zipcode = zipcode)
        if len(zipcode) > 0: 
            latitude = zipcode[0].latitude 
            longitude = zipcode[0].longitude
        else: 
            return Response(events_within_radius, status=status.HTTP_200_OK) 
        events = Events.objects.filter(end__gte=current_datetime.date())
        for event in events:
            zipcode = Ziprad.objects.filter(zipcode = event.zipcode)
            if len(zipcode) > 0: 
                latitude1 = zipcode[0].latitude 
                longitude1 = zipcode[0].longitude
                distance = get_distance_from_two_location(latitude, longitude, latitude1, longitude1)
                if distance <= 50:
                    event_data = EventsSerializer(event).data
                    event_data['distance'] = distance
                    events_within_radius.append(event_data)
        sorted_events = sorted(events_within_radius, key=itemgetter('distance'))
        return Response(sorted_events, status=status.HTTP_200_OK)


class ActivityApi(viewsets.ModelViewSet):
    
    queryset = Activity.objects.all().order_by('id' )
    serializer_class = ActivitySerializer
    pagination_class = CustomPageNumberPagination
     

        
class FollowHouseChurchAPIView(APIView):
    def post(self, request):
        user_id = request.data.get('user_id')
        house_ids = request.data.get('house_ids', [])

        try:
            user = Users.objects.get(id=user_id)
        except Users.DoesNotExist:
            return Response({'message': 'Invalid user_id'}, status=status.HTTP_400_BAD_REQUEST)

        existing_memberships = HouseChurchMember.objects.filter(user_email=user.email)
        existing_houses = existing_memberships.values_list('house_id', flat=True)

        new_house_ids = [house_id for house_id in house_ids if house_id not in existing_houses]
        new_houses = House_church.objects.filter(id__in=new_house_ids)

        new_memberships = [HouseChurchMember(user_email=user.email, house_id=house) for house in new_houses]
        HouseChurchMember.objects.bulk_create(new_memberships)

        return Response({'message': 'Successfully followed house churches'}, status=status.HTTP_200_OK)



class CategoryAPI(viewsets.ModelViewSet):
    queryset = Category.objects.all().order_by('id' )
    serializer_class = CategorySerializer
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    # filterset_fields = ['name']
    def get_queryset(self):
        queryset = super().get_queryset()
        order_by = self.request.query_params.get('order_by')
        name = self.request.query_params.get('name', None)
        if name:
            queryset = queryset.filter(name__icontains=name)
        if order_by:
            queryset = queryset.order_by(order_by)
        return queryset




class RequestToJoinEventAPI(APIView):
    def post(self, request):
        token = request.data.get('token')
        email = request.data.get('email')

        try:
            decoded_token = jwt.decode(token, settings.SECRET_KEY, algorithms=['HS256'])

            attendee_type = decoded_token.get('type')
            event_id = decoded_token.get('event_id')
            token_email = decoded_token.get('email')

            if attendee_type is None:
                attendee_type = 'attendee'  # Set a default value if attendee_type is not present in the token

            if event_id and token_email and token_email == email:
                event = Events.objects.get(id=event_id)

                if event.user_id and event.user_id.email:
                    event_owner_email = event.user_id.email
                    event_owner_name = event.user_id.first_name
                    print(event_owner_name,'----')
                    event_name = event.name
                    event_slug = event.slug

                    # Update the event_member.status to 'accepted' here
                    try:
                        event_member = EventMembers.objects.get(user_email=email, event_id=event)
                        event_member.status = 'accepted'
                        event_member.save()
                    except EventMembers.DoesNotExist:
                        pass

                    context = {
                        'event_owner_name': event_owner_name,
                        'receipt_user': {
                            'name': email,  # Using the recipient's email for demonstration
                        },
                        'event_name': event_name,
                        'event_slug': event_slug,
                    }
                    
                    html_message = render_to_string('event_join_request_email.html', context)
                    plain_message = strip_tags(html_message)

                    email = EmailMultiAlternatives(
                        subject='Membership Request for Event: {}'.format(event_name),
                        body=plain_message,
                        from_email=settings.DEFAULT_FROM_EMAIL,
                        to=[event_owner_email]
                    )
                    email.attach_alternative(html_message, "text/html")
                    email.send()

                    event_owner = Users.objects.get(email=event_owner_email)
                    notification_message = f"A user with email {email} has requested to join the event '{event_name}'."
                    notification = Notification(user=event_owner, message=notification_message,
                                                created_at=timezone.now())
                    notification.save()

                    return Response({'message': 'Join request sent successfully'}, status=status.HTTP_200_OK)
                else:
                    return Response({'message': 'Event owner not found or has no email'},
                                    status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({'message': 'Invalid token or mismatched user email'}, status=status.HTTP_400_BAD_REQUEST)
        except jwt.exceptions.DecodeError as e:
            return Response({'message': 'Invalid token', 'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except ObjectDoesNotExist as e:
            return Response({'message': 'Event not found', 'error': str(e)}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'message': 'An error occurred', 'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



class AcceptRejectRequestAPI(APIView):
    def post(self, request):
        event_member_id = request.data.get('event_member_id')
        action = request.data.get('action')  # 'accept' or 'reject'

        try:
            event_member = EventMembers.objects.get(id=event_member_id)
        except EventMembers.DoesNotExist:
            return Response({'message': 'Event member not found'}, status=status.HTTP_404_NOT_FOUND)
        event_name = event_member.event_id.name

        if action == 'accept':
            event_member.status = 'accepted'
            email_subject = 'Request Accepted : {}'.format(event_name)
            email_template = 'acceptance_email.html'
        elif action == 'reject':
            event_member.status = 'rejected'
            email_subject = 'Request Rejected : {}'.format(event_name)
            email_template = 'rejection_email.html'
        else:
            return Response({'message': 'Invalid action'}, status=status.HTTP_400_BAD_REQUEST)

        event_member.save()

        recipient_email = event_member.user_email
        # recipient_name = event_member.user_name 
        event_slug = event_member.event_id.slug  
        user = Users.objects.filter(email=recipient_email).first()
        recipient_name = user.first_name if user else ''
        context = {
            'recipient_email': recipient_email,
            'event_slug': event_slug,
            'recipient_name':recipient_name,
            'event_name':event_name
        }

        html_email = render_to_string(email_template, context)

        email = EmailMultiAlternatives(
            subject=email_subject,
            body=html_email,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[recipient_email]
        )
        email.content_subtype = 'html'  # Set the content type as HTML
        email.send()

        return Response({'message': f'Request {action}ed successfully. Email sent successfully'}, status=status.HTTP_200_OK)


class ChangeEventMemberTypeAPI(APIView):
    def post(self, request):
        event_member_id = request.data.get('event_member_id')
        action = request.data.get('action')

        if not event_member_id or not action:
            return Response({'error': 'Event member ID and action are required.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            event_member = EventMembers.objects.get(id=event_member_id)
        except EventMembers.DoesNotExist:
            return Response({'error': 'Event member not found.'}, status=status.HTTP_404_NOT_FOUND)

        event_name = event_member.event_id.name if event_member.event_id else ''

        # Perform the action based on the provided value
        if action == 'organizer':
            event_member.type = 'organizer'
            email_subject = 'Role Change Notification : {}'.format(event_name)
            email_template = 'organizer_email.html'
        elif action == 'sub_organizer':
            event_member.type = 'sub_organizer'
            email_subject = 'Role Change Notification : {}'.format(event_name)
            email_template = 'sub_organizer_email.html'
        elif action == 'attendee':
            event_member.type = 'attendee'
            email_subject = 'Role Change Notification : {}'.format(event_name)
            email_template = 'attendee_email.html'
        else:
            return Response({'error': 'Invalid action provided.'}, status=status.HTTP_400_BAD_REQUEST)

        event_member.save()

        recipient_email = event_member.user_email
        event_slug =  event_member.event_id.slug
        user = Users.objects.filter(email=recipient_email).first()
        recipient_name = user.first_name if user else ''
        context = {
            'event_name': event_name,
            'recipient_email': recipient_email,
            'event_slug': event_slug,
            'recipient_name':recipient_name
        }

        html_email = render_to_string(email_template, context)

        email = EmailMultiAlternatives(
            subject=email_subject,
            body=html_email,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[recipient_email]
        )
        email.content_subtype = 'html'
        email.send()

        return Response({'success': 'Event member type changed successfully. Email sent.'}, status=status.HTTP_200_OK)

class ChangeHouseChurchMemberTypeAPI(APIView):
    def post(self, request):
        house_member_id = request.data.get('house_member_id')
        action = request.data.get('action')

        if not house_member_id or not action:
            return Response({'error': 'Member ID and action are required.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            house_member = HouseChurchMember.objects.get(id=house_member_id)
        except HouseChurchMember.DoesNotExist:
            return Response({'error': 'House church member not found.'}, status=status.HTTP_404_NOT_FOUND)

        # Fetch house church data
        house_church = house_member.house_id
        if house_church:
            house_name = house_church.name
            house_slug = house_church.slug
        else:
            house_name = ""
            house_slug = ""

        # Perform the action based on the provided value
        if action == 'organizer':
            house_member.type = 'organizer'
            email_subject = 'Role Change Notification : {}'.format(house_name)
            email_template = 'housememberorganizer.html'
        elif action == 'sub_organizer':
            house_member.type = 'sub_organizer'
            email_subject = 'Role Change Notification : {}'.format(house_name)
            email_template = 'sub_organizer_email.html'
        elif action == 'guest':
            house_member.type = 'guest'
            email_subject = 'Role Change Notification : {}'.format(house_name)
            email_template = 'houseattendee.html'
        else:
            return Response({'error': 'Invalid action provided.'}, status=status.HTTP_400_BAD_REQUEST)

        house_member.save()

        recipient_email = house_member.user_email
        user = Users.objects.filter(email=recipient_email).first()
        recipient_name = user.first_name if user else ''
        context = {
            'recipient_email': recipient_email,
            'recipient_name': recipient_name,
            'house_name': house_name,
            'house_slug': house_slug,
        }

        html_email = render_to_string(email_template, context)

        email = EmailMultiAlternatives(
            subject=email_subject,
            body=html_email,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[recipient_email]
        )
        email.content_subtype = 'html'
        email.send()

        return Response({'success': 'House church member type changed successfully. Email sent.'}, status=status.HTTP_200_OK)
class RepotsAPI(viewsets.ModelViewSet):
    
    queryset = Reports.objects.all().order_by('id')
    serializer_class = ReportsSerializer
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['status','user_id',]

    def create(self, request, *args, **kwargs):
        try:
            return super().create(request, *args, **kwargs)
        except ValidationError as e:
            return Response({'detail': e}, status=status.HTTP_400_BAD_REQUEST)

    def get_queryset(self):
        queryset = super().get_queryset()
        house_id = self.request.query_params.get('house_id', None)
        profile = self.request.query_params.get('profile', None)
        if profile:
            if profile == 'null':
                queryset = queryset.filter(profile__isnull=True)
            else:
                queryset = queryset.filter(profile=profile)
        if house_id:
            if house_id == 'null':
                queryset = queryset.filter(house_id__isnull=True)
            else:
                queryset = queryset.filter(house_id=house_id)
        return queryset
    
class ReportsBulkActionApi(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        action = request.data.get('action')
        reports = request.data.get('reports')

        if action == 'delete':
            # Delete the selected churches
            Reports.objects.filter(id__in=reports).delete()
            return Response({'message': 'Reports deleted successfully.'})
        elif action == 'pending':
            # pending the selected churches
            Reports.objects.filter(id__in=reports).update(status='pending', updated_at=timezone.now())
            return Response({'message': 'Reports Updated successfully.'})
        elif action == 'resolved':
            # pending the selected churches
            Reports.objects.filter(id__in=reports).update(status='resolved',updated_at=timezone.now())
            return Response({'message': 'Reports Updated successfully.'})
        else:
            return Response({'error': 'Invalid action.'}, status=status.HTTP_400_BAD_REQUEST)


class EventPostAPI(viewsets.ModelViewSet):
    
    queryset = Post.objects.filter(parent=None)
    serializer_class = EventPostSerializer
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticated]
    filter_backends = [SearchFilter, filters.DjangoFilterBackend]
    filterset_fields = ['user','parent', 'event_id']
    def perform_create(self, serializer):
        post = serializer.save()  
        event = post.event_id  
        if event:
            event_members = EventMembers.objects.filter(event_id=event)
            recipient_emails = [member.user_email for member in event_members]
            event_name = event.name if event else ''
            event_owner_name = event.user_id.first_name if event.user_id else "Event Organizer"

            context = {
                'post_content': post.message,
                'event_name': event.name,
                'event_slug': event.slug,
                'event_owner_name': event_owner_name,
                'recipient_user': {  # Initialize the recipient_user dictionary
                    'name': '',  
                },
            }

            for recipient_email in recipient_emails:
                recipient_user = Users.objects.filter(email=recipient_email).first()
                recipient_name = recipient_user.first_name if recipient_user else ''
                context['recipient_user']['name'] = recipient_name
                subject='Post Notification :{}'.format(event_name)
               
                html_message = render_to_string('eventpost_email.html', context)
                plain_message = strip_tags(html_message)
                
                email = EmailMultiAlternatives(
                    subject=subject,
                    body=plain_message,
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    to=[recipient_email],  # Use a list to specify recipients
                )
                email.attach_alternative(html_message, "text/html")
                email.send()

            return Response({'message': 'Post created successfully',
                            'event_name': event.name,
                            'event_slug': event.slug},
                            status=status.HTTP_201_CREATED)
        else:
            # Handle the case where no event is associated with the post
            return Response({'message': 'Post created successfully',
                            'event_name': '',
                            'event_slug': ''},
                            status=status.HTTP_201_CREATED)
        
    def create(self, request, *args, **kwargs):
        try:
            return super().create(request, *args, **kwargs)
        except ValidationError as e:
            return Response({'detail': e}, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, *args, **kwargs):
        try:
            return super().update(request, *args, **kwargs)
        except ValidationError as e:
            return Response({'detail': e}, status=status.HTTP_400_BAD_REQUEST)

    def get_queryset(self):
        queryset=super().get_queryset()
        order_by=self.request.query_params.get('order_by')
        date_param = self.request.query_params.get('date')
        queryset = queryset.order_by('-id')  
        if date_param:
            try:
                date = parse(date_param).date()
                queryset = queryset.filter(created_at__date=date)
            except ValueError:
                pass
        if order_by:
                queryset=queryset.order_by(order_by)

        return queryset
    
# class GetEventCommentAPI(viewsets.ReadOnlyModelViewSet):
    
#     queryset = Post.objects.filter(parent=None).order_by('-created_at')
#     serializer_class = EventPostDetailSerializer
#     pagination_class = CustomPageNumberPagination
#     filter_backends = [filters.DjangoFilterBackend]
#     filterset_fields = ['user', 'event_id']


# class ConversationAPI(viewsets.ModelViewSet):
    
#     queryset = Conversation.objects.all().order_by('id')
#     serializer_class = ConversationSerializer
#     pagination_class = CustomPageNumberPagination
#     permission_classes = [IsAuthenticated]

#     def create(self, request, *args, **kwargs):
#         serializer = self.get_serializer(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         participants = request.data['participants']
#         if len(participants) < 2:
#             return Response({'detail': "A conversation must have at least two participants."}, status=status.HTTP_400_BAD_REQUEST)

#         # Check if a conversation already exists between the participants
#         existing_conversation = Conversation.objects.filter(
#             participants__in=participants
#         ).annotate(participant_count=models.Count('participants')).filter(participant_count=len(participants))
#         print(existing_conversation,"------existing_conversation")
#         if existing_conversation.exists():
#             return Response({'detail': "A conversation already exists between the participants."}, status=status.HTTP_400_BAD_REQUEST)
#         self.perform_create(serializer)       
#         return Response(serializer.data, status=status.HTTP_201_CREATED)
    
#     def get_queryset(self):
#         queryset = super().get_queryset()
#         user =  self.request.user
#         participant = self.request.query_params.get('participant', None)
#         user_id = self.request.query_params.get('user_id')
#         if user_id:
#             queryset = queryset.filter(participants__id=user_id)
#         if participant:
#             pass
#         return queryset

      
# class ChatAPI(viewsets.ModelViewSet):
    
#     queryset = Chat.objects.all().order_by('-created_at')
#     serializer_class = ChatSerializer
#     pagination_class = CustomPageNumberPagination
#     permission_classes = [IsAuthenticated]
#     filter_backends = [filters.DjangoFilterBackend]
#     filterset_fields = ['conversation',]
#     def get_queryset(self):
#         queryset = super().get_queryset()
#         conversation_id = self.request.query_params.get('conversation')
#         start_date = self.request.query_params.get('start_date')
#         end_date = self.request.query_params.get('end_date')
#         user_id = self.request.query_params.get('user_id')

#         if conversation_id:
#             queryset = queryset.filter(conversation=conversation_id)
#         if user_id:
#             user = get_object_or_404(Users, id=user_id)
#             queryset = queryset.filter(models.Q(sender=user) | models.Q(receiver=user))
#         if start_date and end_date:
#             start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
#             end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
#             queryset = queryset.filter(created_at__range=[start_date, end_date])

#         return queryset
#     def create(self, request, *args, **kwargs):
#         try:
#             return super().create(request, *args, **kwargs)
#         except ValidationError as e:
#             return Response({'detail': e}, status=status.HTTP_400_BAD_REQUEST)


# class GetConversationAPI(APIView):
#     def get(self, request):
#         participant_ids = request.GET.getlist('participant_ids')
#         if len(participant_ids) < 2: 
#             return Response({'detail': "A conversation must have at least two participants."}, status=status.HTTP_400_BAD_REQUEST)
#         conversations = Conversation.objects.filter(participants__in=participant_ids)
#         conversation_count = len(participant_ids)
#         existing_conversations = conversations.annotate(participant_count=models.Count('participants')).filter(participant_count=conversation_count)
#         serializer = ConversationSerializer(existing_conversations, many=True)
#         return Response(serializer.data, status=status.HTTP_200_OK)

class DashboardDataAPI(APIView):
    def get(self, request):
        total_users = Users.objects.count()
        total_churches = Churches.objects.count()
        all_houses= House_church.objects.count()
        today = timezone.now().date()
        thirty_days_ago = today - timedelta(days=30)
        user_registrations = Users.objects.filter(date_joined__date__range=(thirty_days_ago, today)).count()
        house_church_registrations = Churches.objects.filter(created_at__date__range=(thirty_days_ago, today), status=True).count()
        church_registrations= Churches.objects.filter(created_at__date__range=(thirty_days_ago, today), status=False).count()
        flagged_user_profile = Users.objects.filter(flag__isnull=False).count()
        flagged_house_church = House_church.objects.filter(flag__isnull=False).count()
        upcoming_event_count = Events.objects.filter(start__gte=timezone.now().date()).count()
        data = {
            'total_users': total_users,
            'total_churches': total_churches,
            'all_houses':all_houses,
            'user_registrations': user_registrations,
            'house_church_registrations': house_church_registrations,
            'church_registrations': church_registrations,
            'flagged_user_count': flagged_user_profile,
            'flagged_house_church_count': flagged_house_church,
            'upcoming_event_count': upcoming_event_count,


        }
        return Response(data)
    
class StateViewSet(viewsets.ModelViewSet):
    queryset = State.objects.all()
    serializer_class = StateSerializer
    pagination_class = CustomPageNumberPagination
    def get_queryset(self):
        queryset=super().get_queryset()
        order_by=self.request.query_params.get('order_by')
        name=self.request.query_params.get('name')

        if name:
            queryset=queryset.filter(name__icontains=name)
        if order_by:
                queryset=queryset.order_by(order_by)

        return queryset

class CountyViewSet(viewsets.ModelViewSet):
    queryset = County.objects.all()
    serializer_class = CountySerializer
    pagination_class = CustomPageNumberPagination

    def get_queryset(self):
        queryset = super().get_queryset()
        name = self.request.query_params.get('name')
        state = self.request.query_params.get('state')
        order_by = self.request.query_params.get('order_by')

        if name:
            queryset = queryset.filter(name__icontains=name)
        
        if state:
            queryset = queryset.filter(state__name__icontains=state)
        
        if order_by:
            queryset = queryset.order_by(order_by)

        return queryset

class LocationViewSet(viewsets.ModelViewSet):
    queryset = Location.objects.all()
    serializer_class = LocationSerializer
    pagination_class = CustomPageNumberPagination
    def get_queryset(self):
        queryset=super().get_queryset()
        order_by=self.request.query_params.get('order_by')
        name=self.request.query_params.get('name')
        county = self.request.query_params.get('county')
        state = self.request.query_params.get('state')

        if name:
            queryset=queryset.filter(name__icontains=name)
        if county:
            queryset = queryset.filter(county__name__icontains=county)
        if state:
            queryset = queryset.filter(county__state__name__icontains=state)

        if order_by:
                queryset=queryset.order_by(order_by)

        return queryset

        

def create_location_page(location, meta_title, meta_description, keywords, page_title, is_active, follow, index, image_path):
    location_page = LocationPage(
        location=location,
        meta_title=meta_title,
        meta_description=meta_description,
        keywords=keywords,
        page_title=page_title,
        is_active=is_active,
        follow=follow,
        index=index,
        image_path=image_path
    )
    location_page.save()

# from rest_framework.exceptions import NotFound,APIException
# class HouseChurchByZipcodeAPI(APIView):
#     def get(self, request):
#         nearest_house_churches = []
#         upcoming_events = []
#         posts = []
#         current_datetime = datetime.now()
#         zipcode = request.query_params.get('zipcode')

#         if not zipcode:
#             return Response(status=status.HTTP_400_BAD_REQUEST)

#         # Retrieve the latitude and longitude of the given zipcode
#         try:
#             ziprad_entry = Ziprad.objects.filter(zipcode=zipcode).first()
#             if ziprad_entry is None:
#                 raise NotFound("Ziprad entry not found for the provided zipcode")
#             latitude = ziprad_entry.latitude
#             longitude = ziprad_entry.longitude
#         except Ziprad.MultipleObjectsReturned:
#             raise APIException("Multiple Ziprad entries found for the provided zipcode")

#         # Retrieve house church associated with the provided zipcode
#         try:
#             house_church_at_zipcode = House_church.objects.get(zipcode=zipcode)
#             house_church_data = ShortHouseSerializer(house_church_at_zipcode).data
#             house_church_data['distance'] = 0  # Set distance to 0 for this house church
#             nearest_house_churches.append(house_church_data)
#         except House_church.DoesNotExist:
#             pass

#         # Retrieve the nearest house churches within a 40-mile radius
#         house_churches = House_church.objects.filter(latitude__isnull=False, longitude__isnull=False)
#         for house_church in house_churches:
#             distance = get_distance_from_two_location(latitude, longitude, house_church.latitude, house_church.longitude)
#             if distance <= 40:
#                 house_church_data = ShortHouseSerializer(house_church).data
#                 house_church_data['distance'] = distance
#                 nearest_house_churches.append(house_church_data)

#         # Sort the nearest house churches by distance
#         sorted_house_churches = sorted(nearest_house_churches, key=itemgetter('distance'))
#         nearest_10_house_churches = sorted_house_churches[:10]

#         # Get the upcoming events for each house church
#         house_church_ids = [house_church['id'] for house_church in nearest_10_house_churches]
#         upcoming_events = Events.objects.filter(house_id__in=house_church_ids, end__gte=current_datetime.date())
#         upcoming_events_data = EventsSerializer(upcoming_events, many=True).data
#         # Get posts related to the upcoming events and nearest house churches
#         max_posts_per_house_church = 5  # Maximum number of posts to display for each house church

#         for house_church in nearest_10_house_churches:
#             house_church_posts = Post.objects.filter(event_id__house_id=house_church['id']).order_by('-created_at')[:max_posts_per_house_church]
#             serialized_house_church_posts = EventPostSerializer(house_church_posts, many=True).data
#             posts.extend(serialized_house_church_posts)
#         return Response({'house_churches': nearest_10_house_churches,'events': upcoming_events_data, 'posts': posts}, status=status.HTTP_200_OK)

from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from rest_framework.exceptions import NotFound, APIException
from operator import itemgetter
from datetime import datetime
from .models import Ziprad, House_church, Events, Post
from .serializers import ShortHouseSerializer, EventsSerializer, EventPostSerializer
# from .utils import get_distance_from_two_location

class HouseChurchByZipcodeAPI(APIView):
    def get(self, request):
        nearest_house_churches = []
        upcoming_events = []
        posts = []
        current_datetime = datetime.now()
        zipcode = request.query_params.get('zipcode')

        if not zipcode:
            return Response(status=status.HTTP_400_BAD_REQUEST)

        try:
            ziprad_entry = Ziprad.objects.filter(zipcode=zipcode).first()
            if ziprad_entry is None:
                raise NotFound("Ziprad entry not found for the provided zipcode")
            latitude = ziprad_entry.latitude
            longitude = ziprad_entry.longitude
        except Ziprad.MultipleObjectsReturned:
            raise APIException("Multiple Ziprad entries found for the provided zipcode")

        house_churches = House_church.objects.filter(latitude__isnull=False, longitude__isnull=False)
        for house_church in house_churches:
            distance = get_distance_from_two_location(latitude, longitude, house_church.latitude, house_church.longitude)
            if distance <= 40:
                house_church_data = ShortHouseSerializer(house_church).data
                house_church_data['distance'] = distance
                nearest_house_churches.append(house_church_data)

        sorted_house_churches = sorted(nearest_house_churches, key=itemgetter('distance'))
        nearest_10_house_churches = sorted_house_churches[:10]

        house_church_ids = [house_church['id'] for house_church in nearest_10_house_churches]
        upcoming_events = Events.objects.filter(house_id__in=house_church_ids, end__gte=current_datetime.date())
        upcoming_events_data = EventsSerializer(upcoming_events, many=True).data

        max_posts_per_house_church = 5
        for house_church in nearest_10_house_churches:
            house_church_posts = Post.objects.filter(event_id__house_id=house_church['id']).order_by('-created_at')[:max_posts_per_house_church]
            serialized_house_church_posts = EventPostSerializer(house_church_posts, many=True).data
            posts.extend(serialized_house_church_posts)

        return Response({'house_churches': nearest_10_house_churches, 'events': upcoming_events_data, 'posts': posts}, status=status.HTTP_200_OK)




class EventMessageViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = EventMessageSerializer
    pagination_class = CustomPageNumberPagination
    queryset = EventMessage.objects.all().order_by('-id')  # Add this line to define the default queryset
    
    def perform_create(self, serializer):
        event_id = self.request.data.get('event_id')
        recipient_user_id = self.request.data.get('recipient_user_id')
        
        event = Events.objects.get(pk=event_id)
        recipient_user = Users.objects.get(pk=recipient_user_id)
        
        if recipient_user == self.request.user:
            raise serializers.ValidationError("You cannot send a message to yourself.")
        
        serializer.save(user_id=self.request.user, event_id=event, receipt_user=recipient_user)

class SendInvitationAPI(APIView):
    def post(self, request):
        event_id = request.data.get('event_id')
        house_id = request.data.get('house_id')
        users = request.data.get('users')
        attendee_type = request.data.get('attendee_type', 'attendee')
        message = request.data.get('message')
        joined_by = request.data.get('joined_by')

        event = None
        house_church = None

        if event_id:
            event = Events.objects.get(id=event_id)

        if house_id:
            house_church = House_church.objects.get(id=house_id)

        if not event and not house_church:
            return Response({'message': 'Invalid input. Provide either event_id or house_id'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Group recipients for the global message
        recipient_emails = request.data.get('recipient_emails', [])  # Replace 'recipient_emails' with the correct key
        recipient_names = []
        for receipt_email in recipient_emails:
            try:
                global_recipient_user = Users.objects.get(email=receipt_email)
                recipient_names.append(global_recipient_user.first_name)
            except Users.DoesNotExist:
                pass
        
        event_name = event.name if event else ''  # Define event_name
        
        # Create a single thread for the global message
        if recipient_emails:
            try:
                global_message_title = request.data.get('title', 'Global Message')
                context = {
                    'recipients': recipient_names,
                    'event_name': event_name,
                    'message': message,
                    'event_slug': event.slug if event else '',
                }

                # Create an EventMessage for the global message (outbox)
                global_event_message = EventMessage.objects.create(
                    user_id=request.user,  # Set sender user
                    title=global_message_title,
                    event_message=message,
                    type='outbox',
                    parent_message=None,
                )
                global_event_message.recipients.add(*recipient_emails)
                global_event_message.save()

                # Send the global message to all recipients
                template_name = 'global_message_email.html'
                subject_for = f'{global_message_title}: {event_name}'
                html_message = render_to_string(template_name, context)
                plain_message = strip_tags(html_message)
                email = EmailMultiAlternatives(
                    subject=subject_for,
                    body=plain_message,
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    to=recipient_emails
                )
                email.attach_alternative(html_message, "text/html")
                email_response = email.send()

                # Handle the email response as needed

                return Response({'message': 'Global Message sent successfully'}, status=status.HTTP_200_OK)

            except Exception as e:
                return Response({'message': 'Failed to send global message'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


        token_payload = {
            'type': attendee_type,
            'event_id': event.id if event else None,
            'house_id': house_church.id if house_church else None,
        }

        tokens = []

        for receipt_user in users:
            receipt_email = receipt_user['email']
            token_payload['email'] = receipt_email
            token = jwt.encode(token_payload, settings.SECRET_KEY, algorithm='HS256')
            tokens.append(token)

        event_name = event.name if event else ''
        house_church_name = house_church.name if house_church else ''

        email_responses = []

        for index, receipt_user in enumerate(users):
            receipt_name = receipt_user['name']
            receipt_email = receipt_user['email']

            try:
                user = Users.objects.get(email=receipt_email)
                receipt_name = user.first_name
            except Users.DoesNotExist:
                user = None

            event_city = ''
            event_state = ''
            event_zipcode = ''
            event_date = ''
            event_time = ''

            if event:
                event_city = event.city
                event_state = event.state
                event_zipcode = event.zipcode
                event_date = event.start
                event_time = event.time

            event_slug = event.slug if event else ''
            house_church_slug = house_church.slug if house_church else ''
            event_owner_email = event.user_id.email if event else ''
            event_owner_name = event.user_id.first_name if event else ''
            house_church_owner_email = house_church.user_id.first_name if house_church else ''

            context = {
                'receipt_user': {
                    'name': receipt_name
                },
                'event_name': event_name,
                'event_owner': event_owner_email if event else house_church_owner_email,
                'event_owner_name':event_owner_name,
                'event_slug': event_slug,
                'event_city': event_city,
                'event_state': event_state,
                'event_zipcode': event_zipcode,
                'event_date': event_date,
                'event_time': event_time,
                'house_church_owner': house_church_owner_email,
                'message': message,
                'house_church_name': house_church_name,
                'house_church_slug': house_church_slug,
                'message': message,
                'user': user, 
                'token': tokens[index],
            }

            try:
                recipient_user = Users.objects.get(email=receipt_email)

                if joined_by == 'request' and event:
                    notification_message = f"You have received a join request for {event_name}"
                    notification = Notification(user=recipient_user, message=notification_message, created_at=timezone.now())
                    notification.save()

                    # Create an EventMessage for request (inbox)
                    event_message = EventMessage.objects.create(
                        user_id=recipient_user,  # Set recipient user's id
                        receipt_user=request.user,
                        event_id=event,
                        title= f"{receipt_email} has requested to join event",
                        event_message=message,
                        type='inbox',
                        parent_message=None, 
                    )
                    event_message.save()

                elif joined_by == 'invite' and event:
                    notification_message = f"You have received an invitation to {event_name}"
                    notification = Notification(user=recipient_user, message=notification_message, created_at=timezone.now())
                    notification.save()

                    # Create an EventMessage for invite (outbox)
                    event_message = EventMessage.objects.create(
                        user_id=request.user,  # Set sender user
                        receipt_user=recipient_user if recipient_user else None,
                        title= f"You have invited {receipt_email}",
                        event_message=message,
                        event_id=event, # Save the event_id
                        type='outbox',
                        parent_message=None, 
                    )
                    event_message.save()

            except Users.DoesNotExist:
                # Handling case when recipient user does not exist
                recipient_user = None

                if event and joined_by == 'invite':
                    # Create an EventMessage for invite (outbox) with the recipient_email
                    event_message = EventMessage.objects.create(
                        user_id=request.user,  # Set sender user
                        receipt_user=None, 
                        event_id=event,
                        title= f"You have invited {receipt_email}",                        
                        event_message=message,             
                        type='outbox',
                        parent_message=None 
                    )
                    event_message.save()
            if recipient_user:
                context['recipient_user'] = {
                    'name': recipient_user.first_name,
                    'email': recipient_user.email,
                }
            else:
                # Use the provided name and email when the recipient user is not registered
                context['recipient_user'] = {
                    'name': receipt_name,
                    'email': receipt_email,
                }




            if event and joined_by == 'request':
                try:
                    event_member = EventMembers.objects.create(user_email=receipt_email, event_id=event)
                    event_member.joined_by = joined_by
                    event_member.type = attendee_type
                    event_member.status = 'onhold'
                    event_member.message = message 
                    event_member.save()
                except Exception as e:
                    pass
            elif event and joined_by == 'invite':
                try:
                    event_member = EventMembers.objects.create(user_email=receipt_email, event_id=event)
                    event_member.joined_by = joined_by
                    event_member.type = attendee_type
                    event_member.status = 'onhold'
                    event_member.message = message 
                    event_member.save()
                except Exception as e:
                    pass

            if house_church:
                try:
                    house_member = HouseChurchMember.objects.create(user_email=receipt_email)
                    house_member.type = attendee_type
                    house_member.house_id = house_church
                    house_member.status = 'approved'
                    house_member.message = message
                    house_member.save()
                except Exception as e:
                    pass
            context['recipient_user'] = {
                    'name': receipt_name,
                    'email': receipt_email,
                }
            to_email = receipt_email
            if event and joined_by == 'request':
                template_name = 'event_join_request_email.html'
                to_email = event_owner_email if event else house_church_owner_email
                subject_for= 'Event Join Request :{}'.format(event_name)
            elif event and joined_by == 'invite':
                template_name = 'event_invitation_email.html'
                subject_for= 'Invitation For :{}'.format(event_name)
            else:
                subject_for= 'Follow to :{}'.format(house_church_name)
                template_name = 'house_invitation_email.html'
            

            html_message = render_to_string(template_name, context)
            plain_message = strip_tags(html_message)
            email = EmailMultiAlternatives(
                subject=subject_for,
                body=plain_message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[to_email]
            )
            email.attach_alternative(html_message, "text/html")
            email_response = email.send()
            email_responses.append(email_response)

        if all(response == 1 for response in email_responses):
            return Response({'message': 'Invitations sent successfully'}, status=status.HTTP_200_OK)
        else:
            return Response({'message': 'Failed to send invitations'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



class UpdateLocationPageMetaView(generics.GenericAPIView):
    def get(self, request, *args, **kwargs):
        locations = Location.objects.all()

        for location in locations:
            location_name = location.name
            new_meta_title = '(dynmic_location)'.replace('(dynmic_location)', location_name)

            location_page, created = LocationPage.objects.get_or_create(
                location=location,
                defaults={'meta_title': new_meta_title}
            )

            if not created:
                location_page.meta_title = new_meta_title
                location_page.save()
                # location_page.is_active = True 
                # location_page.save()

        return Response({'message': 'Successfully updated/created meta_titles'})
    


class MetaContentAPI(viewsets.ModelViewSet):
    queryset= MetaContent.objects.all()
    serializer_class= MetaContentSerializers

    def create(self, request, *args, **kwargs):
        return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def _update_location_pages(self, instance):
        locations = Location.objects.all()
        for location in locations:
            location_name = location.name

            new_meta_title = instance.meta_title.replace('(dynmic_location)', location_name)
            new_meta_description = instance.meta_title.replace('(dynmic_location)', location_name)
            new_page_title = instance.meta_title.replace('(dynmic_location)', location_name)
            new_keywords = instance.keywords.replace('(dynmic_location)', location_name)
            new_is_active = instance.is_active
            new_follow = instance.follow
            new_index = instance.index
            new_image = instance.image
            location_page, created = LocationPage.objects.get_or_create(
                location=location,
                defaults={
                    'meta_title': new_meta_title,
                    'meta_description': new_meta_description,
                    'page_title': new_page_title,
                    'keywords': new_keywords,
                    'is_active': new_is_active,
                    'follow': new_follow,
                    'index': new_index,
                    'image': new_image

                }
            )

            if not created:
                location_page.meta_title = new_meta_title
                location_page.meta_description = new_meta_description
                location_page.keywords = new_keywords
                location_page.page_title = new_page_title
                location_page.is_active = new_is_active
                location_page.follow = new_follow
                location_page.index = new_index
                location_page.image = new_image
                location_page.save()

    def update(self, request, *args, **kwargs):
        response = super().update(request, *args, **kwargs)
        if response.status_code == status.HTTP_200_OK:
            instance = self.get_object()
            instance.updated_at = timezone.now()
            instance.save()

            self._update_location_pages(instance)

        return response

    def partial_update(self, request, *args, **kwargs):
        response = super().partial_update(request, *args, **kwargs)
        if response.status_code == status.HTTP_200_OK:
            instance = self.get_object()
            instance.updated_at = timezone.now()
            instance.save()

            self._update_location_pages(instance)

        return response


class EventOwnerUserListViewSet(viewsets.ModelViewSet):
    serializer_class = SenderdetailSerializer
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        event_owner_id = self.request.user.id
        event_id = self.request.query_params.get('event_id')  
        if event_id:
            user_ids = EventMessage.objects.filter(user_id=event_owner_id, event_id=event_id).values_list('receipt_user', flat=True).distinct()
            user_ids = [user_id for user_id in user_ids if user_id != event_owner_id]
            queryset = Users.objects.filter(id__in=user_ids).order_by('-id')
            print(queryset,'--------')
        else:
            user_ids = EventMessage.objects.filter(user_id=event_owner_id).values_list('receipt_user', flat=True).distinct()
            user_ids = [user_id for user_id in user_ids if user_id != event_owner_id]
            queryset = Users.objects.filter(id__in=user_ids).order_by('-id')
            print(queryset,'--------')

        return queryset

    # def list(self, request, *args, **kwargs):
    #     queryset = self.get_queryset()
    #     serializer = SenderdetailSerializer(queryset, many=True)
    #     return Response(serializer.data, status=status.HTTP_200_OK)



class EventuserChatList(viewsets.ModelViewSet):
    http_method_names = ['get', 'post']
    pagination_class = CustomPageNumberPagination
    permission_classes = [IsAuthenticated]
    serializer_class = EventMessageSerializer


    def get_queryset(self):
        event_id = self.request.query_params.get('event_id')
        user_id = self.request.query_params.get('user_id')
        event_owner_id = self.request.user.id
        print(event_id, event_owner_id, "event_owner_id")
        

        queryset = EventMessage.objects.filter(
            event_id=event_id,
            user_id__id__in=[user_id, event_owner_id],
            receipt_user__id__in=[user_id, event_owner_id],
        ).exclude(user_id=user_id,receipt_user = user_id )
        queryset = queryset.exclude(user_id=event_owner_id,receipt_user = event_owner_id )
        queryset = queryset.order_by('-id')
        return queryset








