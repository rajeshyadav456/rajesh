from django.contrib import admin
from django.urls import include, re_path, path
from django.conf import settings
from django.views.static import serve 

admin.site.site_header = 'FAHC Admin'
admin.site.site_title = 'FAHC Admin'
admin.site.site_url = 'https://findahousechurch.com/'
admin.site.index_title = 'FAHC Administration'
admin.empty_value_display = '**Empty**'


urlpatterns = [
    path('api/admin/', admin.site.urls),
    path('api/accounts/', include('Account.urls')),
    path('api/church/', include('Church.urls')),
    path('api/house_church/', include('HouseChurch.urls')),
    # 
    path('api/',include('authentication.urls')),
    # re_path(r'^auth/', include('rest_framework_social_oauth2.urls')), 

    re_path(r'^media/(?P<path>.*)$', serve,{'document_root': settings.MEDIA_ROOT}), 
    re_path(r'^staticfiles/(?P<path>.*)$', serve,{'document_root': settings.STATIC_ROOT}), 
]

