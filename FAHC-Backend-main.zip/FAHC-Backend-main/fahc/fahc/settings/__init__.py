import os
debug = bool(int(os.environ.get('DEBUG', 1)))
if debug:
    from .dev import *
else:
    from .prod import *