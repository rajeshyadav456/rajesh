from .base import *

ALLOWED_HOSTS = ['127.0.0.1', '165.227.74.102', 'app.findahousechurch.com']

SITE_DOMAIN = 'http://165.227.74.102:7000'


CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://165.227.74.102",
    "http://165.227.74.102:3000",
    "http://dev.findahousechurch.com",
    "https://dev.findahousechurch.com",
    "https://app.findahousechurch.com",
    "http://app.findahousechurch.com",
]