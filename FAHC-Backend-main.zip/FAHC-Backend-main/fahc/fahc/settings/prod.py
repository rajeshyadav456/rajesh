from .base import *

ALLOWED_HOSTS = ['127.0.0.1','165.227.74.102', 'app.findahousechurch.com']

SITE_DOMAIN = 'https://app.findahousechurch.com'


CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://165.227.74.102",
    "http://165.227.74.102:3000",
    "http://dev.findahousechurch.com:3000",
    "http://dev.findahousechurch.com",
    "https://dev.findahousechurch.com",
    "https://app.findahousechurch.com",
    "http://app.findahousechurch.com",
]

CSRF_COOKIE_SECURE = True
CSRF_COOKIE_HTTPONLY = True
CSRF_TRUSTED_ORIGINS=['https://dev.findahousechurch.com',]
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
USE_X_FORWARDED_HOST = True
