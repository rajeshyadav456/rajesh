from django.urls import path, include
from .views import *
from rest_framework import routers
router = routers.DefaultRouter()

router.register(r'users', UsersApi, basename='base-users')
router.register(r'churches', ChurchessApi, basename='churches')
router.register(r'contracts', ContactsApi, basename='contracts')
router.register(r'denominations', DenominationsApi, basename='denominations')
router.register(r'downloadcounts', DownloadcountsApi, basename='downloadcounts')
router.register(r'favourites', FavouritesApi, basename='favourites')
router.register(r'histories', HistoriesApi, basename='histories')
router.register(r'houses', HousesApi, basename='houses')
router.register(r'joinhouses', JoinhousesApi, basename='joinhouses')
router.register(r'migrations', MigrationsApi, basename='migrations')
router.register(r'passwordresets', PasswordResetsApi, basename='passwordresets')
router.register(r'reports', ReportsApi, basename='reports')

urlpatterns = [
    path('', include(router.urls)),
    path('index', index,name='index'),
]