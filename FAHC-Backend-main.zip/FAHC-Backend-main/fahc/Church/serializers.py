from rest_framework import serializers
from .models import  *

class UsersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = "__all__"


class ChurchesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Churches
        fields = "__all__"


class ContactsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contacts
        fields = "__all__"


class DenominationsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Denominations
        fields = "__all__"



class DownloadcountsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Downloadcounts
        fields = "__all__"

class EventsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Events
        fields = "__all__"

class FavouritesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Favourites
        fields = "__all__"

class HistoriesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Histories
        fields = "__all__"

class HousesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Houses
        fields = "__all__"

class JoinhousesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Joinhouses
        fields = "__all__"

class MigrationsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Migrations
        fields = "__all__"

class PasswordResetsSerializer(serializers.ModelSerializer):
    class Meta:
        model = PasswordResets
        fields = "__all__"


class ReportsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reports
        fields = "__all__"