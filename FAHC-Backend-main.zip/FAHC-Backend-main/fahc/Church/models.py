from django.db import models


class Churches(models.Model):
    name = models.CharField(max_length=150)
    email = models.CharField(max_length=225, blank=True, null=True)
    biz_info = models.TextField(blank=True, null=True)
    denomination_id = models.CharField(max_length=100, blank=True, null=True)
    address = models.CharField(max_length=100, blank=True, null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    state = models.CharField(max_length=20, blank=True, null=True)
    zipcode = models.CharField(max_length=7, blank=True, null=True)
    e_zip_full = models.CharField(max_length=10, blank=True, null=True)
    country = models.CharField(max_length=20, blank=True, null=True)
    loc_county = models.CharField(max_length=40, blank=True, null=True)
    loc_area_code = models.CharField(max_length=3, blank=True, null=True)
    loc_fips = models.CharField(db_column='loc_FIPS', max_length=5, blank=True, null=True)  # Field name made lowercase.
    loc_msa = models.CharField(db_column='loc_MSA', max_length=5, blank=True, null=True)  # Field name made lowercase.
    loc_pmsa = models.CharField(db_column='loc_PMSA', max_length=5, blank=True, null=True)  # Field name made lowercase.
    loc_tz = models.CharField(db_column='loc_TZ', max_length=6, blank=True, null=True)  # Field name made lowercase.
    loc_dst = models.CharField(db_column='loc_DST', max_length=1)  # Field name made lowercase.
    lat = models.CharField(max_length=15, blank=True, null=True)
    loc_lat_poly = models.CharField(db_column='loc_LAT_poly', max_length=15, blank=True, null=True)  # Field name made lowercase.
    lng = models.CharField(max_length=15, blank=True, null=True)
    loc_long_poly = models.CharField(db_column='loc_LONG_poly', max_length=15, blank=True, null=True)  # Field name made lowercase.
    website = models.CharField(max_length=255, blank=True, null=True)
    web_meta_title = models.CharField(max_length=255, blank=True, null=True)
    web_meta_desc = models.CharField(max_length=255, blank=True, null=True)
    web_meta_keys = models.CharField(max_length=255, blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    biz_phone_ext = models.CharField(max_length=8, blank=True, null=True)
    poc = models.CharField(max_length=225, blank=True, null=True)
    poc_email = models.CharField(max_length=225, blank=True, null=True)
    poc_phone = models.CharField(max_length=225, blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    image = models.CharField(max_length=225, blank=True, null=True)
    slug = models.CharField(max_length=225, blank=True, null=True)
    search_status = models.IntegerField(blank=True, null=True)
    pageurl = models.CharField(max_length=225, blank=True, null=True)
    code = models.TextField(blank=True, null=True)
    claimed = models.IntegerField(blank=True, null=True)
    updated_at = models.DateField(blank=True, null=True)
    created_at = models.DateField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'churches'


class Contacts(models.Model):
    contact_to = models.CharField(max_length=200, blank=True, null=True)
    contact_from = models.CharField(max_length=200, blank=True, null=True)
    attend = models.CharField(max_length=200, blank=True, null=True)
    question = models.CharField(max_length=200, blank=True, null=True)
    phone = models.CharField(max_length=225, blank=True, null=True)
    time = models.CharField(max_length=225, blank=True, null=True)
    message = models.TextField(blank=True, null=True)
    created_at = models.DateField(blank=True, null=True)
    updated_at = models.DateField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'contacts'


class Denominations(models.Model):
    name = models.CharField(max_length=225)
    status = models.IntegerField()
    updated_at = models.DateField(blank=True, null=True)
    created_at = models.DateField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'denominations'


class Downloadcounts(models.Model):
    user_id = models.IntegerField()
    doc_type = models.CharField(max_length=255, blank=True, null=True)
    updated_at = models.DateTimeField()
    created_at = models.DateTimeField()

    class Meta:
        managed = True
        db_table = 'downloadcounts'


class Events(models.Model):
    house_id = models.IntegerField(blank=True, null=True)
    name = models.CharField(max_length=225, blank=True, null=True)
    date = models.CharField(max_length=225, blank=True, null=True)
    time = models.CharField(max_length=225, blank=True, null=True)
    info = models.TextField(blank=True, null=True)
    email = models.CharField(max_length=225, blank=True, null=True)
    created_at = models.DateField(blank=True, null=True)
    updated_at = models.DateField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'events'


class Favourites(models.Model):
    user_id = models.CharField(max_length=225, blank=True, null=True)
    house_id = models.CharField(max_length=225, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'favourites'


class Histories(models.Model):
    user_id = models.IntegerField(blank=True, null=True)
    message = models.CharField(max_length=225, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'histories'


class Houses(models.Model):
    church_id = models.CharField(max_length=225)
    user_id = models.IntegerField()
    address = models.CharField(max_length=225, blank=True, null=True)
    city = models.CharField(max_length=225, blank=True, null=True)
    state = models.CharField(max_length=225, blank=True, null=True)
    zipcode = models.CharField(max_length=225, blank=True, null=True)
    name = models.CharField(max_length=225)
    denomination_id = models.CharField(max_length=223, blank=True, null=True)
    type = models.CharField(max_length=225, blank=True, null=True)
    days = models.CharField(max_length=225, blank=True, null=True)
    time = models.CharField(max_length=225, blank=True, null=True)
    info = models.TextField(blank=True, null=True)
    flag = models.IntegerField(blank=True, null=True)
    special_inst = models.CharField(max_length=225, blank=True, null=True)
    image = models.CharField(max_length=225, blank=True, null=True)
    gallery = models.CharField(max_length=225, blank=True, null=True)
    videos = models.CharField(max_length=225, blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    latitude = models.CharField(max_length=225, blank=True, null=True)
    longitude = models.CharField(max_length=225, blank=True, null=True)
    updated_at = models.DateField(blank=True, null=True)
    created_at = models.DateField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'houses'


class Joinhouses(models.Model):
    user_id = models.IntegerField(blank=True, null=True)
    house_id = models.IntegerField(blank=True, null=True)
    host_id = models.IntegerField(blank=True, null=True)
    message = models.TextField(blank=True, null=True)
    userphone = models.CharField(max_length=225, blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'joinhouses'


class Migrations(models.Model):
    migration = models.CharField(max_length=255)
    batch = models.IntegerField()

    class Meta:
        managed = True
        db_table = 'migrations'


class PasswordResets(models.Model):
    email = models.CharField(max_length=255)
    token = models.CharField(max_length=255)
    created_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'password_resets'


class Reports(models.Model):
    profile_id = models.IntegerField(blank=True, null=True)
    house_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    comment = models.CharField(max_length=225, blank=True, null=True)
    profile_name = models.CharField(max_length=225, blank=True, null=True)
    house_name = models.CharField(max_length=225, blank=True, null=True)
    user_name = models.CharField(max_length=225, blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    created_at = models.DateField(blank=True, null=True)
    updated_at = models.DateField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'reports'


class Users(models.Model):
    name = models.CharField(max_length=255)
    lastname = models.CharField(max_length=255, blank=True, null=True)
    email = models.CharField(unique=True, max_length=255)
    username = models.CharField(unique=True, max_length=225, blank=True, null=True)
    role = models.CharField(max_length=50, blank=True, null=True)
    address = models.CharField(max_length=225, blank=True, null=True)
    city = models.CharField(max_length=225, blank=True, null=True)
    state = models.CharField(max_length=225, blank=True, null=True)
    zipcode = models.CharField(max_length=225, blank=True, null=True)
    status = models.IntegerField()
    flag = models.IntegerField(blank=True, null=True)
    image = models.CharField(max_length=225, blank=True, null=True)
    company = models.CharField(max_length=225, blank=True, null=True)
    website = models.CharField(max_length=225, blank=True, null=True)
    about = models.TextField(blank=True, null=True)
    fb = models.CharField(max_length=225, blank=True, null=True)
    insta = models.CharField(max_length=225, blank=True, null=True)
    twitter = models.CharField(max_length=225, blank=True, null=True)
    phone = models.CharField(max_length=225, blank=True, null=True)
    password = models.CharField(max_length=255)
    gallery = models.CharField(max_length=225, blank=True, null=True)
    videos = models.CharField(max_length=225, blank=True, null=True)
    latitude = models.CharField(max_length=225, blank=True, null=True)
    longitude = models.CharField(max_length=225, blank=True, null=True)
    affilate_id = models.CharField(max_length=225, blank=True, null=True)
    remember_token = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'users'
