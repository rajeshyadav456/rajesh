from django.shortcuts import render
from django.http import HttpResponse
from .models import *
from Account.models import Users as new_users
from HouseChurch.models import (Denominations as New_Denomination, Churches as NewChurch, House_church)
from .serializers import *
from rest_framework import filters, status, viewsets, generics
from .mypagination import CustomPageNumberPagination


class UsersApi(viewsets.ModelViewSet):
    
    queryset = Users.objects.all().order_by('id')
    serializer_class = UsersSerializer
    pagination_class = CustomPageNumberPagination


class ChurchessApi(viewsets.ModelViewSet):
    
    queryset = Churches.objects.all().order_by('id')
    serializer_class = ChurchesSerializer
    pagination_class = CustomPageNumberPagination

class ContactsApi(viewsets.ModelViewSet):
    
    queryset = Contacts.objects.all().order_by('id')
    serializer_class = ContactsSerializer
    pagination_class = CustomPageNumberPagination

class DenominationsApi(viewsets.ModelViewSet):
    
    queryset = Denominations.objects.all().order_by('id')
    serializer_class = DenominationsSerializer
    pagination_class = CustomPageNumberPagination

class DownloadcountsApi(viewsets.ModelViewSet):
    
    queryset = Downloadcounts.objects.all().order_by('id')
    serializer_class = DownloadcountsSerializer
    pagination_class = CustomPageNumberPagination

class EventsApi(viewsets.ModelViewSet):
    
    queryset = Events.objects.all().order_by('id')
    serializer_class = EventsSerializer
    pagination_class = CustomPageNumberPagination

class FavouritesApi(viewsets.ModelViewSet):
    
    queryset = Favourites.objects.all().order_by('id')
    serializer_class = FavouritesSerializer
    pagination_class = CustomPageNumberPagination

class HistoriesApi(viewsets.ModelViewSet):
    
    queryset = Histories.objects.all().order_by('id')
    serializer_class = HistoriesSerializer
    pagination_class = CustomPageNumberPagination

class HousesApi(viewsets.ModelViewSet):
    
    queryset = Houses.objects.all().order_by('id')
    serializer_class = HousesSerializer
    pagination_class = CustomPageNumberPagination

class JoinhousesApi(viewsets.ModelViewSet):
    
    queryset = Joinhouses.objects.all().order_by('id')
    serializer_class = JoinhousesSerializer
    pagination_class = CustomPageNumberPagination

class MigrationsApi(viewsets.ModelViewSet):
    
    queryset = Migrations.objects.all().order_by('id')
    serializer_class = MigrationsSerializer
    pagination_class = CustomPageNumberPagination

class PasswordResetsApi(viewsets.ModelViewSet):
    
    queryset = PasswordResets.objects.all().order_by('id')
    serializer_class = PasswordResetsSerializer
    pagination_class = CustomPageNumberPagination


class ReportsApi(viewsets.ModelViewSet):
    
    queryset = Reports.objects.all().order_by('id')
    serializer_class = ReportsSerializer
    pagination_class = CustomPageNumberPagination


def index(request):
    users = updateHouseChurch()
    data = [f"<p>{user.id} {user.name}</p><br/>" for user in users]
    render_data = "".join(data)
    return HttpResponse(f"<p>Welcome to Find A House Church</p><br>{render_data}")

def movechurcusertoaccountuser():
    users = Users.objects.all()
    not_reg_users = []
    for user in users:
        try:
            new_user = new_users(
                id = user.id,
                first_name = user.name,
                last_name = user.lastname if user.lastname else "",
                email = user.email,
                username =  user.username,
                role = user.role,
                address = user.address,
                city = user.city if user.city else "",
                state = user.state,
                zipcode = user.zipcode if user.zipcode else "",
                status = user.status,
                flag = user.flag,
                image = user.image,
                company = user.company,
                website = user.website,
                about = user.about,
                fb = user.fb,
                insta = user.insta,
                twitter = user.twitter,
                phone = user.phone,
                password = user.password,
                gallery = user.gallery,
                videos = user.videos,
                latitude = user.latitude,
                longitude = user.longitude,
                affilate_id = user.affilate_id,
                remember_token =  user.remember_token,
                date_joined = user.created_at,
            )
        # new_user = new_users(id= user.id,first_name= user.name,username= user.username, role= user.role, address= user.address, city=user.city,
        #                      state= user.state, zipcode= user.zipcode, status= user.status, flag= user.flag, image = user.image,
        #                      company= user.company, website= user.website, about = user.about, fb= user.fb, insta= user.insta,
        #                      twitter= user.twitter, phone= user.phone, password= user.password, gallery= user.gallery, videos=
        #                      user.videos, latitude= user.latitude, longitude= user.longitude, affilate_id= user.affilate_id,
        #                      remember_token= user.remember_token)
            new_user.save()
        except: 
            not_reg_users.append(user)
    return not_reg_users


def move_denomination():
    denomination = Denominations.objects.all()

    for i in denomination:
        status = True if i.status==1 else False
        New_Denomination.objects.create(name = i.name, status = status, created_at = i.created_at, updated_at = i.updated_at)
    return []   

def move_Church():
    churches = Churches.objects.all().exclude(id__in = NewChurch.objects.all().values('id'))

    for church in churches:
        # try: 
        status = True if church.status==1 else False
        denomination_id= church.denomination_id
        user_id = church.user_id
        if church.user_id:
            try:
                user_id = new_users.objects.get(id = user_id)
            except: 
                user_id = None
        if denomination_id:
            if denomination_id.isdigit():
                denomination_id = New_Denomination.objects.get(id = denomination_id)
            else:
                denomination = New_Denomination.objects.filter(name = denomination_id)
                if len(denomination_id)> 0:
                    denomination_id = denomination.first()
                else:
                    denomination_id = None
        NewChurch.objects.create(
            id = church.id,
            name = church.name,
            email = church.email,
            biz_info = church.biz_info,
            denomination_id = denomination_id,
            address = church.address,
            city = church.city,
            state = church.state,
            zipcode = church.zipcode,
            e_zip_full = church.e_zip_full,
            country = church.country,
            loc_county = church.loc_county,
            loc_area_code = church.loc_area_code,
            loc_fips = church.loc_fips,
            loc_msa = church.loc_msa,
            loc_pmsa = church.loc_pmsa,
            loc_tz = church.loc_tz,
            loc_dst = church.loc_dst,
            lat = church.lat,
            loc_lat_poly = church.loc_lat_poly,
            lng = church.lng,
            loc_long_poly = church.loc_long_poly,
            website = church.website,
            web_meta_title = church.web_meta_title,
            web_meta_desc = church.web_meta_desc,
            web_meta_keys = church.web_meta_keys,
            phone = church.phone,
            biz_phone_ext = church.biz_phone_ext,
            poc = church.poc,
            poc_email = church.poc_email,
            poc_phone = church.poc_phone,
            status = status,
            user_id = user_id,
            image = church.image,
            slug = church.slug,
            search_status = church.search_status,
            pageurl = church.pageurl,
            code = church.code,
            claimed = church.claimed,
            created_at = church.created_at,
            updated_at = church.updated_at,
        )
        # except:
        #     return [church]

    return [] 

def moveHouseChurch():
    houses = []
    house_churchs = Houses.objects.all().exclude(id__in = House_church.objects.all().values('id'))
    for house_church in house_churchs:
        user = None
        denomination = None
        status = True if house_church.status==1 else False
        try:
            church = NewChurch.objects.get(id = house_church.church_id)
        except:
            church = None
        try:
            user = new_users.objects.get(id = house_church.user_id)
            denomination = New_Denomination.objects.get(id = house_church.denomination_id)
        except:
            houses.append(house_church)
        # if house_church.denomination_id:
            
        # else:
            
        
        if user:
            House_church.objects.create(
                id = house_church.id,
                church_id = church,
                user_id = user,
                address = house_church.church_id,
                city = house_church.city,
                state = house_church.state,
                zipcode = house_church.zipcode,
                name = house_church.name,
                denomination_id = denomination,
                type = house_church.type,
                days = house_church.days,
                time = house_church.time,
                info = house_church.info,
                flag = house_church.flag,
                special_inst = house_church.special_inst,
                image = house_church.image,
                gallery = house_church.gallery,
                videos = house_church.videos,
                status = status,
                latitude = house_church.latitude,
                longitude = house_church.longitude,
                created_at = house_church.created_at,
                updated_at = house_church.updated_at,

            )
    return houses 






